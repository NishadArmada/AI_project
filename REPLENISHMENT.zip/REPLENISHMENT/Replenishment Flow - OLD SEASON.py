# Databricks notebook source
import pandas as pd 
import numpy as np
from datetime import date, timedelta
from pyspark.sql.functions import col, date_format, weekofyear, year, lpad, concat_ws
from pyspark.sql import functions as F
import glob
import os

# COMMAND ----------

missing_size_df = pd.read_excel("missing_size.xlsx")
missing_df = missing_size_df[['GRADE', 'GROUP_NAME', 'SIZE_CODE', 'SIZE_GROUP', 'MIN_QTY', 'MAX_QTY']]

# COMMAND ----------

from pyspark.sql import functions as F
# Load the data
return_sku_df = spark.sql("""
                          SELECT 
                          SKU_CODE,
                          OPTION_CODE,
                          SIZE_CODE,
                          FROM_LOCATION AS LOCATION_CODE,
                          TO_LOCATION,
                          TRANSFER_TYPE
                           FROM gold.`custom-analysis`.oi_cardex_dup
                           WHERE
                           rn = 1
                           """)

store_current_stock = spark.sql(
                        """
                    SELECT 
                    ITEMCODE AS SKU_CODE, 
                    LOCATION_CODE,
                     (IN_STOCK + INTRANSIT_QTY) AS STORE_STOCK
                    from gold.`custom-analysis`.sku_stock_intransit_op_cur_stock
                    """
                    )

return_sku_df = return_sku_df.join(
    store_current_stock,
    on=['SKU_CODE', 'LOCATION_CODE'],
    how='left'
)


#  Step 1: Count unique SIZE_CODEs for TRANSFER OUT
transfer_out_counts = return_sku_df \
    .filter(
        (F.col("TRANSFER_TYPE") == "TRANSFER OUT") & 
        (F.col("STORE_STOCK") == 0)
    ).groupBy("LOCATION_CODE", "OPTION_CODE") \
    .agg(F.countDistinct("SIZE_CODE").alias("size_code_transfer_out_count"))

# Step 2: Count unique SIZE_CODEs overall
unique_sizes = return_sku_df \
    .groupBy("LOCATION_CODE", "OPTION_CODE") \
    .agg(F.countDistinct("SIZE_CODE").alias("unique_size_codes"))

# Step 3: Join both counts
result = unique_sizes.join(transfer_out_counts, on=["LOCATION_CODE", "OPTION_CODE"], how="left") \
    .withColumn("size_code_transfer_out_count", F.coalesce(F.col("size_code_transfer_out_count"), F.lit(0))) \
    .withColumn("unhealthy_option_cov", F.col("size_code_transfer_out_count") / F.col("unique_size_codes")) \
    .withColumn("healthy_cov", F.lit(1.0) - F.col("unhealthy_option_cov"))


option_cov_df = result.toPandas()
option_cov_df.head()
broken_return_option_df = option_cov_df[option_cov_df['healthy_cov']<=0.50]
broken_return_option_df.head()

# COMMAND ----------

warehouse_sku_df = spark.sql("""
          SELECT 
          distinct LOCATION_CODE as WAREHOUSE_CODE,
          SKU_CODE,
          OPTION_CODE,
          SIZE_CODE,
          COUNTRY,
          WAREHOUSE_STOCK_1 as WH_QTY
          FROM 
          gold.`custom-analysis`.SKU_BOX_QUANTITY
          where LOCATION_CODE not in ('101')
          """).toPandas()

warehouse_sku_df.head()

# COMMAND ----------

host_warehouse_stock = spark.sql("""
          SELECT 
          LOCATION_CODE as WAREHOUSE_CODE,
          SKU_CODE,
          OPTION_CODE,
          SIZE_CODE,
          COUNTRY,
          BOXQTY,
          WAREHOUSE_STOCK_1 as HOSTWATEHOUSE_STOCK
          FROM 
          gold.`custom-analysis`.SKU_BOX_QUANTITY
          WHERE LOCATION_CODE='101' 
          """).toPandas()
host_warehouse_stock.head()

# COMMAND ----------

warehouse_sku_df = warehouse_sku_df[warehouse_sku_df['WH_QTY']>0].copy()

# COMMAND ----------

warehouse_sku_df.head()

# COMMAND ----------

historic_sku_sales_df = spark.sql(
    """
        SELECT 
        A.SALES_DATE,
        A.LOCATION_CODE,A.STORE_TYPE,
        A.GRADE,A.COUNTRY,A.GROUP_NAME,A.SUB_GROUP_NAME,
        A.SKU_CODE, A.OPTION_CODE,
        A.SIZE_CODE,A.LAUNCH_DATE,
        A.BRAND_NAME,A.SUB_BRAND_NAME,
        A.SIZE_GROUP,A.SEASON_NAME, A.SUB_SEASON_NAME,A.SEASON_NAME_YEAR,
        SUM(TOTAL_QUANTITY) AS TOTAL_QUANTITY
        FROM gold.`custom-analysis`.sku_clustering_temp_sales_transfer AS A
        LEFT JOIN gold.`custom-analysis`.product_attributes AS B ON A.SKU_CODE = B.SKU_CODE
        WHERE
        A.SALES_DATE BETWEEN DATE(CURRENT_DATE - INTERVAL 42 DAY) AND CURRENT_DATE
        AND
        A.BRAND_NAME in ('RIVA','CHOICE','RIVA KIDS') AND B.SEASON_NAME_YEAR NOT IN ('SPRING SUMMER 2025', 'AUTUMN WINTER 2025') AND A.TRANS_ACTIVE = '1'
        GROUP BY
        A.SALES_DATE,
        A.LOCATION_CODE,A.STORE_TYPE,
        A.GRADE,A.COUNTRY,A.GROUP_NAME,
        A.SKU_CODE, A.OPTION_CODE,
        A.SIZE_CODE,A.LAUNCH_DATE,
        A.BRAND_NAME,A.SUB_BRAND_NAME, A.SUB_GROUP_NAME,
        A.SIZE_GROUP,A.SEASON_NAME, A.SUB_SEASON_NAME,A.SEASON_NAME_YEAR
        
    """).toPandas()

# COMMAND ----------

historic_sku_sales_df['GROUP_NAME'].fillna(historic_sku_sales_df['GROUP_NAME'].mode()[0], inplace=True)
historic_sku_sales_df['SUB_GROUP_NAME'].fillna(historic_sku_sales_df['SUB_GROUP_NAME'].mode()[0], inplace=True)

# COMMAND ----------

historic_sku_sales_df.isnull().sum()

# COMMAND ----------

historic_sku_sales_df['SALES_DATE']     = pd.to_datetime(historic_sku_sales_df['SALES_DATE'])
historic_sku_sales_df['TOTAL_QUANTITY'] = pd.to_numeric(historic_sku_sales_df['TOTAL_QUANTITY'], errors='coerce').fillna(0)
cutoff = historic_sku_sales_df['SALES_DATE'].max() - pd.Timedelta(days=42)
final_histori_sales_df = historic_sku_sales_df[historic_sku_sales_df['SALES_DATE'] >= cutoff]

# COMMAND ----------

iso = final_histori_sales_df['SALES_DATE'].dt.isocalendar()
final_histori_sales_df['ISO_YYYYWW'] = (
        iso['year'].astype(str)
      + '-W' 
      + iso['week'].astype(str).str.zfill(2)
)

# COMMAND ----------

id_cols = [
    'LOCATION_CODE', 'STORE_TYPE', 'COUNTRY','GRADE',
    'SKU_CODE', 'OPTION_CODE', 'SIZE_CODE',
    'BRAND_NAME', 'SUB_BRAND_NAME','GROUP_NAME','SIZE_GROUP']


# COMMAND ----------

agg = (final_histori_sales_df
       .groupby(id_cols + ['ISO_YYYYWW'], as_index=False)
       .agg(QTY_SOLD=('TOTAL_QUANTITY', 'sum')))

# COMMAND ----------

agg.head()

# COMMAND ----------

pivot = (agg
         .pivot_table(index=id_cols,
                      columns='ISO_YYYYWW',
                      values='QTY_SOLD',
                      aggfunc='sum',
                      fill_value=0
                      )).reset_index()

# COMMAND ----------

weekly_sales_qty_cols = sorted([col for col in pivot.columns if col.startswith('20') and '-W' in col])
weekly_sales_qty_cols

# COMMAND ----------

if len(weekly_sales_qty_cols)>6:
    pivot.drop(weekly_sales_qty_cols[0], axis=1, inplace=True)
weekly_sales_qty_cols = sorted([col for col in pivot.columns if col.startswith('20') and '-W' in col])
weekly_sales_qty_cols

# COMMAND ----------

print(weekly_sales_qty_cols[-2:])
print(weekly_sales_qty_cols[-4:-2])
print(weekly_sales_qty_cols[:-4])

# COMMAND ----------

from datetime import date
import datetime

def get_iso_start_date(iso_week_str: str) -> date:
    """
    Accepts a string in the format 'YYYY-Www' (e.g., '2025-W17') and returns the start date (Monday)
    of the corresponding ISO week.
    """
    year_str, week_str = iso_week_str.split('-W')
    year = int(year_str)
    week = int(week_str)
    return date.fromisocalendar(year, week, 1)  # 1 = Monday

# COMMAND ----------

num_days = (datetime.datetime.now().date()- get_iso_start_date(weekly_sales_qty_cols[-2])).days
print(num_days)

# COMMAND ----------

pivot['ROS1'] = pivot[weekly_sales_qty_cols[:-4]].sum(axis=1) / 14
pivot['ROS2'] = pivot[weekly_sales_qty_cols[-4:-2]].sum(axis=1) / 14
pivot['ROS3'] = pivot[weekly_sales_qty_cols[-2:]].sum(axis=1) / num_days

# COMMAND ----------

from pyspark.sql.functions import col, weekofyear, year, lpad, concat_ws, row_number, round as F_round
from pyspark.sql.window import Window
import pyspark.sql.functions as F
import numpy as np

# 1. Load the data using Spark SQL
historical_week_stock_df = spark.sql("""
    SELECT 
        STK_DATE,
        LOCATION_CODE,
        ITEMCODE AS SKU_CODE,
        STOCK AS CURRENT_STORE_STOCK
    FROM gold.`custom-analysis`.SKU_STOCK_HISTORY_DUP
    WHERE STK_DATE BETWEEN DATE(CURRENT_DATE - INTERVAL 42 DAY) AND CURRENT_DATE
""")

# 2. Add ISO_YYYYWW column in format 'YYYY-Www'
historical_week_stock_df = (
    historical_week_stock_df
    .withColumn("YEAR", year("STK_DATE"))
    .withColumn("WEEK", lpad(weekofyear("STK_DATE").cast("string"), 2, '0'))
    .withColumn("ISO_YYYYWW", concat_ws("-W", col("YEAR"), col("WEEK")))
)

# 3. Get end-of-week stock (latest STK_DATE per week/location/SKU)
window_spec = Window.partitionBy("LOCATION_CODE", "SKU_CODE", "ISO_YYYYWW").orderBy(col("STK_DATE").desc())

latest_stock_df = (
    historical_week_stock_df
    .withColumn("rn", row_number().over(window_spec))
    .filter(col("rn") == 1)
    .drop("rn", "YEAR", "WEEK")
    .withColumn("CURRENT_STORE_STOCK", F_round(col("CURRENT_STORE_STOCK").cast("double")))
)

# 4. Convert to Pandas for pivoting
historical_weekly_stock_df = latest_stock_df.toPandas()
historical_weekly_stock_df.loc[historical_weekly_stock_df['CURRENT_STORE_STOCK']<0,'CURRENT_STORE_STOCK'] = 0 # current stock <=0 replace with 0
historical_weekly_stock_df['CURRENT_STORE_STOCK'].fillna(0, inplace=True)
# 5. Pivot to get weekly columns as features
historical_weekly_stock_df = (
    historical_weekly_stock_df
    .pivot_table(index=['LOCATION_CODE', 'SKU_CODE'],
                 columns='ISO_YYYYWW',
                 values='CURRENT_STORE_STOCK',
                 aggfunc='first',  # Use first as only one record per week
                 fill_value=0)
    .reset_index()
)
# 6. Rename columns to add -HIST suffix
historical_weekly_stock_df.columns = [
    f"{col}-HIST" if col not in ['LOCATION_CODE', 'SKU_CODE'] else col
    for col in historical_weekly_stock_df.columns
]
historical_weekly_stock_df.drop(['2025-W32-HIST'], axis=1, inplace=True)
# 7. Optional drop current week if needed
# historical_weekly_stock_df.drop(['2025-W17-HIST'], axis=1, errors='ignore', inplace=True)

# 8. List historical stock columns
hist_stock_qty_cols = list(historical_weekly_stock_df.filter(regex=r'^\d{4}-W\d{2}-HIST$').columns)
print("HISTORICAL SKU Columns: ", hist_stock_qty_cols)

# 9. Final preview
historical_weekly_stock_df.head()


# COMMAND ----------

store_sku_df = pivot.merge(historical_weekly_stock_df, on=['LOCATION_CODE','SKU_CODE'], how='left')

# COMMAND ----------

store_sku_df['STOCK_LAST_2W'] =  store_sku_df[hist_stock_qty_cols[-2:]].sum(axis=1)

# COMMAND ----------

store_sku_df.head()

# COMMAND ----------

last_week_col = weekly_sales_qty_cols[-1]
year, week = map(int, last_week_col.split('-W'))
last_week_monday = date.fromisocalendar(year, week, 1)
next_week_monday = last_week_monday + timedelta(days=7)
next_year, next_week, _ = next_week_monday.isocalendar()
next_week_col = f'FORECAST_{next_year}-W{next_week:02d}'

# COMMAND ----------

def forecast_fast_fashion(row):
    # Handle stockout fallback
    if row['ROS3']>=0.2:
        predicted_qty = round(row['ROS3']*1.50 *7)
        if row[weekly_sales_qty_cols[-1]] > predicted_qty:
            return row[weekly_sales_qty_cols[-1]] 
        else:
            return predicted_qty
    
    recent_sales = row[weekly_sales_qty_cols[-2:]].sum()
    if row['STOCK_LAST_2W'] == 0 or np.isnan(row['ROS3']) or row['ROS3']==0:
        ros_recent = row['ROS2'] * 1.5 * 0.7  # fallback if stockout
    else:
        ros_recent = row['ROS3'] * 1.5    
    # Weighted ROS
    final_ros = 0.7 * ros_recent + 0.3 * row['ROS2'] + 0.1 * row['ROS1']
    forecast = np.round(final_ros * 7)
    if recent_sales > 0:
        return max(forecast, 1)
    return forecast

# COMMAND ----------

store_sku_df[next_week_col] = store_sku_df.apply(forecast_fast_fashion, axis=1)

# COMMAND ----------

store_sku_df[hist_stock_qty_cols] = store_sku_df[hist_stock_qty_cols].fillna(0)

# COMMAND ----------

store_sku_df['NON_ZERO_STOCK_WEEKS_4W'] = (store_sku_df[hist_stock_qty_cols[-4:]] > 0).sum(axis=1)

store_sku_df['AVG_CLOSING_STOCK_4W'] = (
    store_sku_df[hist_stock_qty_cols[-4:]].sum(axis=1) /
    store_sku_df['NON_ZERO_STOCK_WEEKS_4W'].replace(0, np.nan)
).fillna(0)

store_sku_df['BEST_SELLER_SCORE'] = store_sku_df[weekly_sales_qty_cols[-4:]].sum(axis=1) / store_sku_df['AVG_CLOSING_STOCK_4W']

# COMMAND ----------

store_sku_df['BEST_SELLER_SCORE'].fillna(0, inplace=True)
store_sku_df['BEST_SELLER_SCORE'] = store_sku_df['BEST_SELLER_SCORE'].replace(np.inf, 0)

# COMMAND ----------

store_sku_df['SELLER_TIER'] = pd.cut(
    store_sku_df['BEST_SELLER_SCORE'],
    bins=[-np.inf, 0.01, 0.1, 0.5, 1.0, 1.5, 3.0, np.inf],
    labels=[
        'No Sales',
        'Dead Stock',
        'Very Slow Mover',
        'Slow Mover',
        'Mid Seller',
        'Best Seller',
        'Top Seller'
    ]
)

# COMMAND ----------

# DBTITLE 1,UPDATING CURRENT STORE STOCK AND MIN AND MAX QUANITY STOCKS
current_stock_df = spark.sql("""
                            select 
                            LOCATION_CODE,
                            ITEMCODE as SKU_CODE,
                            Intransit_QTY AS INTRANSIT_QTY,
                            INTERNATIONAL_INTRANSIT_QTY AS FRGN_INTRANSIT,
                            LOCAL_INTRANSIT_QTY,
                            Open_QTY AS OPEN_QTY,
                            (IN_STOCK + INTRANSIT_QTY + Open_QTY) AS TOTAL_NEW_STORE_STOCK,
                            IN_STOCK as CURRENT_STORE_STOCK
                            from gold.`custom-analysis`.SKU_stock_intransit_op_cur_stock 
                            WHERE 
                            BRAND_NAME 
                            IN 
                            ('RIVA','CHOICE', 'RIVA KIDS')
                            """).toPandas()

min_max_qty_df = spark.sql(f"""Select distinct GROUP_NAME,SCALE_CODE SIZE_GROUP, SIZE_CODE,SHOP_GRADE GRADE, MINQTY,MAXQTY from gold.`custom-analysis`.wms_shop_distribution_Dup 
                           """).toPandas()
min_max_qty_df['MINQTY'] = min_max_qty_df['MINQTY'].astype(int)
min_max_qty_df['MAXQTY'] = min_max_qty_df['MAXQTY'].astype(int)

current_stock_df.head()

# COMMAND ----------

missing_df = missing_df[['GROUP_NAME','SIZE_GROUP','SIZE_CODE','GRADE','MIN_QTY','MAX_QTY']]

# COMMAND ----------

missing_df.rename({'MIN_QTY':'MINQTY','MAX_QTY':'MAXQTY'}, axis=1, inplace=True)

# COMMAND ----------

min_max_qty_df = pd.concat([min_max_qty_df,missing_df])

# COMMAND ----------

# min_max_qty_df.drop_duplicates(subset=['GROUP_NAME','SIZE_GROUP','SIZE_CODE','GRADE'], inplace=True)
min_max_qty_df.head()

# COMMAND ----------

sku_store_df = store_sku_df.merge(current_stock_df, on=['SKU_CODE', 'LOCATION_CODE'], how='left')
sku_store_df = sku_store_df.merge(min_max_qty_df, on=['GROUP_NAME','SIZE_GROUP','GRADE','SIZE_CODE'], how='left')
sku_store_df.head()

# COMMAND ----------

sku_store_df.loc[(sku_store_df['MINQTY'].isnull()) &
             (sku_store_df['GRADE']=='C'),['MINQTY','MAXQTY']] = [1,1] 

sku_store_df.loc[(sku_store_df['MINQTY'].isnull()) &
             (sku_store_df['GRADE']=='B'),['MINQTY','MAXQTY']] = [2,2] 

sku_store_df.loc[(sku_store_df['MINQTY'].isnull()) &
             (sku_store_df['GRADE']=='A'),['MINQTY','MAXQTY']] = [2,3] 

# COMMAND ----------

sku_store_df.isnull().sum()

# COMMAND ----------

size_code_stock_df = sku_store_df.groupby(['LOCATION_CODE','OPTION_CODE','SIZE_CODE'], as_index=False).agg({'TOTAL_NEW_STORE_STOCK':'sum'})

option_stock_df = (
    size_code_stock_df
    .groupby(['LOCATION_CODE', 'OPTION_CODE'])['TOTAL_NEW_STORE_STOCK']
    .sum()
    .reset_index()
    .rename(columns={'TOTAL_NEW_STORE_STOCK': 'OPTION_TOTAL_STOCK'})
)
option_stock_df

# COMMAND ----------

sku_store_df = sku_store_df.merge(option_stock_df, on=['LOCATION_CODE', 'OPTION_CODE'], how='left')
sku_store_df.head()

# COMMAND ----------

sku_store_df.loc[
    (sku_store_df[next_week_col] == 0) &
    (sku_store_df['TOTAL_NEW_STORE_STOCK'] == 0) &
    (sku_store_df['OPTION_TOTAL_STOCK'] > 0),
    next_week_col
] = sku_store_df.loc[
    (sku_store_df[next_week_col] == 0) &
    (sku_store_df['TOTAL_NEW_STORE_STOCK'] == 0) &
    (sku_store_df['OPTION_TOTAL_STOCK'] > 0),
    'MINQTY'
]

# COMMAND ----------

warehouse_qty_df = warehouse_sku_df.groupby(['WAREHOUSE_CODE','SKU_CODE','COUNTRY'],as_index=False).agg({'WH_QTY':'sum'})

# COMMAND ----------

# --- 1.  Attach warehouse stock -------------------------------------------
final_sku_stock_df = (sku_store_df
      .merge(warehouse_qty_df[['WAREHOUSE_CODE','SKU_CODE','COUNTRY','WH_QTY']],
             on=['COUNTRY', 'SKU_CODE'],
             how='left')
      .fillna({'WH_QTY': 0}))


# COMMAND ----------

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='KUWAIT'),
                   'WAREHOUSE_CODE'
                   ] = 'K9901'

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='BAHRAIN'),
                   'WAREHOUSE_CODE'
                   ] = 'B97'

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='UAE'),
                   'WAREHOUSE_CODE'
                   ] = 'U019901'

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='SAUDI ARABIA'),
                   'WAREHOUSE_CODE'
                   ] = 'S99'


final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='QATAR'),
                   'WAREHOUSE_CODE'
                   ] = 'Q9901'

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='OMAN'),
                   'WAREHOUSE_CODE'
                   ] = 'O019901'

# COMMAND ----------

final_sku_stock_df.groupby(['LOCATION_CODE', 'SKU_CODE']).size().reset_index(name='count').sort_values('count', ascending=False)

# COMMAND ----------

final_sku_stock_df

# COMMAND ----------

WEEK_COLS = weekly_sales_qty_cols.copy()
STOCK_COLS = list(hist_stock_qty_cols).copy()

pairwise_good = [
    final_sku_stock_df[week].where(final_sku_stock_df[stock] > 0, 0)          # keep sales only if opening stock > 0
    for week, stock in zip(WEEK_COLS, STOCK_COLS)
]
good_sales_total = pd.concat(pairwise_good, axis=1).sum(axis=1)
good_weeks_count = (final_sku_stock_df[STOCK_COLS] > 0).sum(axis=1)       # how many weeks had stock

# daily ROS = total sales / (good_weeks × 7)
final_sku_stock_df["ROS_DAY"] = (
    good_sales_total /
    (good_weeks_count.replace(0, np.nan) * 7)
).fillna(0)

miss_mask          = final_sku_stock_df[STOCK_COLS].eq(0) & final_sku_stock_df[WEEK_COLS].eq(0)
miss_weeks_cnt     = miss_mask.sum(axis=1)
# final_sku_stock_df["MISSED_UNITS"]  = (final_sku_stock_df["ROS_DAY"] * 7 * miss_weeks_cnt).round()

# COMMAND ----------

final_sku_stock_df = final_sku_stock_df.merge(host_warehouse_stock[['SKU_CODE','HOSTWATEHOUSE_STOCK']], how='left')
final_sku_stock_df.head()

# COMMAND ----------

condition = (
    (final_sku_stock_df['STOCK_LAST_2W'] == 0) &
    (final_sku_stock_df[next_week_col] == 0) &
    ((final_sku_stock_df['WH_QTY'] + final_sku_stock_df['HOSTWATEHOUSE_STOCK']) > 0) &
    (final_sku_stock_df['ROS_DAY'] > 0.1)
)


final_sku_stock_df.loc[condition,next_week_col] = np.round(final_sku_stock_df.loc[condition,'ROS_DAY'] * 7)

# COMMAND ----------

broken_return_option_df.head()

# COMMAND ----------

return_sku_df = spark.sql("""
                          SELECT 
                          SKU_CODE,
                          OPTION_CODE,
                          SIZE_CODE,
                          FROM_LOCATION AS LOCATION_CODE,
                          TO_LOCATION,
                          TRANSFER_TYPE
                           FROM gold.`custom-analysis`.oi_cardex_dup
                           WHERE
                           rn = 1
                           AND
                           TRANSFER_TYPE='TRANSFER OUT'
                           """).toPandas()

# COMMAND ----------

return_sku_df = return_sku_df[['LOCATION_CODE','SKU_CODE','TRANSFER_TYPE']].drop_duplicates()

# COMMAND ----------

final_sku_stock_df.shape

# COMMAND ----------

final_sku_stock_df = final_sku_stock_df.merge(return_sku_df[['LOCATION_CODE','SKU_CODE','TRANSFER_TYPE']], on=['LOCATION_CODE','SKU_CODE'], how='left')
final_sku_stock_df.head()

# COMMAND ----------

final_sku_stock_df['GRADE'].value_counts()

# COMMAND ----------

# final_sku_stock_df = final_sku_stock_df.merge(broken_return_option_df, on=['LOCATION_CODE','OPTION_CODE'], how='left')
# final_sku_stock_df.head()

# COMMAND ----------

final_sku_stock_df.loc[final_sku_stock_df['TRANSFER_TYPE']=='TRANSFER OUT',next_week_col] = 0

# COMMAND ----------

# final_sku_stock_df.loc[
#     (final_sku_stock_df['healthy_cov'].notnull()),
#     next_week_col
#     ] = 0

# COMMAND ----------

final_sku_stock_df = final_sku_stock_df.drop_duplicates()

# COMMAND ----------

import numpy as np

final_sku_stock_df['MAXQTY'] = np.where(
    (final_sku_stock_df['SELLER_TIER'].isin(['Top Seller', 'Best Seller'])) & (final_sku_stock_df[next_week_col] > final_sku_stock_df["MAXQTY"]),
    final_sku_stock_df[next_week_col],
    final_sku_stock_df["MAXQTY"]
)

# COMMAND ----------

#final_sku_stock_df.loc[final_sku_stock_df['MAXQTY']>=4,'MAXQTY'] = 4

# COMMAND ----------

MISSED_LAMBDA = 0.20                             # weight on missed units
# High‑priority order: lower number = higher priority
STORE_PRIORITY_MAP = {"A": 0, "B": 1, "C": 2, "OUTLET": 3}

# COMMAND ----------

final_sku_stock_df["PRIORITY_RANK"]  = final_sku_stock_df["GRADE"].map(STORE_PRIORITY_MAP).fillna(99).astype(int)

# COMMAND ----------

mask = ((final_sku_stock_df[next_week_col]>0) & (final_sku_stock_df[next_week_col]<final_sku_stock_df['MINQTY']))
final_sku_stock_df.loc[mask,next_week_col] = final_sku_stock_df.loc[mask,'MINQTY']

# COMMAND ----------

# mask = ((final_sku_stock_df[next_week_col]>0) & (final_sku_stock_df[next_week_col]>=3) & (final_sku_stock_df['SELLER_TIER'].isin(['Top Seller','Best Seller'])))
# final_sku_stock_df.loc[mask,next_week_col] = final_sku_stock_df.loc[mask,'MAXQTY']

# COMMAND ----------

def round_up_to_next_12(x):
    return int(np.ceil(x / 12.0)) * 12 if x > 0 else 0

# COMMAND ----------

final_sku_stock_df.loc[(final_sku_stock_df[next_week_col]==1),next_week_col]=2

# COMMAND ----------

mask_a = (
    final_sku_stock_df['GRADE'].eq('A')
    & final_sku_stock_df['GROUP_NAME'].isin(['SCARF', 'ACCESSORIES', 'JEWELRY']) 
    & (final_sku_stock_df[next_week_col]>0)
)
final_sku_stock_df.loc[mask_a, next_week_col] = np.where(
    final_sku_stock_df.loc[mask_a, next_week_col] > 5, 10, 5
)

mask_b = (
    final_sku_stock_df['GRADE'].eq('B')
    & final_sku_stock_df['GROUP_NAME'].isin(['SCARF', 'ACCESSORIES', 'JEWELRY']) 
    & (final_sku_stock_df[next_week_col]>0)
)
final_sku_stock_df.loc[mask_b, next_week_col] = np.where(
    final_sku_stock_df.loc[mask_b, next_week_col] > 3, 6, 3
)

mask_c = (
    final_sku_stock_df['GRADE'].eq('C')
    & final_sku_stock_df['GROUP_NAME'].isin(['SCARF', 'ACCESSORIES', 'JEWELRY']) 
    & (final_sku_stock_df[next_week_col]>0)
)
final_sku_stock_df.loc[mask_c, next_week_col] = np.where(
    final_sku_stock_df.loc[mask_c, next_week_col] > 3, 3, 3
)

mask_a = (
    final_sku_stock_df['GRADE'].eq('A')
    & final_sku_stock_df['GROUP_NAME'].isin(['SCARF', 'ACCESSORIES', 'JEWELRY']) 
)

mask_b = (
    final_sku_stock_df['GRADE'].eq('B')
    & final_sku_stock_df['GROUP_NAME'].isin(['SCARF', 'ACCESSORIES', 'JEWELRY']) 
)

mask_c = (
    final_sku_stock_df['GRADE'].eq('C')
    & final_sku_stock_df['GROUP_NAME'].isin(['SCARF', 'ACCESSORIES', 'JEWELRY']) 
)

final_sku_stock_df.loc[mask_a,['MINQTY','MAXQTY']] = [5, 10]
final_sku_stock_df.loc[mask_b,['MINQTY','MAXQTY']] = [3, 6]
final_sku_stock_df.loc[mask_c,['MINQTY','MAXQTY']] = [3, 3]

# COMMAND ----------

final_sku_stock_df.loc[(final_sku_stock_df['LOCATION_CODE'].isin(['16','13'])) & (final_sku_stock_df[next_week_col]>0), next_week_col] = 1

# COMMAND ----------

final_sku_stock_df["RAW_NEED"] = (final_sku_stock_df[next_week_col].astype(float) - final_sku_stock_df["TOTAL_NEW_STORE_STOCK"].astype(float)).clip(lower=0)
#final_sku_stock_df["ADJ_NEED"] = final_sku_stock_df["RAW_NEED"].astype(float) + final_sku_stock_df["MISSED_UNITS"].astype(float)

# COMMAND ----------

mask = (
    (final_sku_stock_df['GROUP_NAME'] == 'BATH AND BODY|HOME FRAGRANCE') &
    (final_sku_stock_df['RAW_NEED'] > 0)
)

final_sku_stock_df.loc[mask, 'RAW_NEED'] =final_sku_stock_df.loc[mask, 'RAW_NEED'].apply(round_up_to_next_12)

# COMMAND ----------

final_sku_stock_df.loc[(final_sku_stock_df['LOCATION_CODE'].isin(['16','13'])) &
(final_sku_stock_df['GROUP_NAME'] == 'BATH AND BODY|HOME FRAGRANCE'),'RAW_NEED'] = 0

# COMMAND ----------

# def compute_need(adj, lo, hi):
#     if adj == 0:
#         return 0                               # ① no demand
#     elif adj <=lo:
#         return lo                              # ② bump up to minimum
#     elif adj >= hi:
#         return hi                              # ③ cap at maximum
#     else:
#         return adj                             # ④ use adj as‑is

final_sku_stock_df["NEED"] = final_sku_stock_df['RAW_NEED']

# COMMAND ----------

# final_sku_stock_df[]

# COMMAND ----------

final_sku_stock_df.loc[(final_sku_stock_df['TOTAL_NEW_STORE_STOCK']>final_sku_stock_df['MAXQTY'])
                       & (final_sku_stock_df['NEED']>0)
                       ,'NEED'] = 0

# COMMAND ----------

# DBTITLE 1,SALES FROM FIRST TRANSFER TO TILL CURRENT DATE
first_sale_to_last_sale_df = spark.sql(
    """
        SELECT 
        LOCATION_CODE, SKU_CODE,
        SUM(TOTAL_QUANTITY) AS TOTAL_QTY_SOLD
        FROM gold.`custom-analysis`.sku_clustering_temp_sales_transfer
        WHERE 
        BRAND_NAME in ('RIVA','CHOICE','RIVA KIDS')
        GROUP BY
        SKU_CODE, LOCATION_CODE
    """).toPandas()

region_wise_sku_performance = spark.sql(
    """
        SELECT 
        COUNTRY, SKU_CODE,
        SUM(TOTAL_QUANTITY) AS TOTAL_QTY_SOLD_REGION
        FROM gold.`custom-analysis`.sku_clustering_temp_sales_transfer
        WHERE 
        BRAND_NAME in ('RIVA','CHOICE','RIVA KIDS')
        GROUP BY
        SKU_CODE, COUNTRY
    """).toPandas()

final_sku_stock_df = final_sku_stock_df.merge(first_sale_to_last_sale_df, on=['LOCATION_CODE','SKU_CODE'], how='left')
final_sku_stock_df = final_sku_stock_df.merge(region_wise_sku_performance, on=['COUNTRY','SKU_CODE'], how='left')
final_sku_stock_df['SALES_MIX'] = final_sku_stock_df['TOTAL_QTY_SOLD'] / final_sku_stock_df['TOTAL_QTY_SOLD_REGION']

# COMMAND ----------

region_demand_df = final_sku_stock_df.groupby(['COUNTRY','SKU_CODE'], as_index = False).agg({next_week_col:'sum'}).rename({next_week_col:'REGION_DEMAND'}, axis=1)
final_sku_stock_df = final_sku_stock_df.merge(region_demand_df, on=['COUNTRY','SKU_CODE'], how='left')
final_sku_stock_df['REGION_DEMAND_CONT'] = (final_sku_stock_df[next_week_col] / final_sku_stock_df['REGION_DEMAND']).fillna(0)

# COMMAND ----------

final_sku_stock_df.head()

# COMMAND ----------

df = final_sku_stock_df.copy()

# ---- 1. Normalised drivers (all 0–1 already) --------------------------

df['VELOCITY_IDX']      = df['TOTAL_QTY_SOLD']          / df['TOTAL_QTY_SOLD_REGION']        # how fast it moves locally
df['SALES_MIX_IDX']     = df['SALES_MIX']                                                     # share in the store basket
df['DEMAND_GAP_IDX']    = ((df['REGION_DEMAND'].astype(float) - df['TOTAL_QTY_SOLD'].astype(float))
                            .clip(lower=0) / df['REGION_DEMAND'])                             # unmet demand
df['CONTRIB_IDX']       = df['REGION_DEMAND_CONT'].astype(float)                                    # store’s weight in region

# tidy up any divide-by-zero or NaN
df[['VELOCITY_IDX','DEMAND_GAP_IDX']] = df[['VELOCITY_IDX','DEMAND_GAP_IDX']].fillna(0)

# ---- 2. Composite priority score --------------------------------------

df['SKU_PRIORITY'] = (
      0.40 * df['VELOCITY_IDX'].astype(float)        # keep fast movers stocked
    + 0.30 * df['SALES_MIX_IDX'].astype(float)       # protect key basket items
    + 0.20 * df['DEMAND_GAP_IDX'].astype(float)      # chase remaining demand
    + 0.10 * df['CONTRIB_IDX'].astype(float)         # honour regional hotspots
) * 100                                # scale to 0-100 for easy reading

# ---- 3. Easy-to-read tier label ---------------------------------------

df['PRIORITY_TIER'] = pd.cut(
    df['SKU_PRIORITY'],
    bins=[-1,20,40,60,80,100],
    labels=['Skip','Low','Medium','High','Top-Up NOW'],
    right=False
)

# ---- 4. View for planners ---------------------------------------------

priority_view = (df
    .sort_values(['SKU_PRIORITY','SKU_CODE'], ascending=[False,True])
    [['LOCATION_CODE','SKU_CODE','SKU_PRIORITY','PRIORITY_TIER']]
)


# COMMAND ----------

df.sort_values('SKU_PRIORITY', ascending=False)

# COMMAND ----------

final_sku_stock_df = df.sort_values('SKU_PRIORITY', ascending=False)

# COMMAND ----------

final_sku_stock_df.sort_values(["COUNTRY","SKU_CODE",
               "PRIORITY_RANK","ROS3",'SKU_PRIORITY'],
              ascending=[True,True,True,False,False],
              inplace=True)

# COMMAND ----------

final_sku_stock_df.head()

# COMMAND ----------

from pyspark.sql.functions import collect_list

# Step 1: Run SQL query
nonrepl_items_df = spark.sql("""
    SELECT 
    LOCATION_CODE AS FROM_LOCATION,
    ITEMCODE, TO_LOC 
    FROM bronze.orjwan.OI_NONREPL_ITEMS 
    WHERE LOCATION_CODE IN ('K9901', 'O019901', 'S99', 'U019901', 'B97','Q9901') AND  LOCATION_CODE is not  NULL
""")

# Step 2: Group by TO_LOC and collect ITEMCODE as list
grouped_df = nonrepl_items_df.groupBy(['FROM_LOCATION',"TO_LOC"]).agg(collect_list("ITEMCODE").alias("ITEMCODES"))

# Step 3: Convert to dictionary: {TO_LOC: [ITEMCODE1, ITEMCODE2, ...]}
to_loc_dict = {
    row['FROM_LOCATION']: row['ITEMCODES']
    for row in grouped_df.collect()
}

# COMMAND ----------

to_loc_dict.keys()

# COMMAND ----------

def allocate(group: pd.DataFrame) -> pd.DataFrame:
    stock_left = int(group["WH_QTY"].iloc[0])
    alloc, unful = [], []

    for _, r in group.iterrows():
        if r['SKU_CODE'] in to_loc_dict.get(r['WAREHOUSE_CODE'], []):
            need = int(r["NEED"])
            qty = 0 # min(need, stock_left)
            stock_left -= qty
            alloc.append(int(qty))
            unful.append(int(need - qty))
        else:       
            need = int(r["NEED"])
            qty = min(need, stock_left)
            stock_left -= qty
            alloc.append(int(qty))
            unful.append(int(need - qty))
        
        out = group.copy()
    out["REPLENISHED_QTY"]       = alloc
    out["UNFULFILLED_QTY"] = unful
    return out


# COMMAND ----------

result = (final_sku_stock_df.groupby(["COUNTRY","SKU_CODE"], group_keys=False)
            .apply(allocate))

# COMMAND ----------

result.loc[
    (result['LOCATION_CODE'].isin(['K1001','K1005'])) &
    (result['OPTION_CODE']=='105124-23004-A23'),:
]

# COMMAND ----------

result['HOSTWATEHOUSE_STOCK'].fillna(0, inplace=True)

# COMMAND ----------

result.head()

# COMMAND ----------

# def allocate_from_donors(dest_row, donors):
#     """
#     Fill dest_row.UNFULFILLED_QTY using donors in the same COUNTRY & SKU_CODE.
#     Returns: list of transfer dicts and qty_filled (int).
#     """
#     need          = int(dest_row.UNFULFILLED_QTY)
#     if need == 0:
#         return [], 0

#     # match on COUNTRY & SKU_CODE; you may add SIZE_CODE if needed
#     mask = (
#         (donors["COUNTRY"]   == dest_row.COUNTRY) &
#         (donors["SKU_CODE"]  == dest_row.SKU_CODE) &
#         (donors["AVAILABLE_QTY"] > 0) &
#         (donors["LOCATION_CODE"] != dest_row.LOCATION_CODE)   # avoid self-transfer
#     )
#     pool = donors.loc[mask].sort_values("AVAILABLE_QTY", ascending=False)

#     transfers = []
#     for idx, src in pool.iterrows():
#         take = min(need, int(src.AVAILABLE_QTY))
#         if take == 0:
#             continue

#         # register the move
#         transfers.append({
#             "COUNTRY"           : src.COUNTRY,
#             "FROM_LOCATION"     : src.LOCATION_CODE,
#             "SRC_LAST_2_WEEK_SALES_QTY": sum([src[col] for col in WEEK_COLS[-2:]]),
#             'SRC_OPEN_QTY_+_INTRANSIT'      : src.OPEN_QTY + src.INTRANSIT_QTY,
#             'SRC_CURRENT_STOCK'     :src.CURRENT_STORE_STOCK,

#             "TO_LOCATION"       : dest_row.LOCATION_CODE,
#             "SKU_CODE"          : src.SKU_CODE,
#             "SIZE_CODE"         : src.SIZE_CODE,
#             "TRANSFER_DATE"     : pd.Timestamp(date.today()).normalize(),
            
#             'DES_LAST_2_SALES_WEEK_QTY': sum([dest_row[col] for col in WEEK_COLS[-2:]]),
#             "DES_OPEN_QTY_+_INTRANSIT"      :dest_row.OPEN_QTY + dest_row.INTRANSIT_QTY,
#             'DES_CURRENT_STOCK' :dest_row.CURRENT_STORE_STOCK,
#             "QUANTITY_TRANSFERED": take,
#             "TRANSFER_TYPE"     : "STORE-STORE TRANSFER",

            

#         })

#         # update running state
#         donors.at[idx, "AVAILABLE_QTY"] -= take
#         need -= take
#         if need == 0:
#             break

#     qty_filled = dest_row.UNFULFILLED_QTY - need
#     return transfers, qty_filled


# COMMAND ----------

# mask = result["LOCATION_CODE"].isin(['K1005','K1003','K1603','K1605','K1608','K1201','K1001','K1602','K1002'])

# result.loc[mask, 'REPLENISHED_QTY'] = 0
# result.loc[mask, 'UNFULFILLED_QTY'] = result.loc[mask, 'NEED']

# buffer_stock_pick = result[(result["UNFULFILLED_QTY"] > 0) & mask].copy()
# buffer_stock_pick.head()

# region_alloc_qty_df = result.groupby(['COUNTRY','SKU_CODE'], as_index=False).agg({'REPLENISHED_QTY':'sum'}).rename({'REPLENISHED_QTY':'TOTAL_ALLOCATED_REGION_QTY'}, axis=1)
# buffer_stock_pick_df = pd.merge(buffer_stock_pick, region_alloc_qty_df, on=['SKU_CODE','COUNTRY'], how='left')



# warehouse_sku_kuwait_df = spark.sql("""
#           SELECT 
#           distinct
#           SKU_CODE,
#           COUNTRY,
#           WAREHOUSE_STOCK_2 as STOCK_WITH_BUFFER
#           FROM 
#           gold.`custom-analysis`.SKU_BOX_QUANTITY
#           where LOCATION_CODE = 'K9901'
#           """).toPandas()

# buffer_stock_pick_df = pd.merge(buffer_stock_pick_df, warehouse_sku_kuwait_df, on=['SKU_CODE','COUNTRY'], how='left') 
# buffer_stock_pick_df['NEW_STOCK'] = buffer_stock_pick_df['STOCK_WITH_BUFFER'] - buffer_stock_pick_df['TOTAL_ALLOCATED_REGION_QTY']
# buffer_stock_pick_df.loc[buffer_stock_pick_df['NEW_STOCK'].isnull(), 'NEW_STOCK'] = 0

# def host_min_max(group: pd.DataFrame) -> pd.DataFrame:
#     host_left = int(group["NEW_STOCK"].iloc[0])
#     host_alloc = []

#     for _, r in group.iterrows():
#         need = int(r["UNFULFILLED_QTY"])
#         lo   = int(r["MINQTY"])
#         hi   = int(r["MAXQTY"])

#         if need == 0 or host_left == 0:
#             q = 0
#         else:
#             q = min(need, host_left)          # attempt
#             # bump up to MIN if feasible
#             if 0 < q < lo <= host_left:
#                 q = need
#             # cap at MAX
#             q = min(q, 100000)
#         host_left -= q
#         host_alloc.append(q)

#     out = group.copy()
#     out["BUFFER_ALLOCATED_QTY"] = host_alloc
#     return out


# buffer_stock_pick_df = (
#     buffer_stock_pick_df.groupby(["SKU_CODE"], group_keys=False)
#          .apply(host_min_max)
# )

# COMMAND ----------

# buffer_stock_pick_df['REPLENISHED_QTY'] =  buffer_stock_pick_df['BUFFER_ALLOCATED_QTY']

# COMMAND ----------


# buffer_stock_pick_df["UNFULFILLED_QTY"] = (
#         buffer_stock_pick_df["UNFULFILLED_QTY"] - buffer_stock_pick_df["BUFFER_ALLOCATED_QTY"]
# ).clip(lower=0)

# COMMAND ----------

# buffer_stock_pick_df

# COMMAND ----------

# buffer_stock_pick_df.to_csv("buffer_stock_reduce_selected_stores_old_season.csv", index=False)

# COMMAND ----------

short = result[result["UNFULFILLED_QTY"] > 0].copy()

# COMMAND ----------

# 2. Bring host stock per SKU‑size (sum of free pieces)
host = (short
        .groupby(["SKU_CODE"], as_index=False)
        .agg(HOST_STK=("HOSTWATEHOUSE_STOCK","first")))   # one number per SKU‑size


# COMMAND ----------

host

# COMMAND ----------

short = (short
         .merge(host, on=["SKU_CODE"], how="left")
         .sort_values(["SKU_CODE","PRIORITY_RANK"]))

# COMMAND ----------

short

# COMMAND ----------

def host_allocate(g: pd.DataFrame) -> pd.DataFrame:
    host_left = int(g["HOST_STK"].iloc[0])
    host_alloc = []

    for _, r in g.iterrows():
        need = int(r["UNFULFILLED_QTY"])
        q    = min(need, host_left)
        host_left -= q
        host_alloc.append(q)

    g = g.copy()
    g["HOST_ALLOC_QTY"] = host_alloc
    g["HOST_LEFT_AFTER"] = host_left  # audit
    return g

# COMMAND ----------

short.head()

# COMMAND ----------

short = (short
         .groupby(["SKU_CODE",], group_keys=False)
         .apply(host_allocate))


# COMMAND ----------

from pyspark.sql.functions import collect_list

# Step 1: Run SQL query
nonrepl_items_df = spark.sql("""
    SELECT 
    LOCATION_CODE AS FROM_LOCATION,
    ITEMCODE, TO_LOC 
    FROM bronze.orjwan.OI_NONREPL_ITEMS 
    WHERE LOCATION_CODE IN ('101') AND TO_LOC IS NOT NULL
""")

# Step 2: Group by TO_LOC and collect ITEMCODE as list
grouped_df = nonrepl_items_df.groupBy("TO_LOC").agg(collect_list("ITEMCODE").alias("ITEMCODES"))

# Step 3: Convert to dictionary: {TO_LOC: [ITEMCODE1, ITEMCODE2, ...]}
to_loc_dict = {
    row['TO_LOC']: row['ITEMCODES']
    for row in grouped_df.collect()
}

# COMMAND ----------

# def host_min_max(group: pd.DataFrame) -> pd.DataFrame:
#     host_left = int(group["HOST_STK"].iloc[0])
#     host_alloc = []

#     for _, r in group.iterrows():
#         need = int(r["UNFULFILLED_QTY"])
#         lo   = int(r["MINQTY"])
#         hi   = int(r["MAXQTY"])
#         sku_code = r['SKU_CODE']

#         warehouse_code = r['WAREHOUSE_CODE']
#         if sku_code in  to_loc_dict.get(warehouse_code, []):
#             host_alloc.append(0)
#             continue
#         if need == 0 or host_left == 0:
#             q = 0
#         else:
#             q = min(need, host_left)          # attempt
#             # bump up to MIN if feasible
#             if 0 < q < lo <= host_left:
#                 q = need
#             # cap at MAX
#             q = min(q, 100000)
#         host_left -= q
#         host_alloc.append(q)

#     out = group.copy()
#     out["HOST_ALLOC_QTY"] = host_alloc
#     return out

# COMMAND ----------

# short = (
#     short.groupby(["SKU_CODE"], group_keys=False)
#          .apply(host_min_max)
# )

# COMMAND ----------

short[short['HOST_ALLOC_QTY']>0]

# COMMAND ----------

result_temp = result.merge(
    short[["COUNTRY","LOCATION_CODE","SKU_CODE","HOST_ALLOC_QTY"]],
    on=["COUNTRY","LOCATION_CODE","SKU_CODE"],
    how="left"
).fillna({"HOST_ALLOC_QTY": 0})

# COMMAND ----------

# final numbers
result_temp["REPLENISHED_QTY"]   = result_temp["REPLENISHED_QTY"] + result_temp["HOST_ALLOC_QTY"]
result_temp["UNFULFILLED_QTY"] = (
        result_temp["UNFULFILLED_QTY"] - result_temp["HOST_ALLOC_QTY"]
).clip(lower=0)

# COMMAND ----------

# from pyspark.sql.functions import collect_list

# # Step 1: Run SQL query
# nonrepl_items_df = spark.sql("""
#     SELECT 
#     LOCATION_CODE AS FROM_LOCATION,
#     ITEMCODE, TO_LOC 
#     FROM bronze.orjwan.OI_NONREPL_ITEMS 
#     WHERE LOCATION_CODE IN ('K9901', 'O019901', 'S99', 'U019901', 'B97','Q9901') AND  LOCATION_CODE is not  NULL
# """)

# # Step 2: Group by TO_LOC and collect ITEMCODE as list
# grouped_df = nonrepl_items_df.groupBy(['FROM_LOCATION',"TO_LOC"]).agg(collect_list("ITEMCODE").alias("ITEMCODES"))

# # Step 3: Convert to dictionary: {TO_LOC: [ITEMCODE1, ITEMCODE2, ...]}
# to_loc_dict = {
#     row['FROM_LOCATION']: row['ITEMCODES']
#     for row in grouped_df.collect()
# }

# COMMAND ----------

result_temp['REPLENISHING_WAREHOUSE'] = np.nan

# COMMAND ----------

result_temp.loc[result_temp['HOST_ALLOC_QTY']>0,'REPLENISHING_WAREHOUSE'] = "101"

# COMMAND ----------

result_temp.loc[
    (result_temp['HOSTWATEHOUSE_STOCK']==0) &
    (result_temp['REPLENISHED_QTY']>0), 
    "REPLENISHING_WAREHOUSE"
] = result_temp.loc[
    (result_temp['HOSTWATEHOUSE_STOCK']==0) &
    (result_temp['REPLENISHED_QTY']>0), 
    "WAREHOUSE_CODE"]

# COMMAND ----------

mask = (result_temp['HOST_ALLOC_QTY']==0) & (result_temp['REPLENISHED_QTY']>0)
result_temp.loc[mask,'REPLENISHING_WAREHOUSE'] = result_temp.loc[mask,'WAREHOUSE_CODE']      

# COMMAND ----------

store_to_store_transfer_ds = result_temp.copy()

# COMMAND ----------

store_to_store_transfer_ds.to_csv("replenishment_history/old_season_sept_17_2025.csv", index=False)

# COMMAND ----------

#upload_file(store_to_store_transfer_ds,'store_to_store_transfer_ds')

# COMMAND ----------

import boto3
import datetime
def upload_file(df,file_name):
    df.reset_index(inplace=True)
    file_path = f'{file_name}_{str(datetime.datetime.now().time())}.csv'
    df.to_csv(file_path,index=False)
    access_key_id = "GOOG1E6IFCXNK7S7SIRIU2ZB3DZ5KZYETNXCZ7FCOPF3PZP2UWSI2TBYNGTWQ"
    secret_access_key = "WLbR0N3jp5iRCgGA0MJpzhOI6Bes4alRfpM5GI1g"
    s3_client = boto3.client(
        's3',
        aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key,
        endpoint_url="https://storage.googleapis.com"  # Google Cloud Storage endpoint for S3 API
    )

    bucket_name = "armada-gcs-ml-0001"
    object_name = file_path
    local_file_path = file_path

    # Upload the file
    with open(local_file_path, "rb") as data:
        s3_client.upload_fileobj(data, bucket_name, object_name)

# COMMAND ----------

result_temp.head()

# COMMAND ----------

# result_temp.drop(['TO_LOCATION'], axis=1, inplace=True)

# COMMAND ----------

# result_temp.to_csv("sku_replenishment_new.csv", )

# COMMAND ----------

# result_temp[(result_temp['LOCATION_CODE']=='R04') & (result_temp['SKU_CODE']=='101105-25065-502-LRG')] 

# COMMAND ----------

result_temp.head()

# COMMAND ----------

result_temp[(result_temp['OPTION_CODE']=='108101-24005-005') & (result_temp['LOCATION_CODE']=='K1002') ]

# COMMAND ----------

result_temp.drop(['PRIORITY_RANK','RAW_NEED','TOTAL_QTY_SOLD','TOTAL_QTY_SOLD_REGION','SALES_MIX','REGION_DEMAND','REGION_DEMAND_CONT','VELOCITY_IDX','SALES_MIX_IDX','DEMAND_GAP_IDX','CONTRIB_IDX',
                      'NON_ZERO_STOCK_WEEKS_4W',	'AVG_CLOSING_STOCK_4W','STOCK_LAST_2W',
                  ], axis=1, inplace=True)

# COMMAND ----------

result_temp.loc[
    (result_temp['LOCATION_CODE']=='K1005') &
    (result_temp['SKU_CODE']=='101101-25013-516-MED'),:
]

# COMMAND ----------

result_temp.rename({'LOCATION_CODE':'TO_LOCATION','REPLENISHING_WAREHOUSE':'FROM_LOCATION'}, axis=1, inplace=True)

# COMMAND ----------

result_temp.loc[(result_temp['REPLENISHED_QTY']>0)& (result_temp['WH_QTY']>0),['FROM_LOCATION','TO_LOCATION','INTRANSIT_QTY','SKU_CODE','OPEN_QTY','TOTAL_NEW_STORE_STOCK','CURRENT_STORE_STOCK','MINQTY','MAXQTY']]

# COMMAND ----------

result_temp.loc[(result_temp['TO_LOCATION']=='D04') &
(result_temp['SKU_CODE'].str.contains('101101-25020')),['TO_LOCATION','SKU_CODE',next_week_col,'OPEN_QTY','INTRANSIT_QTY','CURRENT_STORE_STOCK','TOTAL_NEW_STORE_STOCK']]

# COMMAND ----------

#upload_file(result_temp, 'result_temp')

# COMMAND ----------

result_temp

# COMMAND ----------

result_temp[result_temp['NEED']>0]

# COMMAND ----------

replenishment_requieted_stores_df = result_temp[result_temp['NEED']>0].copy()
replenishment_requieted_stores_df['30DAYS_SALES'] = replenishment_requieted_stores_df[weekly_sales_qty_cols[-4:]].sum(axis=1)

# COMMAND ----------

replenishment_requieted_stores_df
# Get the second last column
second_last_col = replenishment_requieted_stores_df.columns[-2]

# Reorder columns
cols = [second_last_col] + [col for col in replenishment_requieted_stores_df.columns if col != second_last_col]

# Reassign the dataframe with reordered columns
replenishment_requieted_stores_df = replenishment_requieted_stores_df[cols]

# COMMAND ----------

final_temp_df = replenishment_requieted_stores_df[['FROM_LOCATION','TO_LOCATION','SKU_CODE','REPLENISHED_QTY','WH_QTY','30DAYS_SALES','MINQTY','MAXQTY','CURRENT_STORE_STOCK','LOCAL_INTRANSIT_QTY','FRGN_INTRANSIT','INTRANSIT_QTY','OPEN_QTY','HOST_ALLOC_QTY','HOSTWATEHOUSE_STOCK','COUNTRY']]
final_temp_df.head()

# COMMAND ----------

final_temp_df.shape

# COMMAND ----------

final_temp_df['FROM_LOCATION'].fillna('101', inplace=True)

# COMMAND ----------

final_temp_df.rename({'HOST_ALLOC_QTY':'REQ FOR 101',
                      'HOSTWATEHOUSE_STOCK':'HOST WH STK',
                      'OPEN_QTY':'OPENORDERQTY',
                      },
                    axis=1, inplace=True
                    )

# COMMAND ----------

final_temp_df = final_temp_df[final_temp_df['REPLENISHED_QTY']>0]

# COMMAND ----------

final_temp_df.shape

# COMMAND ----------

ss25_sku_df = pd.read_csv("ss.csv")
ss25_sku_df

# COMMAND ----------

ss25_sku_df = pd.read_csv("replenishment_aw25_report_sep_17_2025_v4.csv")
ss25_sku_df

# COMMAND ----------

df = pd.concat([final_temp_df,ss25_sku_df], ignore_index=True)
df

# COMMAND ----------

df.to_csv("combine_result_sep_17_v1.csv", index=False)

# COMMAND ----------

import os
import ssl
import socket
from ftplib import FTP_TLS, error_perm, all_errors

FTP_HOST = "3.120.129.102"
FTP_USER = "import"
FTP_PASS = "import9264!"
FTP_PORT = 21

LOCAL_FILE = "combine_result_sep_10_v1.csv"          # <-- set your CSV path
REMOTE_DIR = "/replenishment"
REMOTE_NAME = os.path.basename(LOCAL_FILE)

def ensure_remote_dir(ftps: FTP_TLS, remote_dir: str):
    remote_dir = remote_dir.strip().replace("\\", "/").strip("/")
    if not remote_dir:
        return
    for part in remote_dir.split("/"):
        try:
            ftps.cwd(part)
        except error_perm:
            try:
                ftps.mkd(part)
            except error_perm:
                pass  # already exists or no perms
            ftps.cwd(part)

def upload_csv():
    if not os.path.isfile(LOCAL_FILE):
        raise FileNotFoundError(f"Local file not found: {LOCAL_FILE}")

    # --- TLS context that accepts self-signed certs (UNVERIFIED) ---
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2

    # Fresh client; force IPv4 to avoid EPSV/IPv6 issues
    with FTP_TLS(context=ctx, timeout=60) as ftps:
        ftps.af = socket.AF_INET

        # Connect and do explicit FTPS handshake ONCE
        ftps.connect(FTP_HOST, FTP_PORT)
        ftps.auth()                 # secure control channel (AUTH TLS)
        ftps.login(FTP_USER, FTP_PASS)

        # Required by many FTPS servers
        ftps.sendcmd("PBSZ 0")
        ftps.prot_p()               # protect/encrypt data channel

        # Disable EPSV (common firewall/NAT fix). Ignore if unsupported.
        try:
            ftps.sendcmd("EPSV ALL")
        except all_errors:
            pass

        # Passive is usually safer through firewalls
        ftps.set_pasv(True)

        # Ensure target folder and upload
        ensure_remote_dir(ftps, REMOTE_DIR)
        with open(LOCAL_FILE, "rb") as f:
            ftps.storbinary(f"STOR " + REMOTE_NAME, f)

        print(f"✅ Uploaded '{LOCAL_FILE}' to '{REMOTE_DIR}/{REMOTE_NAME}'")

if __name__ == "__main__":
    upload_csv()


# COMMAND ----------

