# Databricks notebook source
import pandas as pd 
import numpy as np
import seaborn as sns
from typing import Dict
import datetime
from datetime import date, timedelta
import itertools   # only for create_map
from pyspark.sql.functions import col, date_format, weekofyear, year, lpad, concat_ws
from pyspark.sql import functions as F, DataFrame

# COMMAND ----------

return_option_df = spark.sql("""
WITH transfer_flags AS (
  SELECT 
    OPTION_CODE,
    FROM_LOCATION,
    MAX(CASE WHEN TRANSFER_TYPE = 'TRANSFER IN' THEN 1 ELSE 0 END) AS has_transfer_in
  FROM gold.`custom-analysis`.oi_cardex_dup
  GROUP BY OPTION_CODE, FROM_LOCATION
)

SELECT 
  a.*, 
  f.has_transfer_in
FROM gold.`custom-analysis`.oi_cardex_dup a
LEFT JOIN transfer_flags f
  ON a.OPTION_CODE = f.OPTION_CODE 
 AND a.FROM_LOCATION = f.FROM_LOCATION
 ORDER BY a.TRANS_DT DESC
""")

no_transfer_opts = return_option_df.groupBy("OPTION_CODE", "FROM_LOCATION") \
    .agg(F.max("has_transfer_in").alias("max_transfer")) \
    .filter("max_transfer = 0") \
    .select("OPTION_CODE", "FROM_LOCATION")
result_df = no_transfer_opts.join(return_option_df, on=["OPTION_CODE", "FROM_LOCATION"], how="left")
final_df = result_df.select("OPTION_CODE", "FROM_LOCATION", "HAS_TRANSFER_IN").distinct()
not_transfer_in_options_df = final_df.toPandas()

not_transfer_in_options_df.rename({'FROM_LOCATION': 'LOCATION_CODE'}, axis=1, inplace=True)

# COMMAND ----------

def apply_subwarehouse_uplift(
    current_df: DataFrame,
    sub_df: DataFrame,
    wh_to_store: Dict[str, str],
    agg_col: str = "TOTAL_NEW_STORE_STOCK",
    loc_col: str = "LOCATION_CODE",
    sku_col: str = "SKU_CODE",
) -> DataFrame:
    """
    Add sub-warehouse stock to the parent store’s total stock per SKU (Spark version).

    Parameters
    ----------
    current_df : pyspark.sql.DataFrame
        Store-level stock (includes K1003, K1004, …).
    sub_df : pyspark.sql.DataFrame
        Sub-warehouse stock (e.g. K9902, K9903).
    wh_to_store : dict
        {'K9902': 'K1003', 'K9903': 'K1004'}
    agg_col : str
        Column whose values need to be added to the parent store.
    loc_col / sku_col : str
        Column names for location and SKU.

    Returns
    -------
    pyspark.sql.DataFrame
        `current_df` with `agg_col` updated for the mapped stores.
    """
    # ───────────────────────────────────────────────
    # 1) Map sub-warehouses → parent stores
    # ───────────────────────────────────────────────
    # Build a Spark map literal: {old_code:new_code, …}
    mapping_expr = F.create_map(
        *[F.lit(x) for x in itertools.chain(*wh_to_store.items())]
    )

    sub_mapped = (
        sub_df
        .withColumn(loc_col, mapping_expr[F.col(loc_col)])          # K9902→K1003, …
        .groupBy(loc_col, sku_col)
        .agg(F.sum(agg_col).alias("SUB_WH_STOCK"))                  # safeguard duplicates
    )

    # ───────────────────────────────────────────────
    # 2) Merge and apply the uplift
    # ───────────────────────────────────────────────
    updated = (
        current_df
        .join(sub_mapped, on=[loc_col, sku_col], how="left")        # keep all current rows
        .withColumn("SUB_WH_STOCK", F.coalesce("SUB_WH_STOCK", F.lit(0)))
        .withColumn(agg_col, F.col(agg_col) + F.col("SUB_WH_STOCK"))
        .drop("SUB_WH_STOCK")
    )

    return updated

# COMMAND ----------

global_option_size_df = spark.sql("""
        select OPTION_CODE, 
        count(distinct SKU_CODE) global_option_size 
        from 
        gold.`custom-analysis`.product_attributes group by OPTION_CODE
        """).toPandas()
        
def get_iso_start_date(iso_week_str: str) -> date:
    """
    Accepts a string in the format 'YYYY-Www' (e.g., '2025-W17') and returns the start date (Monday)
    of the corresponding ISO week.
    """
    year_str, week_str = iso_week_str.split('-W')
    year = int(year_str)
    week = int(week_str)
    return date.fromisocalendar(year, week, 1)  # 1 = Monday

# COMMAND ----------

missing_size_df = pd.read_excel("missing_size.xlsx")
missing_df = missing_size_df[['GRADE', 'GROUP_NAME', 'SIZE_CODE', 'SIZE_GROUP', 'MIN_QTY', 'MAX_QTY']]

# COMMAND ----------

warehouse_sku_df = spark.sql("""
          SELECT 
          distinct LOCATION_CODE as WAREHOUSE_CODE,
          SKU_CODE,
          OPTION_CODE,
          SIZE_CODE,
          COUNTRY,
          WAREHOUSE_STOCK_1 as WH_QTY
          FROM 
          gold.`custom-analysis`.SKU_BOX_QUANTITY
          where LOCATION_CODE not in ('101')
          """).toPandas()

host_warehouse_stock = spark.sql("""
          SELECT 
          LOCATION_CODE as WAREHOUSE_CODE,
          SKU_CODE,
          OPTION_CODE,
          SIZE_CODE,
          COUNTRY,
          BOXQTY,
          WAREHOUSE_STOCK_1 as HOSTWATEHOUSE_STOCK
          FROM 
          gold.`custom-analysis`.SKU_BOX_QUANTITY
          WHERE LOCATION_CODE='101'
          """).toPandas()

# COMMAND ----------

warehouse_sku_df = warehouse_sku_df[warehouse_sku_df['WH_QTY']>0].copy()

# COMMAND ----------

historic_sku_sales_df = spark.sql(
    """
        SELECT 
        SALES_DATE,
        LOCATION_CODE,STORE_TYPE,
        GRADE,COUNTRY,GROUP_NAME,
        SKU_CODE, OPTION_CODE,
        SIZE_CODE,LAUNCH_DATE,
        BRAND_NAME,SUB_BRAND_NAME,
        SIZE_GROUP,SEASON_NAME, SUB_SEASON_NAME,
        SUM(TOTAL_QUANTITY) AS TOTAL_QUANTITY
        FROM gold.`custom-analysis`.sku_clustering_temp_sales_transfer A
        WHERE 
        SKU_CODE in (select distinct SKU_CODE  from gold.`custom-analysis`.product_attributes WHERE SEASON_NAME_YEAR in ('AUTUMN WINTER 2025'))
        AND
        SALES_DATE BETWEEN DATE(CURRENT_DATE - INTERVAL 42 DAY) AND CURRENT_DATE AND TRANS_ACTIVE = '1'
        
        AND
        BRAND_NAME in ('RIVA','CHOICE','RIVA KIDS')
        GROUP BY
        SALES_DATE,SIZE_GROUP,
        LOCATION_CODE,STORE_TYPE,
        GRADE,COUNTRY,GROUP_NAME,
        SKU_CODE, OPTION_CODE,
        SIZE_CODE,LAUNCH_DATE,
        BRAND_NAME,SUB_BRAND_NAME,
        SEASON_NAME, SUB_SEASON_NAME
        
    """).toPandas()

# COMMAND ----------

historic_sku_sales_df.loc[(historic_sku_sales_df['LOCATION_CODE']=='K4602'),
                      'GRADE'] = 'C'

# COMMAND ----------

historic_sku_sales_df['SALES_DATE']     = pd.to_datetime(historic_sku_sales_df['SALES_DATE'])
historic_sku_sales_df['TOTAL_QUANTITY'] = pd.to_numeric(historic_sku_sales_df['TOTAL_QUANTITY'], errors='coerce').fillna(0)
cutoff = historic_sku_sales_df['SALES_DATE'].max() - pd.Timedelta(days=42)
final_histori_sales_df = historic_sku_sales_df[historic_sku_sales_df['SALES_DATE'] >= cutoff]

# COMMAND ----------

final_histori_sales_df['GROUP_NAME'].fillna(final_histori_sales_df['GROUP_NAME'].mode()[0], inplace=True)

# COMMAND ----------

final_histori_sales_df[final_histori_sales_df['GRADE'].isnull()]['LOCATION_CODE'].unique()

# COMMAND ----------

iso = final_histori_sales_df['SALES_DATE'].dt.isocalendar()
final_histori_sales_df['ISO_YYYYWW'] = (
        iso['year'].astype(str)
      + '-W' 
      + iso['week'].astype(str).str.zfill(2)
)

id_cols = [
    'LOCATION_CODE', 'STORE_TYPE', 'COUNTRY',
    'SKU_CODE', 'OPTION_CODE', 'SIZE_CODE', 'LAUNCH_DATE',
    'BRAND_NAME', 'SUB_BRAND_NAME','GRADE','GROUP_NAME','SIZE_GROUP']

agg = (final_histori_sales_df
       .groupby(id_cols + ['ISO_YYYYWW'], as_index=False)
       .agg(QTY_SOLD=('TOTAL_QUANTITY', 'sum')))

pivot = (agg
         .pivot_table(index=id_cols,
                      columns='ISO_YYYYWW',
                      values='QTY_SOLD',
                      aggfunc='sum',
                      fill_value=0
                      )).reset_index()

pivot.drop(['2025-W32'], axis=1, inplace=True)
weekly_sales_qty_cols = sorted([col for col in pivot.columns if col.startswith('20') and '-W' in col])

# COMMAND ----------

pivot

# COMMAND ----------

print(weekly_sales_qty_cols[-2:])
print(weekly_sales_qty_cols[-4:-2])
print(weekly_sales_qty_cols[:-4])

# COMMAND ----------

num_days = (datetime.datetime.now().date()- get_iso_start_date(weekly_sales_qty_cols[-2])).days
print(num_days)

# COMMAND ----------

pivot['ROS1'] = pivot[weekly_sales_qty_cols[:-4]].sum(axis=1) / 14
pivot['ROS2'] = pivot[weekly_sales_qty_cols[-4:-2]].sum(axis=1) / 14
pivot['ROS3'] = pivot[weekly_sales_qty_cols[-2:]].sum(axis=1) / num_days

# COMMAND ----------

from pyspark.sql.functions import col, weekofyear, year, lpad, concat_ws, row_number, round as F_round
from pyspark.sql.window import Window
import pyspark.sql.functions as F
import numpy as np

# 1. Load the data using Spark SQL
historical_week_stock_df = spark.sql("""
    SELECT 
        STK_DATE,
        LOCATION_CODE,
        ITEMCODE AS SKU_CODE,
        STOCK AS CURRENT_STORE_STOCK
    FROM gold.`custom-analysis`.SKU_STOCK_HISTORY_DUP
    WHERE STK_DATE BETWEEN DATE(CURRENT_DATE - INTERVAL 42 DAY) AND CURRENT_DATE
""")

# 2. Add ISO_YYYYWW column in format 'YYYY-Www'
historical_week_stock_df = (
    historical_week_stock_df
    .withColumn("YEAR", year("STK_DATE"))
    .withColumn("WEEK", lpad(weekofyear("STK_DATE").cast("string"), 2, '0'))
    .withColumn("ISO_YYYYWW", concat_ws("-W", col("YEAR"), col("WEEK")))
)

# 3. Get end-of-week stock (latest STK_DATE per week/location/SKU)
window_spec = Window.partitionBy("LOCATION_CODE", "SKU_CODE", "ISO_YYYYWW").orderBy(col("STK_DATE").desc())

latest_stock_df = (
    historical_week_stock_df
    .withColumn("rn", row_number().over(window_spec))
    .filter(col("rn") == 1)
    .drop("rn", "YEAR", "WEEK")
    .withColumn("CURRENT_STORE_STOCK", F_round(col("CURRENT_STORE_STOCK").cast("double")))
)

# 4. Convert to Pandas for pivoting
historical_weekly_stock_df = latest_stock_df.toPandas()
historical_weekly_stock_df.loc[historical_weekly_stock_df['CURRENT_STORE_STOCK']<0,'CURRENT_STORE_STOCK'] = 0 # current stock <=0 replace with 0
historical_weekly_stock_df['CURRENT_STORE_STOCK'].fillna(0, inplace=True)
# 5. Pivot to get weekly columns as features
historical_weekly_stock_df = (
    historical_weekly_stock_df
    .pivot_table(index=['LOCATION_CODE', 'SKU_CODE'],
                 columns='ISO_YYYYWW',
                 values='CURRENT_STORE_STOCK',
                 aggfunc='first',  # Use first as only one record per week
                 fill_value=0)
    .reset_index()
)
# 6. Rename columns to add -HIST suffix
historical_weekly_stock_df.columns = [
    f"{col}-HIST" if col not in ['LOCATION_CODE', 'SKU_CODE'] else col
    for col in historical_weekly_stock_df.columns
]
historical_weekly_stock_df.drop(['2025-W32-HIST'], axis=1, inplace=True)

# 8. List historical stock columns
hist_stock_qty_cols = list(historical_weekly_stock_df.filter(regex=r'^\d{4}-W\d{2}-HIST$').columns)
print("HISTORICAL SKU Columns: ", hist_stock_qty_cols)

# 9. Final preview
historical_weekly_stock_df.head()


# COMMAND ----------

store_sku_df = pivot.merge(historical_weekly_stock_df, on=['LOCATION_CODE','SKU_CODE'], how='left')

# COMMAND ----------

store_sku_df['STOCK_LAST_2W'] =  (store_sku_df[hist_stock_qty_cols[-2:]].sum(axis=1)).astype(bool)

# COMMAND ----------

last_week_col = weekly_sales_qty_cols[-1]
year, week = map(int, last_week_col.split('-W'))
last_week_monday = date.fromisocalendar(year, week, 1)
next_week_monday = last_week_monday + timedelta(days=7)
next_year, next_week, _ = next_week_monday.isocalendar()
next_week_col = f'FORECAST_{next_year}-W{next_week:02d}'

# COMMAND ----------

def forecast_fast_fashion(row):
    # Handle stockout fallback
    if row['ROS3']>=0.2:
        predicted_qty = round(row['ROS3']*1.50 *7)
        if row[weekly_sales_qty_cols[-1]] > predicted_qty:
            return row[weekly_sales_qty_cols[-1]] 
        else:
            return predicted_qty
    
    recent_sales = row[weekly_sales_qty_cols[-2:]].sum()
    if row['STOCK_LAST_2W'] == False or np.isnan(row['ROS3']) or row['ROS3']==0:
        ros_recent = row['ROS2'] * 1.5 * 0.7  # fallback if stockout
    else:
        ros_recent = row['ROS3'] * 1.5    
    
    if row['ROS1']==0 and row['ROS2']==0:
        final_ros = ros_recent 
    else:
        final_ros = 0.7 * ros_recent + 0.3 * row['ROS2'] + 0.1 * row['ROS1'] 
    forecast = np.round(final_ros * 7)
    if recent_sales > 0:
        return max(forecast, 1)
    return forecast

# COMMAND ----------

store_sku_df[next_week_col] = store_sku_df.apply(forecast_fast_fashion, axis=1)

# COMMAND ----------

# DBTITLE 1,PULLOUT Logic
pullout_option_df = spark.sql("""
SELECT  * FROM gold.`custom-analysis`.SKU_HEALTHY_PERCENT
where DAYS_SINCE_FIRST_TRANSFER > 14
""").toPandas()

option_forecast_df = store_sku_df.groupby(['LOCATION_CODE','OPTION_CODE'], as_index=False).agg({next_week_col:'sum'})
pullout_option_df = pullout_option_df.merge(option_forecast_df, on=['LOCATION_CODE','OPTION_CODE'], how='left').fillna(0)

pullout_option_df['IS_PULLOUT'] = (
    ((pullout_option_df['STORE_STOCK_OPTION_COV']<50) & (pullout_option_df[next_week_col]==0)) |
    ((pullout_option_df['STOCK']==0) & (pullout_option_df[next_week_col]<=1) & (pullout_option_df['UNIQUE_SIZE_CODE_OVERALL']>3)) |
    ((pullout_option_df['STORE_STOCK_OPTION_COV']<50) & (pullout_option_df['LAST_2_WEEK_SALES_QTY']<=0)) |
    ((pullout_option_df['has_transfer_in'] == 0)) )

pullout_option_df['IS_PULLOUT'] = pullout_option_df['IS_PULLOUT'].astype(int)


# pullout_option_df.loc[(pullout_option_df['OPTION_CODE']=='103114-25001-084') &
# (pullout_option_df['LOCATION_CODE']=='B1002'),'IS_PULLOUT'] = 1


broken_return_option_df = pullout_option_df[pullout_option_df['IS_PULLOUT']>0]


broken_return_option_df.rename({'IS_PULLOUT':'unhealthy_option_cov'}, axis=1, inplace=True)

# Adding Manual Pullout options
manual_pullout_df = (
    spark.sql("""
        SELECT
            LOCATION_CODE,
            Option_Code AS OPTION_CODE
        FROM gold.`custom-analysis`.sku_pullout_open_1
    """)
    .toPandas()
    .drop_duplicates()                      
)
pullout_options = spark.sql("""
                SELECT 
                DISTINCT OPTION_CODE, 
                FROM_LOCATION AS LOCATION_CODE
                FROM 
                gold.`custom-analysis`.SKU_PULLOUT_TRANSFEROUT 
                where 
                IS_PULLOUT='1'
                """).toPandas()
manual_pullout_df = pd.concat([manual_pullout_df,pullout_options], ignore_index=True).drop_duplicates()

#  ── if you already have broken_return_option_df in pandas, keep this line;
#     otherwise convert from Spark:
# broken_return_option_df = spark.table("your.table").toPandas()

# ────────────────────────────────────────────────────────────────────────────
# 1.  Identify (LOCATION_CODE, OPTION_CODE) pairs that are **missing**
#     from broken_return_option_df
# ────────────────────────────────────────────────────────────────────────────

missing_pairs = (
    manual_pullout_df
        .merge(
            broken_return_option_df[["LOCATION_CODE", "OPTION_CODE"]],
            on=["LOCATION_CODE", "OPTION_CODE"],
            how="left",
            indicator=True
        )
        .query("_merge == 'left_only'")
        .drop(columns="_merge")
)

# ────────────────────────────────────────────────────────────────────────────
# 2.  If nothing is missing, stop here
# ────────────────────────────────────────────────────────────────────────────
if missing_pairs.empty:
    # broken_return_option_df is already up‑to‑date
    updated_df = broken_return_option_df

else:
    # ────────────────────────────────────────────────────────────────────────
    # 3.  Build a block of new rows, filled with NaN then overwrite known cols
    #     • all columns identical to broken_return_option_df
    #     • unhealthy_option_cov is set to 1.0 where present
    # ────────────────────────────────────────────────────────────────────────
    cols = broken_return_option_df.columns
    new_rows = pd.DataFrame(np.nan, index=missing_pairs.index, columns=cols)

    new_rows[["LOCATION_CODE", "OPTION_CODE"]] = missing_pairs.values

    if "unhealthy_option_cov" in new_rows.columns:
        new_rows["unhealthy_option_cov"] = 1.0

    # ────────────────────────────────────────────────────────────────────────
    # 4.  Concatenate once (linear time) instead of row‑by‑row (quadratic)
    # ────────────────────────────────────────────────────────────────────────
    updated_df = pd.concat(
        [broken_return_option_df, new_rows],
        ignore_index=True
    )

# updated_df now contains the original rows *plus* any new pull‑out rows
# ────────────────────────────────────────────────────────────────────────────
# 5.  (Optional) Write back to Spark or disk
# ────────────────────────────────────────────────────────────────────────────

# updated_broken_return_option_spark = spark.createDataFrame(updated_df)
# updated_broken_return_option_spark.write.mode("overwrite").saveAsTable(
#     "gold.`custom-analysis`.broken_return_option_updated"
# )

# Done – `updated_df` is your final result in Pandas
broken_return_option_df = updated_df.copy()

# COMMAND ----------

pullout_option_df[(pullout_option_df['LOCATION_CODE']=='16') &
(pullout_option_df['OPTION_CODE']=='101101-25018-100')]

# COMMAND ----------

store_sku_df[hist_stock_qty_cols] = store_sku_df[hist_stock_qty_cols].fillna(0)

# COMMAND ----------

store_sku_df['NON_ZERO_STOCK_WEEKS_4W'] = (store_sku_df[hist_stock_qty_cols[-4:]] > 0).sum(axis=1)

store_sku_df['AVG_CLOSING_STOCK_4W'] = (
    store_sku_df[hist_stock_qty_cols[-4:]].sum(axis=1) /
    store_sku_df['NON_ZERO_STOCK_WEEKS_4W'].replace(0, np.nan)
).fillna(0)

store_sku_df['BEST_SELLER_SCORE'] = store_sku_df[weekly_sales_qty_cols[-4:]].sum(axis=1) / store_sku_df['AVG_CLOSING_STOCK_4W']
store_sku_df['BEST_SELLER_SCORE'].fillna(0, inplace=True)
store_sku_df['BEST_SELLER_SCORE'] = store_sku_df['BEST_SELLER_SCORE'].replace(np.inf, 0)

store_sku_df['SELLER_TIER'] = pd.cut(
    store_sku_df['BEST_SELLER_SCORE'],
    bins=[-np.inf, 0.01, 0.1, 0.5, 1.0, 1.5, 3.0, np.inf],
    labels=[
        'No Sales',
        'Dead Stock',
        'Very Slow Mover',
        'Slow Mover',
        'Mid Seller',
        'Best Seller',
        'Top Seller'
    ]
)

# COMMAND ----------

wh_to_store_map = {'K9902': 'K1003', 'K9903': 'K1004'}

current_stock_df = spark.sql("""
                            select 
                            LOCATION_CODE,
                            ITEMCODE as SKU_CODE,
                            Intransit_QTY AS INTRANSIT_QTY,
                            INTERNATIONAL_INTRANSIT_QTY AS FRGN_INTRANSIT,
                            LOCAL_INTRANSIT_QTY,
                            Open_QTY AS OPEN_QTY,
                            TOTAL_STOCK AS TOTAL_NEW_STORE_STOCK,
                            IN_STOCK as CURRENT_STORE_STOCK
                            from gold.`custom-analysis`.SKU_stock_intransit_op_cur_stock 
                            WHERE 
                            BRAND_NAME 
                            IN 
                            ('RIVA','CHOICE', 'RIVA KIDS')
                            """)

subwarehouse_stock = spark.sql("""
                            select 
                            LOCATION_CODE,
                            ITEMCODE as SKU_CODE,
                            TOTAL_STOCK AS TOTAL_NEW_STORE_STOCK
                            from gold.`custom-analysis`.SKU_stock_intransit_op_cur_stock 
                            WHERE 
                            BRAND_NAME 
                            IN 
                            ('RIVA','CHOICE', 'RIVA KIDS')
                            and LOCATION_CODE in ('K9902','K9903')
                            """)


current_plus = apply_subwarehouse_uplift(
    current_stock_df,
    subwarehouse_stock,
    wh_to_store_map
)

# COMMAND ----------

current_stock_df = current_plus.toPandas()

# COMMAND ----------

# DBTITLE 1,UPDATING CURRENT STORE STOCK AND MIN AND MAX QUANITY STOCKS
min_max_qty_df = spark.sql(f"""Select distinct GROUP_NAME,SCALE_CODE SIZE_GROUP, SIZE_CODE,SHOP_GRADE GRADE, MINQTY,MAXQTY from gold.`custom-analysis`.wms_shop_distribution_Dup 
                           """).toPandas()
min_max_qty_df['MINQTY'] = min_max_qty_df['MINQTY'].astype(int)
min_max_qty_df['MAXQTY'] = min_max_qty_df['MAXQTY'].astype(int)

current_stock_df.head()

# COMMAND ----------

missing_df = missing_df[['GROUP_NAME','SIZE_GROUP','SIZE_CODE','GRADE','MIN_QTY','MAX_QTY']]

# COMMAND ----------

missing_df.rename({'MIN_QTY':'MINQTY','MAX_QTY':'MAXQTY'}, axis=1, inplace=True)

# COMMAND ----------

min_max_qty_df = pd.concat([min_max_qty_df,missing_df])

# COMMAND ----------

# min_max_qty_df.drop_duplicates(subset=['GROUP_NAME','SIZE_GROUP','SIZE_CODE','GRADE'], inplace=True)
min_max_qty_df.head()

# COMMAND ----------

sku_store_df = store_sku_df.merge(current_stock_df, on=['SKU_CODE', 'LOCATION_CODE'], how='left')
sku_store_df = sku_store_df.merge(min_max_qty_df, on=['GROUP_NAME','SIZE_GROUP','GRADE','SIZE_CODE'], how='left')
sku_store_df.head()

# COMMAND ----------

sku_store_df.loc[(sku_store_df['MINQTY'].isnull()) &
             (sku_store_df['GRADE']=='C'),['MINQTY','MAXQTY']] = [1,1] 

sku_store_df.loc[(sku_store_df['MINQTY'].isnull()) &
             (sku_store_df['GRADE']=='B'),['MINQTY','MAXQTY']] = [2,2] 

sku_store_df.loc[(sku_store_df['MINQTY'].isnull()) &
             (sku_store_df['GRADE']=='A'),['MINQTY','MAXQTY']] = [2,3] 

# COMMAND ----------

sku_store_df[(sku_store_df['GRADE']=='A') &
(sku_store_df['GROUP_NAME']=='OUTERWEAR') &
(sku_store_df['SIZE_CODE']=='SML') &
(sku_store_df['SIZE_GROUP']=='XSM2XL')]

# COMMAND ----------

sku_store_df.isnull().sum()

# COMMAND ----------

size_code_stock_df = sku_store_df.groupby(['LOCATION_CODE','OPTION_CODE','SIZE_CODE'], as_index=False).agg({'TOTAL_NEW_STORE_STOCK':'sum'})

option_stock_df = (
    size_code_stock_df
    .groupby(['LOCATION_CODE', 'OPTION_CODE'])['TOTAL_NEW_STORE_STOCK']
    .sum()
    .reset_index()
    .rename(columns={'TOTAL_NEW_STORE_STOCK': 'OPTION_TOTAL_STOCK'})
)
option_stock_df


# COMMAND ----------

sku_store_df = sku_store_df.merge(option_stock_df, on=['LOCATION_CODE', 'OPTION_CODE'], how='left')
sku_store_df.head()

# COMMAND ----------

sku_store_df.loc[
    (sku_store_df[next_week_col] == 0) &
    (sku_store_df['TOTAL_NEW_STORE_STOCK'] == 0) &
    (sku_store_df['OPTION_TOTAL_STOCK'] > 0),
    next_week_col
] = sku_store_df.loc[
    (sku_store_df[next_week_col] == 0) &
    (sku_store_df['TOTAL_NEW_STORE_STOCK'] == 0) &
    (sku_store_df['OPTION_TOTAL_STOCK'] > 0),
    'MINQTY'
]

# COMMAND ----------

warehouse_qty_df = warehouse_sku_df.groupby(['WAREHOUSE_CODE','SKU_CODE','COUNTRY'],as_index=False).agg({'WH_QTY':'sum'})

# COMMAND ----------

# --- 1.  Attach warehouse stock -------------------------------------------
final_sku_stock_df = (sku_store_df
      .merge(warehouse_qty_df[['WAREHOUSE_CODE','SKU_CODE','COUNTRY','WH_QTY']],
             on=['COUNTRY', 'SKU_CODE'],
             how='left')
      .fillna({'WH_QTY': 0}))


# COMMAND ----------

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='KUWAIT'),
                   'WAREHOUSE_CODE'
                   ] = 'K9901'

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='BAHRAIN'),
                   'WAREHOUSE_CODE'
                   ] = 'B97'

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='UAE'),
                   'WAREHOUSE_CODE'
                   ] = 'U019901'

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='SAUDI ARABIA'),
                   'WAREHOUSE_CODE'
                   ] = 'S99'


final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='QATAR'),
                   'WAREHOUSE_CODE'
                   ] = 'Q9901'

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='OMAN'),
                   'WAREHOUSE_CODE'
                   ] = 'O019901'

# COMMAND ----------

WEEK_COLS = weekly_sales_qty_cols.copy()
STOCK_COLS = list(hist_stock_qty_cols).copy()

pairwise_good = [
    final_sku_stock_df[week].where(final_sku_stock_df[stock] > 0, 0)          # keep sales only if opening stock > 0
    for week, stock in zip(WEEK_COLS, STOCK_COLS)
]
good_sales_total = pd.concat(pairwise_good, axis=1).sum(axis=1)
good_weeks_count = (final_sku_stock_df[STOCK_COLS] > 0).sum(axis=1)       # how many weeks had stock

# daily ROS = total sales / (good_weeks × 7)
final_sku_stock_df["ROS_DAY"] = (
    good_sales_total /
    (good_weeks_count.replace(0, np.nan) * 7)
).fillna(0)

miss_mask          = final_sku_stock_df[STOCK_COLS].eq(0) & final_sku_stock_df[WEEK_COLS].eq(0)
miss_weeks_cnt     = miss_mask.sum(axis=1)
# final_sku_stock_df["MISSED_UNITS"]  = (final_sku_stock_df["ROS_DAY"] * 7 * miss_weeks_cnt).round()

# COMMAND ----------

final_sku_stock_df = final_sku_stock_df.merge(host_warehouse_stock[['SKU_CODE','HOSTWATEHOUSE_STOCK']], how='left')
final_sku_stock_df.head()

# COMMAND ----------

condition = (
    (final_sku_stock_df['STOCK_LAST_2W'] == False) &
    (final_sku_stock_df[next_week_col] == 0) &
    ((final_sku_stock_df['WH_QTY'] + final_sku_stock_df['HOSTWATEHOUSE_STOCK']) > 0) &
    (final_sku_stock_df['ROS_DAY'] > 0.1)
)


final_sku_stock_df.loc[condition,next_week_col] = np.round(final_sku_stock_df.loc[condition,'ROS_DAY'] * 7)

# COMMAND ----------

broken_return_option_df.head()

# COMMAND ----------

final_sku_stock_df = final_sku_stock_df.merge(broken_return_option_df[['LOCATION_CODE','OPTION_CODE','unhealthy_option_cov']], on=['LOCATION_CODE','OPTION_CODE'], how='left')
final_sku_stock_df.head()

# COMMAND ----------

final_sku_stock_df.loc[
    (final_sku_stock_df['unhealthy_option_cov'].notnull()),
    next_week_col
    ] = 0

# COMMAND ----------

final_sku_stock_df = final_sku_stock_df.drop_duplicates()

# COMMAND ----------

final_sku_stock_df['MAXQTY'] = np.where(
    (final_sku_stock_df['SELLER_TIER'].isin(['Top Seller', 'Best Seller'])) & (final_sku_stock_df[next_week_col] > final_sku_stock_df["MAXQTY"]),
    final_sku_stock_df[next_week_col],
    final_sku_stock_df["MAXQTY"]
)

# COMMAND ----------

final_sku_stock_df.loc[final_sku_stock_df['MAXQTY']>=4,'MAXQTY'] = 4

# COMMAND ----------

MISSED_LAMBDA = 0.20                             # weight on missed units
# High‑priority order: lower number = higher priority
STORE_PRIORITY_MAP = {"A": 0, "B": 1, "C": 2, "OUTLET": 3}

# COMMAND ----------

final_sku_stock_df["PRIORITY_RANK"]  = final_sku_stock_df["GRADE"].map(STORE_PRIORITY_MAP).fillna(99).astype(int)

# COMMAND ----------

mask = ((final_sku_stock_df[next_week_col]>0) & (final_sku_stock_df[next_week_col]<final_sku_stock_df['MINQTY']))
final_sku_stock_df.loc[mask,next_week_col] = final_sku_stock_df.loc[mask,'MINQTY']

# COMMAND ----------

final_sku_stock_df = final_sku_stock_df.merge(global_option_size_df, how='left', on=['OPTION_CODE'])

# COMMAND ----------

mask = ((final_sku_stock_df[next_week_col]>0) & (final_sku_stock_df[next_week_col]>=3) & (final_sku_stock_df['SELLER_TIER'].isin(['Top Seller','Best Seller'])))
final_sku_stock_df.loc[mask,next_week_col] = final_sku_stock_df.loc[mask,'MAXQTY']

# COMMAND ----------

apparels = ['ACCESSORIES', 'DRESS', 'BLOUSE', 'SHIRT', 'SKIRT' , 'TROUSER' , 'BLAZER' , 'COAT' , 'SETS','ACCESSORIES', 'OUTERWEAR']
apparels_mask = ((final_sku_stock_df['GROUP_NAME'].isin(apparels)) & 
                       (final_sku_stock_df['global_option_size']==1) &
                       (final_sku_stock_df[next_week_col]>0))


final_sku_stock_df.loc[apparels_mask & (final_sku_stock_df['GRADE']=='A') & (final_sku_stock_df[next_week_col]<=5),next_week_col] = 5

final_sku_stock_df.loc[apparels_mask & (final_sku_stock_df['GRADE'].isin(['B','C'])) & (final_sku_stock_df[next_week_col]<=3),next_week_col] = 3

# COMMAND ----------

final_sku_stock_df.loc[(final_sku_stock_df[next_week_col]==1),next_week_col] = 2
final_sku_stock_df.loc[(final_sku_stock_df['LOCATION_CODE'].isin(['16','13'])) & (final_sku_stock_df[next_week_col]>0), next_week_col] = 1

# COMMAND ----------

final_sku_stock_df[(final_sku_stock_df['LOCATION_CODE']=='16') &
(final_sku_stock_df['OPTION_CODE']=='101101-25018-100')]

# COMMAND ----------

mask_a = (
    final_sku_stock_df['GRADE'].eq('A')
    & final_sku_stock_df['GROUP_NAME'].isin(['SCARF', 'ACCESSORIES', 'JEWELRY']) 
    & (final_sku_stock_df[next_week_col]>0)
)
final_sku_stock_df.loc[mask_a, next_week_col] = np.where(
    final_sku_stock_df.loc[mask_a, next_week_col] > 5, 10, 5
)

mask_b = (
    final_sku_stock_df['GRADE'].eq('B')
    & final_sku_stock_df['GROUP_NAME'].isin(['SCARF', 'ACCESSORIES', 'JEWELRY']) 
    & (final_sku_stock_df[next_week_col]>0)
)
final_sku_stock_df.loc[mask_b, next_week_col] = np.where(
    final_sku_stock_df.loc[mask_b, next_week_col] > 3, 6, 3
)

mask_c = (
    final_sku_stock_df['GRADE'].eq('C')
    & final_sku_stock_df['GROUP_NAME'].isin(['SCARF', 'ACCESSORIES', 'JEWELRY']) 
    & (final_sku_stock_df[next_week_col]>0)
)
final_sku_stock_df.loc[mask_c, next_week_col] = np.where(
    final_sku_stock_df.loc[mask_c, next_week_col] > 3, 3, 3
)

mask_a = (
    final_sku_stock_df['GRADE'].eq('A')
    & final_sku_stock_df['GROUP_NAME'].isin(['SCARF', 'ACCESSORIES', 'JEWELRY']) 
)

mask_b = (
    final_sku_stock_df['GRADE'].eq('B')
    & final_sku_stock_df['GROUP_NAME'].isin(['SCARF', 'ACCESSORIES', 'JEWELRY']) 
)

mask_c = (
    final_sku_stock_df['GRADE'].eq('C')
    & final_sku_stock_df['GROUP_NAME'].isin(['SCARF', 'ACCESSORIES', 'JEWELRY']) 
)

final_sku_stock_df.loc[mask_a,['MINQTY','MAXQTY']] = [5, 10]
final_sku_stock_df.loc[mask_b,['MINQTY','MAXQTY']] = [3, 6]
final_sku_stock_df.loc[mask_c,['MINQTY','MAXQTY']] = [3, 3]

# COMMAND ----------

final_sku_stock_df[final_sku_stock_df['GROUP_NAME'].isin(['SCARF','ACCESSORIES','JEWELRY'])]    

# COMMAND ----------

final_sku_stock_df["RAW_NEED"] = (final_sku_stock_df[next_week_col].astype(float) - final_sku_stock_df["TOTAL_NEW_STORE_STOCK"].astype(float)).clip(lower=0)
#final_sku_stock_df["ADJ_NEED"] = final_sku_stock_df["RAW_NEED"].astype(float) + final_sku_stock_df["MISSED_UNITS"].astype(float)

# COMMAND ----------

final_sku_stock_df["NEED"] = final_sku_stock_df['RAW_NEED']

# COMMAND ----------

store_ids = ['K1001','R04']
subwarehouse_stock = spark.sql(
    """select 
    LOCATION_CODE,
    ITEMCODE AS SKU_CODE,
    (IN_STOCK + Intransit_QTY) as SWH_STOCK

    from 
    gold.`custom-analysis`.sku_stock_intransit_op_cur_stock where LOCATION_CODE='K9904' AND TOTAL_STOCK>0
    """).toPandas()



subwh_to_store = pd.DataFrame({
    "SUBWH_CODE": ["K9904", "K9904"],
    "LOCATION_CODE": store_ids
    }
    )

ros_priority = spark.sql("""
          SELECT LOCATION_CODE, OPTION_CODE, (SUM(TOTAL_QUANTITY) / 14) AS ROS
        FROM gold.`custom-analysis`.sku_clustering_temp_sales_transfer
        WHERE LOCATION_CODE IN ('K1001', 'R04')
        AND SALES_DATE >= CURRENT_DATE - INTERVAL 14 DAY
        GROUP BY LOCATION_CODE,OPTION_CODE
        """).toPandas()

subwarehouse_store_df = final_sku_stock_df.loc[final_sku_stock_df['LOCATION_CODE'].isin(store_ids),['LOCATION_CODE','OPTION_CODE','SKU_CODE',next_week_col,'NEED','TOTAL_NEW_STORE_STOCK']]
subwarehouse_store_df = subwarehouse_store_df.merge(ros_priority, on=['LOCATION_CODE','OPTION_CODE'], how='left')
subwarehouse_store_df['ROS'].fillna(0, inplace=True)

# COMMAND ----------

def _allocate_single_sku(subwh_qty: int, df: pd.DataFrame,
                         shortfall_col: str = "NEED",
                         priority_col: str = "ROS") -> tuple[pd.Series, int]:
    """
    Allocate `subwh_qty` pieces across the rows of `df`
    (one row per store, already filtered to ONE SKU + ONE SUBWH).
    Returns the allocation vector and the remaining qty.
    """
    df = df.sort_values(priority_col, ascending=False)           # priority
    alloc = []
    for shortfall in df[shortfall_col]:
        give = min(shortfall, subwh_qty)
        alloc.append(give)
        subwh_qty -= give
    return pd.Series(alloc, index=df.index), subwh_qty


def allocate_all_subwh_stock(
    subwh_stock: pd.DataFrame,       # [SUBWH_CODE, SKU_CODE, SWH_STOCK]
    wh2store:   pd.DataFrame,        # [SUBWH_CODE, STORE_CODE]
    demand:     pd.DataFrame,        # [STORE_CODE, SKU_CODE, FORECAST, STOCK, ROS, …]
    swh_stock_col: str = "SWH_STOCK",
    priority_col: str = "ROS",
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Greedily allocate *every* sub-warehouse’s stock to its mapped stores.

    Returns
    -------
    allocated_df : full demand table with added columns:
        • SHORTFALL
        • ALLOCATED_FROM_SWH
        • FINAL_STOCK
        • SUBWH_CODE (via mapping)
    remainder_df : rows (SUBWH_CODE, SKU_CODE, REMAINING_QTY) for anything unallocated
    """
    demand = demand.copy()
    demand = demand.merge(wh2store, on="LOCATION_CODE", how="left")
    
    swh_qty_dict = {
    k: float(v)
    for k, v in (
        subwh_stock
        .groupby(["LOCATION_CODE", "SKU_CODE"])[swh_stock_col]
        .sum()
        .to_dict()
        .items()
    )
    }
    
    allocations = []
    remainders = []
    
    for (subwh, sku), grp in demand.groupby(["SUBWH_CODE", "SKU_CODE"]):
        qty_available = swh_qty_dict.get((subwh, sku), 0)
        alloc_vec, qty_left = _allocate_single_sku(
            qty_available, grp, shortfall_col="NEED", priority_col=priority_col
        )
        allocations.append(alloc_vec)
        
        if qty_left:
            remainders.append({
                "SUBWH_CODE": subwh,
                'OPTION_CODE':grp.OPTION_CODE.iloc[0],
                "SKU_CODE":   sku,
                "REMAINING_QTY": qty_left
            })
        
    demand["ALLOCATED_FROM_SWH"] = pd.concat(allocations).sort_index()
    demand["FINAL_STOCK"] = demand["TOTAL_NEW_STORE_STOCK"].astype(float) + demand["ALLOCATED_FROM_SWH"].astype(float)
    remainder_df = pd.DataFrame(remainders)
    return demand, remainder_df

demand_df, remainder_df = allocate_all_subwh_stock(subwarehouse_stock, subwh_to_store, subwarehouse_store_df)

# COMMAND ----------

remainder_df.to_csv("remainders.csv", index=False)

# COMMAND ----------

demand_df.head()

# COMMAND ----------

final_sku_stock_df = final_sku_stock_df.merge(demand_df[['LOCATION_CODE','SKU_CODE','FINAL_STOCK']], on=['LOCATION_CODE','SKU_CODE'] ,how='left')

subwarehouse_stock_requiered_mask = (final_sku_stock_df['FINAL_STOCK'].notnull())
final_sku_stock_df.loc[subwarehouse_stock_requiered_mask, 'TOTAL_NEW_STORE_STOCK'] = final_sku_stock_df.loc[subwarehouse_stock_requiered_mask, 'FINAL_STOCK']

final_sku_stock_df.loc[subwarehouse_stock_requiered_mask,"RAW_NEED"] = (
final_sku_stock_df.loc[subwarehouse_stock_requiered_mask, next_week_col].astype(float) - final_sku_stock_df.loc[subwarehouse_stock_requiered_mask, "TOTAL_NEW_STORE_STOCK"].astype(float)).clip(lower=0)

final_sku_stock_df.loc[subwarehouse_stock_requiered_mask,"NEED"] = final_sku_stock_df.loc[subwarehouse_stock_requiered_mask,'RAW_NEED']

# COMMAND ----------

final_sku_stock_df.loc[(final_sku_stock_df['TOTAL_NEW_STORE_STOCK']>=final_sku_stock_df['MAXQTY']) & ~(apparels_mask),'NEED'] = 0

# COMMAND ----------

final_sku_stock_df[final_sku_stock_df['GROUP_NAME'].isin(['SCARF','ACCESSORIES','JEWELRY'])]

# COMMAND ----------

# DBTITLE 1,SALES FROM FIRST TRANSFER TO TILL CURRENT DATE
first_sale_to_last_sale_df = spark.sql(
    """
        SELECT 
        LOCATION_CODE, SKU_CODE,
        SUM(TOTAL_QUANTITY) AS TOTAL_QTY_SOLD
        FROM gold.`custom-analysis`.sku_clustering_temp_sales_transfer
        WHERE 
        BRAND_NAME in ('RIVA','CHOICE','RIVA KIDS')
        GROUP BY
        SKU_CODE, LOCATION_CODE
    """).toPandas()

region_wise_sku_performance = spark.sql(
    """
        SELECT 
        COUNTRY, SKU_CODE,
        SUM(TOTAL_QUANTITY) AS TOTAL_QTY_SOLD_REGION
        FROM gold.`custom-analysis`.sku_clustering_temp_sales_transfer
        WHERE 
        BRAND_NAME in ('RIVA','CHOICE','RIVA KIDS')
        GROUP BY
        SKU_CODE, COUNTRY
    """).toPandas()

final_sku_stock_df = final_sku_stock_df.merge(first_sale_to_last_sale_df, on=['LOCATION_CODE','SKU_CODE'], how='left')
final_sku_stock_df = final_sku_stock_df.merge(region_wise_sku_performance, on=['COUNTRY','SKU_CODE'], how='left')
final_sku_stock_df['SALES_MIX'] = final_sku_stock_df['TOTAL_QTY_SOLD'] / final_sku_stock_df['TOTAL_QTY_SOLD_REGION']

# COMMAND ----------

region_demand_df = final_sku_stock_df.groupby(['COUNTRY','SKU_CODE'], as_index = False).agg({next_week_col:'sum'}).rename({next_week_col:'REGION_DEMAND'}, axis=1)
final_sku_stock_df = final_sku_stock_df.merge(region_demand_df, on=['COUNTRY','SKU_CODE'], how='left')
final_sku_stock_df['REGION_DEMAND_CONT'] = (final_sku_stock_df[next_week_col] / final_sku_stock_df['REGION_DEMAND']).fillna(0)

# COMMAND ----------

final_sku_stock_df.head()

# COMMAND ----------

df = final_sku_stock_df.copy()

# ---- 1. Normalised drivers (all 0–1 already) --------------------------

df['VELOCITY_IDX']      = df['TOTAL_QTY_SOLD']          / df['TOTAL_QTY_SOLD_REGION']        # how fast it moves locally
df['SALES_MIX_IDX']     = df['SALES_MIX']                                                     # share in the store basket
df['DEMAND_GAP_IDX']    = ((df['REGION_DEMAND'].astype(float) - df['TOTAL_QTY_SOLD'].astype(float))
                            .clip(lower=0) / df['REGION_DEMAND'])                             # unmet demand
df['CONTRIB_IDX']       = df['REGION_DEMAND_CONT'].astype(float)                                    # store’s weight in region

# tidy up any divide-by-zero or NaN
df[['VELOCITY_IDX','DEMAND_GAP_IDX']] = df[['VELOCITY_IDX','DEMAND_GAP_IDX']].fillna(0)

# ---- 2. Composite priority score --------------------------------------

df['SKU_PRIORITY'] = (
      0.40 * df['VELOCITY_IDX'].astype(float)        # keep fast movers stocked
    + 0.30 * df['SALES_MIX_IDX'].astype(float)       # protect key basket items
    + 0.20 * df['DEMAND_GAP_IDX'].astype(float)      # chase remaining demand
    + 0.10 * df['CONTRIB_IDX'].astype(float)         # honour regional hotspots
) * 100                                # scale to 0-100 for easy reading

# ---- 3. Easy-to-read tier label ---------------------------------------

df['PRIORITY_TIER'] = pd.cut(
    df['SKU_PRIORITY'],
    bins=[-1,20,40,60,80,100],
    labels=['Skip','Low','Medium','High','Top-Up NOW'],
    right=False
)

# ---- 4. View for planners ---------------------------------------------

priority_view = (df
    .sort_values(['SKU_PRIORITY','SKU_CODE'], ascending=[False,True])
    [['LOCATION_CODE','SKU_CODE','SKU_PRIORITY','PRIORITY_TIER']]
)


# COMMAND ----------

df.sort_values('SKU_PRIORITY', ascending=False)

# COMMAND ----------

final_sku_stock_df = df.sort_values('SKU_PRIORITY', ascending=False)

# COMMAND ----------

final_sku_stock_df.sort_values(["COUNTRY","SKU_CODE",
               "PRIORITY_RANK","ROS3",'SKU_PRIORITY'],
              ascending=[True,True,True,False,False],
              inplace=True)

# COMMAND ----------

final_sku_stock_df.head()

# COMMAND ----------

# DBTITLE 1,Temperary
from pyspark.sql.functions import collect_list

# Step 1: Run SQL query
nonrepl_items_df = spark.sql("""
    SELECT 
    LOCATION_CODE AS FROM_LOCATION,
    ITEMCODE, TO_LOC 
    FROM bronze.orjwan.OI_NONREPL_ITEMS 
    WHERE LOCATION_CODE IN ('K9901', 'O019901', 'S99', 'U019901', 'B97','Q9901') AND  LOCATION_CODE is not  NULL
""")

# Step 2: Group by TO_LOC and collect ITEMCODE as list
grouped_df = nonrepl_items_df.groupBy(['FROM_LOCATION',"TO_LOC"]).agg(collect_list("ITEMCODE").alias("ITEMCODES"))

# Step 3: Convert to dictionary: {TO_LOC: [ITEMCODE1, ITEMCODE2, ...]}
to_loc_dict = {
    row['FROM_LOCATION']: row['ITEMCODES']
    for row in grouped_df.collect()
}

# COMMAND ----------

# def allocate(group: pd.DataFrame) -> pd.DataFrame:
#     stock_left = int(group["WH_QTY"].iloc[0])
#     alloc, unful = [], []

#     for _, r in group.iterrows():
#         need = int(r["NEED"])
#         qty = min(need, stock_left)
#         stock_left -= qty
#         alloc.append(int(qty))
#         unful.append(int(need - qty))
#     out = group.copy()
#     out["REPLENISHED_QTY"]       = alloc
#     out["UNFULFILLED_QTY"] = unful
#     return out

def allocate(group: pd.DataFrame) -> pd.DataFrame:
    stock_left = int(group["WH_QTY"].iloc[0])
    alloc, unful = [], []

    for _, r in group.iterrows():
        if r['SKU_CODE'] in to_loc_dict.get(r['WAREHOUSE_CODE'],[]):
            need = int(r["NEED"])
            qty = 0 # min(need, stock_left)
            stock_left -= qty
            alloc.append(int(qty))
            unful.append(int(need - qty))
        else:       
            need = int(r["NEED"])
            qty = min(need, stock_left)
            stock_left -= qty
            alloc.append(int(qty))
            unful.append(int(need - qty))
        
        out = group.copy()
    out["REPLENISHED_QTY"]       = alloc
    out["UNFULFILLED_QTY"] = unful
    return out



# COMMAND ----------

result = (final_sku_stock_df.groupby(["COUNTRY","SKU_CODE"], group_keys=False)
            .apply(allocate))

# COMMAND ----------

result['HOSTWATEHOUSE_STOCK'].fillna(0, inplace=True)

# COMMAND ----------

result.head()

# COMMAND ----------

# mask = result["LOCATION_CODE"].isin(['K1005','K1003','K1603','K1605','K1608','K1201','K1001','K1602','K1002'])

# result.loc[mask, 'REPLENISHED_QTY'] = 0
# result.loc[mask, 'UNFULFILLED_QTY'] = result.loc[mask, 'NEED']

# buffer_stock_pick = result[(result["UNFULFILLED_QTY"] > 0) & mask].copy()
# buffer_stock_pick.head()

# region_alloc_qty_df = result.groupby(['COUNTRY','SKU_CODE'], as_index=False).agg({'REPLENISHED_QTY':'sum'}).rename({'REPLENISHED_QTY':'TOTAL_ALLOCATED_REGION_QTY'}, axis=1)
# buffer_stock_pick_df = pd.merge(buffer_stock_pick, region_alloc_qty_df, on=['SKU_CODE','COUNTRY'], how='left')



# warehouse_sku_kuwait_df = spark.sql("""
#           SELECT 
#           distinct
#           SKU_CODE,
#           COUNTRY,
#           WAREHOUSE_STOCK_2 as STOCK_WITH_BUFFER
#           FROM 
#           gold.`custom-analysis`.SKU_BOX_QUANTITY
#           where LOCATION_CODE = 'K9901'
#           """).toPandas()

# buffer_stock_pick_df = pd.merge(buffer_stock_pick_df, warehouse_sku_kuwait_df, on=['SKU_CODE','COUNTRY'], how='left') 
# buffer_stock_pick_df['NEW_STOCK'] = buffer_stock_pick_df['STOCK_WITH_BUFFER'] - buffer_stock_pick_df['TOTAL_ALLOCATED_REGION_QTY']
# buffer_stock_pick_df.loc[buffer_stock_pick_df['NEW_STOCK'].isnull(), 'NEW_STOCK'] = 0

# def host_min_max(group: pd.DataFrame) -> pd.DataFrame:
#     host_left = int(group["NEW_STOCK"].iloc[0])
#     host_alloc = []

#     for _, r in group.iterrows():
#         need = int(r["UNFULFILLED_QTY"])
#         lo   = int(r["MINQTY"])
#         hi   = int(r["MAXQTY"])

#         if need == 0 or host_left == 0:
#             q = 0
#         else:
#             q = min(need, host_left)          # attempt
#             # bump up to MIN if feasible
#             if 0 < q < lo <= host_left:
#                 q = need
#             # cap at MAX
#             q = min(q, 100000)
#         host_left -= q
#         host_alloc.append(q)

#     out = group.copy()
#     out["BUFFER_ALLOCATED_QTY"] = host_alloc
#     return out


# buffer_stock_pick_df = (
#     buffer_stock_pick_df.groupby(["SKU_CODE"], group_keys=False)
#          .apply(host_min_max)
# )

# COMMAND ----------

# buffer_stock_pick_df['REPLENISHED_QTY'] =  buffer_stock_pick_df['BUFFER_ALLOCATED_QTY']

# COMMAND ----------

# buffer_stock_pick_df["UNFULFILLED_QTY"] = (
#         buffer_stock_pick_df["UNFULFILLED_QTY"] - buffer_stock_pick_df["BUFFER_ALLOCATED_QTY"]
# ).clip(lower=0)

# COMMAND ----------

result[(result['OPTION_CODE']=='101101-25018-100') &
(result['LOCATION_CODE']=='16')]

# COMMAND ----------

result.to_csv("replenishment_history/local_to_store_replenishment_sept_17_v1.csv", index=False)

# COMMAND ----------

region_stock_df = spark.sql("""
select  SKU_CODE,  
        CASE 
            WHEN Market = 'UAE' THEN 'UAE'
            WHEN Market = 'KWT' THEN 'KUWAIT'
            WHEN Market = 'BAH' THEN 'BAHRAIN'
            WHEN Market = 'OMN' THEN 'OMAN'
            WHEN Market = 'SUD' THEN 'SAUDI ARABIA'
            WHEN Market = 'QA'  THEN 'QATAR'
        END AS COUNTRY, 
        TOTAL_STOCK as TOTAL_REGION_STOCK
        from gold.`custom-analysis`.sku_host_to_local
        where Market IN ('UAE','KWT','OMN','SUD','QA','BAH')
        """).toPandas()

region_stock_df['TOTAL_REGION_STOCK'].fillna(0, inplace=True)

# COMMAND ----------

region_stock_df.head()

# COMMAND ----------

result.shape

# COMMAND ----------

result = result.merge(region_stock_df, on=['SKU_CODE','COUNTRY'], how='left')

# COMMAND ----------

result

# COMMAND ----------

result[(result['OPTION_CODE']=='101101-25013-516') &
(result['LOCATION_CODE']=='U021003')]

# COMMAND ----------

result['TOTAL_NEW_STORE_STOCK'] = result['TOTAL_NEW_STORE_STOCK'].astype(float)

# COMMAND ----------

agg = result.groupby(['COUNTRY', 'SKU_CODE'], as_index=False).agg(
    store_stock  = ('TOTAL_NEW_STORE_STOCK', 'sum'),
    forecast     = (next_week_col, 'sum'),
    wh_stock_ini = ('WH_QTY', 'first'),
    region_stock = ('TOTAL_REGION_STOCK', 'first')
    )
    
agg['shortage']       = (agg.forecast.astype(float) - agg.region_stock.astype(float)).clip(lower=0)
agg['region_qty_rem'] = (agg.region_stock.astype(float) - agg.forecast.astype(float)).clip(lower=0)
agg['need_host_pull'] = agg.shortage.gt(0)          # True / False
agg['host_pull_qty']  = agg.shortage                # how many to request

# COMMAND ----------

result = result.merge(agg, on=['COUNTRY','SKU_CODE'], how='left')

# COMMAND ----------

short = result[(result["UNFULFILLED_QTY"] > 0) & (result['need_host_pull']==True)].copy()

# COMMAND ----------

short.head()

# COMMAND ----------

def allocate_host_pull(group: pd.DataFrame) -> pd.DataFrame:
    """
    Distribute the host_pull_qty value proportionally across the rows
    in *this* (COUNTRY, SKU_CODE) group.
    
    • Keeps integer units (rounds with largest‑fraction rule)
    • Result column = HOST_PULL_ALLOC
    """
    need_total = int(group['host_pull_qty'].iloc[0])             # 5 in your sample
    demand     = group['UNFULFILLED_QTY'].astype(float)
    demand_sum = demand.sum()

    # fractional allocation (keeps original proportions)
    alloc = demand / demand_sum * need_total                     # may be fractional

    # ---- integerise without losing/creating units --------------
    alloc_int   = np.floor(alloc).astype(int)
    remainder   = need_total - alloc_int.sum()                   # 0 … need_total‑1
    if remainder:
        # give the leftover units to the rows with the largest fractional parts
        frac = (alloc - alloc_int)
        bump_idx = frac.nlargest(remainder).index
        alloc_int.loc[bump_idx] += 1
    # ------------------------------------------------------------

    group['HOST_PULL_ALLOC'] = alloc_int
    return group

# apply per region×SKU
cols_key = ['COUNTRY', 'SKU_CODE']          # extend if host_pull_qty differs by more keys
final = (short                                   # your original DataFrame
         .groupby(cols_key, group_keys=False)
         .apply(allocate_host_pull))

# # (optional) what is still unfulfilled after the host pull
# final['UNFULFILLED_AFTER_PULL'] = (
#     final['UNFULFILLED_QTY'] - final['HOST_PULL_ALLOC']
# )

# COMMAND ----------

final[(final['COUNTRY']=='BAHRAIN') &
      (final['SKU_CODE']=='101105-25014-005-LRG')
      ]

# COMMAND ----------

# 2. Bring host stock per SKU‑size (sum of free pieces)
host = (final
        .groupby(["SKU_CODE"], as_index=False)
        .agg(HOST_STK=("HOSTWATEHOUSE_STOCK","first")))   # one number per SKU‑size

short = (final
         .merge(host, on=["SKU_CODE"], how="left")
         .sort_values(["SKU_CODE","PRIORITY_RANK"]))

# COMMAND ----------

def host_allocate(g: pd.DataFrame) -> pd.DataFrame:
    host_left = int(g["HOST_STK"].iloc[0])
    host_alloc = []

    for _, r in g.iterrows():
        need = int(r["HOST_PULL_ALLOC"])
        q    = min(need, host_left)
        host_left -= q
        host_alloc.append(q)

    g = g.copy()
    g["HOST_ALLOC_QTY"] = host_alloc
    g["HOST_LEFT_AFTER"] = host_left  # audit
    return g

# COMMAND ----------

short

# COMMAND ----------

short = (short
         .groupby(["SKU_CODE",], group_keys=False)
         .apply(host_allocate))


# COMMAND ----------

def host_min_max(group: pd.DataFrame) -> pd.DataFrame:
    host_left = int(group["HOST_STK"].iloc[0])
    host_alloc = []

    for _, r in group.iterrows():
        need = int(r["HOST_PULL_ALLOC"])
        lo   = int(r["MINQTY"])
        hi   = int(r["MAXQTY"])

        if need == 0 or host_left == 0:
            q = 0
        else:
            q = min(need, host_left)          # attempt
            # bump up to MIN if feasible
            if 0 < q < lo <= host_left:
                q = need
            # cap at MAX
            q = min(q, 100000)
        host_left -= q
        host_alloc.append(0) #q)

    out = group.copy()
    out["HOST_ALLOC_QTY"] = host_alloc
    return out

# COMMAND ----------

short = (
    short.groupby(["SKU_CODE"], group_keys=False)
         .apply(host_min_max)
)

# COMMAND ----------

short[short['HOST_ALLOC_QTY']>0]

# COMMAND ----------

result_temp = result.merge(
    short[["COUNTRY","LOCATION_CODE","SKU_CODE","HOST_ALLOC_QTY"]],
    on=["COUNTRY","LOCATION_CODE","SKU_CODE"],
    how="left"
).fillna({"HOST_ALLOC_QTY": 0})

# COMMAND ----------

# # final numbers
# result_temp["REPLENISHED_QTY"]   = result_temp["REPLENISHED_QTY"] + result_temp["HOST_ALLOC_QTY"]
# result_temp["UNFULFILLED_QTY"] = (
#         result_temp["UNFULFILLED_QTY"] - result_temp["HOST_ALLOC_QTY"]
# ).clip(lower=0)

# COMMAND ----------

result_temp[(result_temp['UNFULFILLED_QTY']>0) & (result_temp['HOSTWATEHOUSE_STOCK']>0)]

# COMMAND ----------

result_temp['REPLENISHING_WAREHOUSE'] = np.nan

# COMMAND ----------

result_temp.loc[result_temp['HOST_ALLOC_QTY']>0,'REPLENISHING_WAREHOUSE'] = "101"

# COMMAND ----------

result_temp.loc[
    (result_temp['HOSTWATEHOUSE_STOCK']==0) &
    (result_temp['REPLENISHED_QTY']>0), 
    "REPLENISHING_WAREHOUSE"
] = result_temp.loc[
    (result_temp['HOSTWATEHOUSE_STOCK']==0) &
    (result_temp['REPLENISHED_QTY']>0), 
    "WAREHOUSE_CODE"]

# COMMAND ----------

mask = (result_temp['HOST_ALLOC_QTY']==0) & (result_temp['REPLENISHED_QTY']>0)
result_temp.loc[mask,'REPLENISHING_WAREHOUSE'] = result_temp.loc[mask,'WAREHOUSE_CODE']      

# COMMAND ----------

store_to_store_transfer_ds = result_temp.copy()

# COMMAND ----------

# store_to_store_transfer_ds.to_csv("store_to_store_transfer_v3.csv", index=False)

# COMMAND ----------

import boto3
import datetime
def upload_file(df,file_name):
    df.reset_index(inplace=True)
    file_path = f'{file_name}_{str(datetime.datetime.now().time())}.csv'
    df.to_csv(file_path,index=False)
    access_key_id = "GOOG1E6IFCXNK7S7SIRIU2ZB3DZ5KZYETNXCZ7FCOPF3PZP2UWSI2TBYNGTWQ"
    secret_access_key = "WLbR0N3jp5iRCgGA0MJpzhOI6Bes4alRfpM5GI1g"
    s3_client = boto3.client(
        's3',
        aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key,
        endpoint_url="https://storage.googleapis.com"  # Google Cloud Storage endpoint for S3 API
    )

    bucket_name = "armada-gcs-ml-0001"
    object_name = file_path
    local_file_path = file_path

    # Upload the file
    with open(local_file_path, "rb") as data:
        s3_client.upload_fileobj(data, bucket_name, object_name)

# COMMAND ----------



# COMMAND ----------

# result_temp.drop(['TO_LOCATION'], axis=1, inplace=True)

# COMMAND ----------

# result_temp.to_csv("sku_replenishment_new.csv", )

# COMMAND ----------

# result_temp[(result_temp['LOCATION_CODE']=='R04') & (result_temp['SKU_CODE']=='101105-25065-502-LRG')] 

# COMMAND ----------

result_temp[(result_temp['OPTION_CODE']=='106108-25009-502') &
(result_temp['LOCATION_CODE']=='K1005')]

# COMMAND ----------

result_temp.drop(['PRIORITY_RANK','RAW_NEED','TOTAL_QTY_SOLD','TOTAL_QTY_SOLD_REGION','SALES_MIX','REGION_DEMAND','REGION_DEMAND_CONT','VELOCITY_IDX','SALES_MIX_IDX','DEMAND_GAP_IDX','CONTRIB_IDX',
                  				 'unhealthy_option_cov',
                      'NON_ZERO_STOCK_WEEKS_4W',	'AVG_CLOSING_STOCK_4W','STOCK_LAST_2W',
                  ], axis=1, inplace=True)

# COMMAND ----------

result_temp.rename({'LOCATION_CODE':'TO_LOCATION','REPLENISHING_WAREHOUSE':'FROM_LOCATION'}, axis=1, inplace=True)

# COMMAND ----------

result_temp.loc[(result_temp['REPLENISHED_QTY']>0)& (result_temp['WH_QTY']>0),['FROM_LOCATION','TO_LOCATION','INTRANSIT_QTY','SKU_CODE','OPEN_QTY','TOTAL_NEW_STORE_STOCK','CURRENT_STORE_STOCK','MINQTY','MAXQTY']]

# COMMAND ----------

# upload_file(result_temp,'replenishment_result_june_25_2025')

# COMMAND ----------

replenishment_requieted_stores_df = result_temp[result_temp['NEED']>0].copy()
replenishment_requieted_stores_df['30DAYS_SALES'] = replenishment_requieted_stores_df[weekly_sales_qty_cols[-4:]].sum(axis=1)

# COMMAND ----------

replenishment_requieted_stores_df
# Get the second last column
second_last_col = replenishment_requieted_stores_df.columns[-2]

# Reorder columns
cols = [second_last_col] + [col for col in replenishment_requieted_stores_df.columns if col != second_last_col]

# Reassign the dataframe with reordered columns
replenishment_requieted_stores_df = replenishment_requieted_stores_df[cols]

# COMMAND ----------



# COMMAND ----------

store_to_store_transfer_ds[(store_to_store_transfer_ds['OPTION_CODE']=='106108-25009-502') &
(store_to_store_transfer_ds['LOCATION_CODE']=='K1007')]

# COMMAND ----------

# replenishment_requieted_stores_df = replenishment_requieted_stores_df[(replenishment_requieted_stores_df['COUNTRY']=='SAUDI ARABIA')]

# COMMAND ----------

final_temp_df = replenishment_requieted_stores_df[['FROM_LOCATION','TO_LOCATION','SKU_CODE','REPLENISHED_QTY','WH_QTY','30DAYS_SALES','MINQTY','MAXQTY','CURRENT_STORE_STOCK','LOCAL_INTRANSIT_QTY','FRGN_INTRANSIT','INTRANSIT_QTY','OPEN_QTY','HOST_ALLOC_QTY','HOSTWATEHOUSE_STOCK']]
final_temp_df.head()

# COMMAND ----------

final_temp_df['FROM_LOCATION'].fillna('101', inplace=True)

# COMMAND ----------

final_temp_df.rename({'HOST_ALLOC_QTY':'REQ FOR 101',
                      'HOSTWATEHOUSE_STOCK':'HOST WH STK',
                      'OPEN_QTY':'OPENORDERQTY',
                      },
                    axis=1, inplace=True
                    )

# COMMAND ----------

result_temp[(result_temp['TO_LOCATION']=='R04') &
(result_temp['SKU_CODE'].str.contains('101105-25065-502-LRG'))
 ]

# COMMAND ----------

final_temp_df

# COMMAND ----------

final_temp_df['REQ FOR 101'].sum()

# COMMAND ----------

final_temp_df = final_temp_df[final_temp_df['REPLENISHED_QTY']>0]

# COMMAND ----------

# final_temp_df[final_temp_df['SKU_CODE'].str.contains('101101-25112-023')]
# final_temp_df[final_temp_df['COUNTRY']=='KUWAIT'].to_csv("ss.csv", index=False)

# COMMAND ----------



# COMMAND ----------

final_temp_df.to_csv("replenishment_aw25_report_sep_17_2025_v4.csv", index=False)

# COMMAND ----------

final_temp_df = pd.read_csv("host_to_local_replenishment_wms_sept_14_2025_v1.csv")

# COMMAND ----------


aw25_repl_prev = pd.read_csv("replenishment_history/local_to_store_replenishment_sept_14_v1.csv")
basic_repl_prev = pd.read_csv("replenishment_history/old_season_sept_14_2025.csv")

common_cols_prev = aw25_repl_prev.columns.intersection(basic_repl_prev.columns)

aw25_prev_common = aw25_repl_prev[common_cols_prev]
basic_prev_common = basic_repl_prev[common_cols_prev]

prev_rep_df = pd.concat([aw25_prev_common, basic_prev_common], ignore_index=True)


# --- Current replenishment data ---
aw25_repl_curr = pd.read_csv("replenishment_history/local_to_store_replenishment_sept_17_v1.csv")
basic_repl_curr = pd.read_csv("replenishment_history/old_season_sept_17_2025.csv")

common_cols_curr = aw25_repl_curr.columns.intersection(basic_repl_curr.columns)

aw25_curr_common = aw25_repl_curr[common_cols_curr]
basic_curr_common = basic_repl_curr[common_cols_curr]

current_rep_df = pd.concat([aw25_curr_common, basic_curr_common], ignore_index=True)

prev_forecast_col = 'FORECAST_2025-W38'
current_forecast_col = 'FORECAST_2025-W39'

# COMMAND ----------

import pandas as pd
from datetime import timedelta

omni_report_df = spark.sql("""
            select *
            from gold.`custom-analysis`.SKU_OMNI_REPORT 
            WHERE  
            REASON='SATISFIED'
            and
            OrderQty>FromStoreStock
            and (Order_date>='2025-09-14')
            ORDER BY Order_date desc
            """).toPandas()

omni_report_df['Order_date'] = pd.to_datetime(omni_report_df['Order_date'])

from pyspark.sql.functions import col

historic_sku_df = spark.sql("""
                    select 
                        LOCATION_CODE,
                        ITEMCODE as SKU_CODE, 
                        STK_DATE,
                        STOCK 
                        from gold.`custom-analysis`.sku_stock_history_dup
                        where STK_DATE>'2025-01-01'
        """)

def actual_current_stock(row,historic_sku_df):
    location_code = row['LOCATION_CODE']
    sku_code = row['Itemcode']
    order_date = row['Order_date']
    next_date = order_date + timedelta(days=1)
    
    stock_count = historic_sku_df.filter(
    (col("LOCATION_CODE") == location_code) &
    (col("SKU_CODE") == sku_code) &
    (col("STK_DATE") == next_date) 
    ).select("STOCK").collect()

    if len(stock_count)>0:
        stock_count = stock_count[0][0]  # get first row, first column
        stock_count = int(stock_count)  if stock_count is not None else None
    else:
        stock_count = 0  # or None, if not found
    return stock_count

omni_report_df['ACTUAL_STOCK'] = omni_report_df.apply(lambda row: actual_current_stock(row, historic_sku_df), axis=1)
omni_report_df['ACTUAL_STOCK'].fillna(0, inplace=True)


# previus replenishment result
prev_rep_df =  prev_rep_df.copy() #pd.read_csv("datasets/backup_report_july_25_2025/combine_result_aug_29_v2.csv") 

def prev_replenished_qty(row,prev_rep_df):
    location_code = row['LOCATION_CODE']
    sku_code = row['Itemcode']
    
    stock_count = prev_rep_df.loc[
        (prev_rep_df['LOCATION_CODE']==location_code) &
        (prev_rep_df['SKU_CODE']==sku_code)                          
        ,['OPEN_QTY','INTRANSIT_QTY','TOTAL_NEW_STORE_STOCK','REPLENISHED_QTY',prev_forecast_col]
        ]
    if stock_count.empty:
        return pd.Series([0,0])
    else:
        rep_qty = stock_count['REPLENISHED_QTY'].iloc[0]
        return pd.Series([
            stock_count['OPEN_QTY'].iloc[0],
            stock_count['INTRANSIT_QTY'].iloc[0],
            stock_count['TOTAL_NEW_STORE_STOCK'].iloc[0],
            rep_qty,
            stock_count[prev_forecast_col].iloc[0]
                           ])
omni_report_df[['PREV_OPEN_QTY','PREV_INTRANSIT_QTY','PREV_TOTAL_NEW_STORE_STOCK','PREV_REPLENISHMENT_QTY',f'PREV_{prev_forecast_col}']] = omni_report_df.apply(lambda row: prev_replenished_qty(row, prev_rep_df), axis=1)

current_rep_df = current_rep_df.copy()


def curr_replenished_qty(row,current_rep_df):
    location_code = row['LOCATION_CODE']
    sku_code = row['Itemcode']
    
    stock_count = current_rep_df.loc[
        (current_rep_df['LOCATION_CODE']==location_code) &
        (current_rep_df['SKU_CODE']==sku_code)                          
        ,['OPEN_QTY','INTRANSIT_QTY','TOTAL_NEW_STORE_STOCK','REPLENISHED_QTY',current_forecast_col]
        ]
    if stock_count.empty:
        return pd.Series([0,0])
    else:
        rep_qty = stock_count['REPLENISHED_QTY'].iloc[0]
        return pd.Series([
            stock_count['OPEN_QTY'].iloc[0],
            stock_count['INTRANSIT_QTY'].iloc[0],
            stock_count['TOTAL_NEW_STORE_STOCK'].iloc[0],
            rep_qty,
            stock_count[current_forecast_col].iloc[0]
                           ])
omni_report_df[['CUR_OPEN_QTY','CUR_INTRANSIT_QTY','CUR_TOTAL_NEW_STORE_STOCK','CUR_REPLENISHMENT_QTY',f'CUR_{current_forecast_col}']] = omni_report_df.apply(lambda row: curr_replenished_qty(row, current_rep_df), axis=1)

# COMMAND ----------

omni_report_df

# COMMAND ----------

prev_rep_df[(prev_rep_df['LOCATION_CODE']=='U021001') &
(prev_rep_df['SKU_CODE']=='106105-25004-034-LRG')]

# COMMAND ----------

omni_report_df

# COMMAND ----------

repl_df = spark.sql("""
        select 
        replenishment_date,
        SKU_CODE,
        TO_LOCATION as LOCATION_CODE,
        REPLENISHED_QTY
        from development.testdb.replenishment 
        where replenishment_date is not null
        """).toPandas()

repl_df.head()

# COMMAND ----------

repl_df[repl_df['SKU_CODE']=='101105-25041-219-SML']

# COMMAND ----------

p_attr = spark.sql("""
            select SKU_CODE as Itemcode, SEASON_NAME, SEASON_YEAR from gold.`custom-analysis`.product_attributes
            """).toPandas()
omni_report_df = omni_report_df.merge(p_attr, on='Itemcode', how='left')

# COMMAND ----------



# COMMAND ----------

omni_report_df[(omni_report_df['SEASON_YEAR']=='2025') &
               (omni_report_df['SEASON_NAME']=='AUTUMN WINTER')
               ]

# COMMAND ----------



# COMMAND ----------

repl_df['replenishment_date'] = pd.to_datetime(repl_df['replenishment_date'])

# COMMAND ----------

import pandas as pd

# Ensure datetime types
omni_report_df = omni_report_df.copy()
repl_df = repl_df.copy()
omni_report_df["Order_date"] = pd.to_datetime(omni_report_df["Order_date"])
repl_df["replenishment_date"] = pd.to_datetime(repl_df["replenishment_date"])

def get_prev_next_replenishment(row):
    same_sku_store = (
        repl_df["LOCATION_CODE"].eq(row["LOCATION_CODE"]) &
        repl_df["SKU_CODE"].eq(row["Itemcode"])
    )

    before = repl_df.loc[same_sku_store & (repl_df["replenishment_date"] < row["Order_date"])]
    after  = repl_df.loc[same_sku_store & (repl_df["replenishment_date"] > row["Order_date"])]

    # ---- previous (latest < order_date) ----
    if before.empty:
        prev_date = pd.NaT
        prev_qty = 0
    else:
        prev_date = before["replenishment_date"].max()
        prev_qty = before.loc[
            before["replenishment_date"].eq(prev_date), "REPLENISHED_QTY"
        ].sum()

    # ---- next (earliest > order_date) ----
    if after.empty:
        next_date = pd.NaT
        next_qty = 0
    else:
        next_date = after["replenishment_date"].min()
        next_qty = after.loc[
            after["replenishment_date"].eq(next_date), "REPLENISHED_QTY"
        ].sum()

    return pd.Series([prev_qty, prev_date, next_date, next_qty])

# Apply
omni_report_df[["Prev_Repl_Qty", "Last_Repl_Date", "Next_Repl_Date", "Next_Repl_Qty"]] = (
    omni_report_df.apply(get_prev_next_replenishment, axis=1)
)


# COMMAND ----------

omni_report_df['DAY_SINCE_LAST_REPLENISHMENT'] =  (omni_report_df['Order_date'] - omni_report_df['Last_Repl_Date']).dt.days

# COMMAND ----------

omni_report_df['DAY_SINCE_LATEST_REPLENISHMENT'] =  (omni_report_df['Next_Repl_Date'] - omni_report_df['Order_date']).dt.days

# COMMAND ----------

omni_report_df.head()

# COMMAND ----------

repl_df[(repl_df['LOCATION_CODE']=='K1607') &
(repl_df['SKU_CODE']=='166108-25022-502-LRG')]

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from gold.`custom-analysis`.sku_stock_intransit_op_cur_stock where ITEMCODE='165624-24001-F46-001' and LOCATION_CODE='K1608'

# COMMAND ----------

#
select 

# COMMAND ----------

omni_report_df['DAY_SINCE_LAST_REPLENISHMENT'] =  (omni_report_df['Order_date'] - pd.to_datetime('2025-08-29')).dt.days

# COMMAND ----------

df[(df['LOCATION_CODE']=='K1005') &
(df['SKU_CODE']=='101108-25099-005-XLR')]

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from gold.`custom-analysis`.sku_stock_intransit_op_cur_stock where ITEMCODE='101105-25024-005-XXL' and LOCATION_CODE='K1002'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from gold.`custom-analysis`.sku_stock_history_dup where LOCATION_CODE='K1002' and 
# MAGIC ITEMCODE='101105-25024-005-XXL' and STK_DATE='2025-08-30'

# COMMAND ----------

display(omni_report_df)

# COMMAND ----------

omni_report_df[(omni_report_df['Itemcode']=='108106-25008-042-XXL') &
(omni_report_df['LOCATION_CODE']=='K1003')]

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC select * from gold.`custom-analysis`.sku_clustering_temp_sales_transfer 
# MAGIC where 
# MAGIC SKU_CODE='108106-25008-042-XXL' and
# MAGIC LOCATION_CODE='K1003'

# COMMAND ----------

omni_report_df[(omni_report_df['Itemcode']=='108106-25008-042-XXL') &
(omni_report_df['LOCATION_CODE']=='K1003')]

# COMMAND ----------

omni_report_df.to_csv("omni_channel.csv", index=False)

# COMMAND ----------

df = pd.read_csv("local_to_store_replenishment_sep_10_v1.csv", index_col='Unnamed: 0')

# COMMAND ----------

result_temp[(result_temp['SKU_CODE']=='108102-24002-026-LRG') &
(result_temp['TO_LOCATION']=='K1002')]

# COMMAND ----------

df[(df['SKU_CODE']=='108109-25032-067-XLR') &
(df['LOCATION_CODE']=='U011005')]

# COMMAND ----------

# MAGIC %sql
# MAGIC select STK_DATE,ITEMCODE,OPTION_CODE,LOCATION_CODE,STOCK from gold.`custom-analysis`.sku_stock_history_dup 
# MAGIC where 
# MAGIC ITEMCODE='168109-25028-005-MED' and
# MAGIC LOCATION_CODE='K1606'
# MAGIC order by STK_DATE desc

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from gold.`custom-analysis`.sku_stock_intransit_op_cur_stock where LOCATION_CODE='K1606' and ITEMCODE='168109-25028-005-MED'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from gold.`custom-analysis`.sku_stock_intransit_op_cur_stock where LOCATION_CODE='K1002' and ITEMCODE='108105-24017-502-MED'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from gold.`custom-analysis`.sku_stock_history_dup 
# MAGIC where LOCATION_CODE='K1002' and ITEMCODE='108105-24017-502-MED'
# MAGIC order by STK_DATE desc
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from gold.`custom-analysis`.sku_stock_intransit_op_cur_stock

# COMMAND ----------

!cp *.csv datasets/backup_report_july_25_2025

# COMMAND ----------

!rm -rf *.csv

# COMMAND ----------

df = pd.read_csv("replenishment_history/local_to_store_replenishment_sept_17_v1.csv")

# COMMAND ----------

df[(df['SKU_CODE']=='108109-24013-005-MED') &
   (df['LOCATION_CODE']=='K1602')]

# COMMAND ----------

omni_report_df[(omni_report_df['Itemcode']=='108106-25013-290-XXL') &
(omni_report_df['LOCATION_CODE']=='K1001')]

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from gold.`custom-analysis`.sku_box_quantity where LOCATION_CODE='K9901' and SKU_CODE='108106-25013-290-XXL'

# COMMAND ----------

import pandas as pd

# COMMAND ----------

df = pd.read_csv("replenishment_history/local_to_store_replenishment_sept_14_v1.csv")

# COMMAND ----------

df.loc[(df['SKU_CODE'].isin(['108101-25029-067-XXL',
                        '108101-25029-067-XLR',
                        '108101-25029-067-XSN',
                        '108101-25020-066-MSP',
                        '108101-25020-066-SML'
                         ])) &
   (df['COUNTRY']=='UAE'),['SKU_CODE','WAREHOUSE_CODE','WH_QTY']]

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from gold.`custom-analysis`.sku_box_quantity 
# MAGIC where
# MAGIC SKU_CODE in (
# MAGIC '108101-25029-067-XXL',
# MAGIC '108101-25029-067-XLR',
# MAGIC '108101-25029-067-XSM',
# MAGIC '108101-25020-D66-MED',
# MAGIC '108101-25020-D66-XSM',
# MAGIC '108101-25020-D66-SML',
# MAGIC '108101-25029-067-XLR'
# MAGIC )
# MAGIC and 
# MAGIC LOCATION_CODE='U019901' 

# COMMAND ----------

