# Databricks notebook source
import pandas as pd
import re
import numpy as np
import seaborn as sns
from datetime import date, timedelta
from pyspark.sql.functions import col, date_format, weekofyear, year, lpad, concat_ws
from pyspark.sql import functions as F

from scipy.stats import norm

# COMMAND ----------

warehouse_sku_df = spark.sql("""
          SELECT 
          distinct LOCATION_CODE as WAREHOUSE_CODE,
          SKU_CODE,
          OPTION_CODE,
          SIZE_CODE,
          COUNTRY,
          WAREHOUSE_STOCK_1 as WH_QTY
          FROM 
          gold.`custom-analysis`.SKU_BOX_QUANTITY
          where LOCATION_CODE not in ('101')
          """).toPandas()
warehouse_sku_df.head()

# COMMAND ----------

host_warehouse_stock = spark.sql("""
          SELECT 
          LOCATION_CODE as WAREHOUSE_CODE,
          SKU_CODE,
          OPTION_CODE,
          SIZE_CODE,
          COUNTRY,
          BOXQTY,
          WAREHOUSE_STOCK_1 as HOSTWATEHOUSE_STOCK
          FROM 
          gold.`custom-analysis`.SKU_BOX_QUANTITY
          WHERE LOCATION_CODE='101' 
          """).toPandas()
host_warehouse_stock.head()

# COMMAND ----------

host_warehouse_stock.head()

# COMMAND ----------

from pyspark.sql import functions as F
# Load the data
return_sku_df = spark.sql("""
                          SELECT 
                          DISTINCT SKU_CODE,
                          OPTION_CODE,
                          SIZE_CODE,
                          FROM_LOCATION AS LOCATION_CODE,
                          TO_LOCATION,
                          TRANSFER_TYPE
                           FROM gold.`custom-analysis`.oi_cardex_dup
                           WHERE
                           rn = 1
                           """)

store_current_stock = spark.sql(
                        """
                    SELECT 
                    ITEMCODE AS SKU_CODE, 
                    LOCATION_CODE,
                     (IN_STOCK + INTRANSIT_QTY) AS STORE_STOCK
                    from gold.`custom-analysis`.sku_stock_intransit_op_cur_stock
                    """
                    )

return_sku_df = return_sku_df.join(
    store_current_stock,
    on=['SKU_CODE', 'LOCATION_CODE'],
    how='left'
)


#  Step 1: Count unique SIZE_CODEs for TRANSFER OUT
transfer_out_counts = return_sku_df \
    .filter(
        (F.col("TRANSFER_TYPE") == "TRANSFER OUT") & 
        (F.col("STORE_STOCK") == 0)
    ).groupBy("LOCATION_CODE", "OPTION_CODE") \
    .agg(F.countDistinct("SIZE_CODE").alias("size_code_transfer_out_count"))

# Step 2: Count unique SIZE_CODEs overall
unique_sizes = return_sku_df \
    .groupBy("LOCATION_CODE", "OPTION_CODE") \
    .agg(F.countDistinct("SIZE_CODE").alias("unique_size_codes"))

# Step 3: Join both counts
result = unique_sizes.join(transfer_out_counts, on=["LOCATION_CODE", "OPTION_CODE"], how="left") \
    .withColumn("size_code_transfer_out_count", F.coalesce(F.col("size_code_transfer_out_count"), F.lit(0))) \
    .withColumn("unhealthy_option_cov", F.col("size_code_transfer_out_count") / F.col("unique_size_codes")) \
    .withColumn("healthy_cov", F.lit(1.0) - F.col("unhealthy_option_cov"))


option_cov_df = result.toPandas()
option_cov_df.head()
broken_return_option_df = option_cov_df[option_cov_df['healthy_cov']<0.50]
broken_return_option_df.head()

# COMMAND ----------

historic_sku_sales_df = spark.sql(
    """
        SELECT 
        SALES_DATE,
        LOCATION_CODE,STORE_TYPE,
        GRADE,COUNTRY,GROUP_NAME,
        SKU_CODE, OPTION_CODE,
        SIZE_CODE,LAUNCH_DATE,
        BRAND_NAME,SUB_BRAND_NAME,
        SIZE_GROUP,SEASON_NAME, SUB_SEASON_NAME,
        SUM(TOTAL_QUANTITY) AS TOTAL_QUANTITY
        FROM gold.`custom-analysis`.sku_clustering_temp_sales_transfer
        WHERE SALES_DATE BETWEEN DATE(CURRENT_DATE - INTERVAL 56 DAY) AND CURRENT_DATE
        -- AND      
        -- SKU_CODE in 
        -- (select distinct SKU_CODE  from gold.`custom-analysis`.product_attributes WHERE SEASON_NAME_YEAR in ('SPRING SUMMER 2025','AUTUMN WINTER 2025'))
        AND
        TRANS_ACTIVE='1'
        AND
        BRAND_NAME in ('RIVA','CHOICE','RIVA KIDS')
        GROUP BY
        SALES_DATE,SIZE_GROUP,
        LOCATION_CODE,STORE_TYPE,
        GRADE,COUNTRY,GROUP_NAME,
        SKU_CODE, OPTION_CODE,
        SIZE_CODE,LAUNCH_DATE,
        BRAND_NAME,SUB_BRAND_NAME,
        SEASON_NAME, SUB_SEASON_NAME
    """).toPandas()

historic_sku_sales_df['SALES_DATE'] = pd.to_datetime(historic_sku_sales_df['SALES_DATE'])

# COMMAND ----------

historic_sku_sales_df['GROUP_NAME'].fillna(historic_sku_sales_df['GROUP_NAME'].mode()[0], inplace=True)

# COMMAND ----------

historic_sku_sales_df['SALES_DATE']     = pd.to_datetime(historic_sku_sales_df['SALES_DATE'])
historic_sku_sales_df['TOTAL_QUANTITY'] = pd.to_numeric(historic_sku_sales_df['TOTAL_QUANTITY'], errors='coerce').fillna(0)
cutoff = historic_sku_sales_df['SALES_DATE'].max() - pd.Timedelta(days=56)
final_historical_sales_df = historic_sku_sales_df[historic_sku_sales_df['SALES_DATE'] >= cutoff]

# COMMAND ----------

today = final_historical_sales_df['SALES_DATE'].max().normalize()
days_diff   = (today - final_historical_sales_df['SALES_DATE']).dt.days
week_number = days_diff // 7              # 0 = most-recent week, 1 = previous, 

# --- 4.  Compute the window-end and window-start for each row -------------
window_end   = today - pd.to_timedelta(week_number * 7,  unit='D')
window_start = window_end - pd.Timedelta(days=7)   # 7 days back from the end date

# --- 5.  Build a nice label like  “2025-02-05-2025-02-12” ----------------
final_historical_sales_df['WEEK_LABEL'] = (
        window_start.dt.strftime('%Y-%m-%d')
        + '-'
        + window_end.dt.strftime('%Y-%m-%d')
)

# optional: order by time so most-recent week appears first
final_historical_sales_df.sort_values(['WEEK_LABEL', 'SALES_DATE'], ascending=[True, True], inplace=True)

# COMMAND ----------

weekly_sales_qty_cols = sorted(final_historical_sales_df['WEEK_LABEL'].unique())

# COMMAND ----------

id_cols = [
    'LOCATION_CODE', 'STORE_TYPE', 'COUNTRY',
    'SKU_CODE', 'OPTION_CODE', 'SIZE_CODE', 'LAUNCH_DATE',
    'BRAND_NAME', 'SUB_BRAND_NAME','GRADE','GROUP_NAME','SIZE_GROUP'
    ]

# COMMAND ----------

agg = (final_historical_sales_df
       .groupby(id_cols + ['WEEK_LABEL'], as_index=False)
       .agg(QTY_SOLD=('TOTAL_QUANTITY', 'sum')))

# COMMAND ----------

pivot = (agg
         .pivot_table(index=id_cols,
                      columns='WEEK_LABEL',
                      values='QTY_SOLD',
                      aggfunc='sum',
                      fill_value=0
                      )).reset_index()

# COMMAND ----------

# ---------------------------------------------------------------------------
# libraries
# ---------------------------------------------------------------------------
from pyspark.sql import functions as F
from pyspark.sql.window import Window
import pandas as pd

# ---------------------------------------------------------------------------
# 1. Pull the last 42 calendar days of stock history
# ---------------------------------------------------------------------------
historical_week_stock_df = spark.sql("""
    SELECT
        STK_DATE,
        LOCATION_CODE,
        ITEMCODE        AS SKU_CODE,
        STOCK           AS CURRENT_STORE_STOCK
    FROM  gold.`custom-analysis`.SKU_STOCK_HISTORY_DUP
    WHERE STK_DATE BETWEEN DATE(CURRENT_DATE - INTERVAL 56 DAY) AND CURRENT_DATE
""")

# ---------------------------------------------------------------------------
# 2. Anchor the “today” reference at the latest STK_DATE in the dataset
# ---------------------------------------------------------------------------
today_str = (historical_week_stock_df
             .agg(F.max("STK_DATE").alias("today"))
             .collect()[0]["today"].strftime("%Y-%m-%d"))
today = F.lit(today_str).cast("date")

# ---------------------------------------------------------------------------
# 3. Work out which 7-day bucket each row belongs to
#    0 = most-recent week (today-7 → today], 1 = previous week, …
# ---------------------------------------------------------------------------
days_back   = F.datediff(today, F.col("STK_DATE"))
week_number = F.floor(days_back / 7).cast("int")            # INT is mandatory

week_offset_days = (week_number * 7).cast("int")            # still INT

window_end   = F.date_sub(today, week_offset_days)          # inclusive upper bound
window_start = F.date_sub(window_end, F.lit(7))             # exclusive lower bound

historical_week_stock_df = (historical_week_stock_df
    .withColumn("WEEK_NUM",  week_number)
    .withColumn("WIN_START", window_start)
    .withColumn("WIN_END",   window_end)
    .withColumn(
        "WEEK_LABEL",
        F.concat_ws("-",
            F.date_format("WIN_START", "yyyy-MM-dd"),
            F.date_format("WIN_END",   "yyyy-MM-dd")
        )
    )
)

# ---------------------------------------------------------------------------
# 4. Keep only the latest snapshot within each bucket / store / SKU
# ---------------------------------------------------------------------------
w = Window.partitionBy("LOCATION_CODE", "SKU_CODE", "WEEK_LABEL") \
          .orderBy(F.col("STK_DATE").desc())

latest_stock_df = (historical_week_stock_df
    .withColumn("rn", F.row_number().over(w))
    .filter("rn = 1")
    .select("LOCATION_CODE", "SKU_CODE", "WEEK_LABEL",
            F.round("CURRENT_STORE_STOCK").alias("CURRENT_STORE_STOCK"))
)

# ---------------------------------------------------------------------------
# 5. Spark → Pandas (you can keep it in Spark and use .pivot if you prefer)
# ---------------------------------------------------------------------------
pdf = latest_stock_df.toPandas()

# Clean negatives / nulls
pdf.loc[pdf["CURRENT_STORE_STOCK"] < 0, "CURRENT_STORE_STOCK"] = 0
pdf["CURRENT_STORE_STOCK"].fillna(0, inplace=True)

# ---------------------------------------------------------------------------
# 6. Pivot so every 7-day bucket becomes its own column
# ---------------------------------------------------------------------------
pdf = (pdf
    .pivot_table(index=["LOCATION_CODE", "SKU_CODE"],
                 columns="WEEK_LABEL",
                 values="CURRENT_STORE_STOCK",
                 aggfunc="first",
                 fill_value=0)
    .reset_index()
)

# ---------------------------------------------------------------------------
# 7. Add the -HIST suffix to bucket columns
# ---------------------------------------------------------------------------
pdf.columns = [c if c in ("LOCATION_CODE", "SKU_CODE") else f"{c}-HIST"
               for c in pdf.columns]

# ---------------------------------------------------------------------------
# 8. List the historical columns (optional) and preview
# ---------------------------------------------------------------------------
hist_stock_qty_cols = [c for c in pdf.columns
                       if c not in ("LOCATION_CODE", "SKU_CODE")]

print("HISTORICAL SKU Columns:", hist_stock_qty_cols)

# COMMAND ----------

pdf.head()

# COMMAND ----------

store_sku_df = pivot.merge(pdf, on=['LOCATION_CODE','SKU_CODE'], how='left')

# COMMAND ----------

week_cols = [c for c in store_sku_df.columns if re.match(r"\d{4}-\d{2}-\d{2}-\d{4}-\d{2}-\d{2}", c)]
week_cols = [c for c in week_cols if 'HIST' not in c]
# sort by the *start* date of the interval so left-to-right = oldest-→-newest
week_cols = sorted(week_cols,
                   key=lambda c: pd.to_datetime(c.split('-')[0]))   # 1st date in each lab

# COMMAND ----------

# ---------------- business rules (keep as‑is) -----------------
CYCLE_DAYS_HOST_TO_REGION   = 14      # review period (order frequency)
TRANSIT_DAYS_HOST_TO_REGION = 7       # lead time
SERVICE_LEVEL               = 0.60    # cycle‑service target
Z_VALUE = norm.ppf(1 - SERVICE_LEVEL / 2)   # ≈ 0.8416

# ---------------- new forecasting helper ----------------------
def store_next3_with_buffer(row):
    """
    Forecast next‑3‑week demand + one‑week safety stock, but
    return 0‑demand when the last 4 weeks were all zeros.
    """
    y   = row[week_cols].astype(float).to_numpy()
    y4  = y[-2:]                      # most‑recent 3 weeks

    # ⇲ Hard stop — no recent sales → no short‑term demand
    if y4.sum() == 0:
        return pd.Series([0, 0, 0], index=["NEXT_W1", "NEXT_W2", "NEXT_W3"])

    # Otherwise follow your original logic (slightly guarded)
    recent_non_zero = (y4 > 0).sum()
    ros = y4.mean() if recent_non_zero >= 2 else y.mean()

    # Sample std only if there was *any* recent activity, else 0
    std = y4.std(ddof=1) if recent_non_zero else 0.0
    ss  = max(0, Z_VALUE * std)       # one‑week safety stock

    f   = max(0, int(np.ceil(ros + ss)))
    return pd.Series([f, f, f], index=["NEXT_W1", "NEXT_W2", "NEXT_W3"])


# apply to your dataframe
store_sku_df[["NEXT_W1", "NEXT_W2", "NEXT_W3"]] = (
    store_sku_df.apply(store_next3_with_buffer, axis=1)
)


# COMMAND ----------

store_demand = (
    store_sku_df.groupby(["LOCATION_CODE","SKU_CODE"], as_index=False)
      [["NEXT_W2","NEXT_W3"]]
      .sum()
      .assign(DEMAND_COVERAGE=lambda x: x["NEXT_W2"])
)
store_sku_df = store_sku_df.merge(store_demand[['LOCATION_CODE','SKU_CODE','DEMAND_COVERAGE']], on=['LOCATION_CODE','SKU_CODE'], how='left')

# COMMAND ----------

store_sku_df.head()

# COMMAND ----------

# store_sku_df.loc[(store_sku_df[WEEK_COLS[-1]]>0) & (store_sku_df['DEMAND_COVERAGE']<=0)]

# COMMAND ----------

current_stock_df = spark.sql("""
                            select 
                            LOCATION_CODE,
                            ITEMCODE as SKU_CODE,
                            Intransit_QTY AS INTRANSIT_QTY,
                            INTERNATIONAL_INTRANSIT_QTY AS FRGN_INTRANSIT,
                            LOCAL_INTRANSIT_QTY,
                            Open_QTY AS OPEN_QTY,
                            (IN_STOCK + LOCAL_INTRANSIT_QTY+INTERNATIONAL_INTRANSIT_QTY + Open_QTY) AS TOTAL_NEW_STORE_STOCK,
                            IN_STOCK as CURRENT_STORE_STOCK
                            from gold.`custom-analysis`.SKU_stock_intransit_op_cur_stock 
                            WHERE  
                            ITEMCODE in (select distinct SKU_CODE  from gold.`custom-analysis`.product_attributes WHERE SEASON_NAME_YEAR IN ('SPRING SUMMER 2025','AUTUMN WINTER 2025'))
                            AND
                            BRAND_NAME 
                            IN 
                            ('RIVA','CHOICE', 'RIVA KIDS')
                            """).toPandas()

min_max_qty_df = spark.sql(f"""Select distinct GROUP_NAME,SCALE_CODE SIZE_GROUP, SIZE_CODE,SHOP_GRADE GRADE, MINQTY,MAXQTY from gold.`custom-analysis`.wms_shop_distribution_Dup 
                           """).toPandas()
min_max_qty_df['MINQTY'] = min_max_qty_df['MINQTY'].astype(int)
min_max_qty_df['MAXQTY'] = min_max_qty_df['MAXQTY'].astype(int)

current_stock_df.head()

# COMMAND ----------

sku_store_df = store_sku_df.merge(current_stock_df, on=['SKU_CODE', 'LOCATION_CODE'], how='left')
sku_store_df = sku_store_df.merge(min_max_qty_df, on=['GROUP_NAME','SIZE_GROUP','GRADE','SIZE_CODE'], how='left')
sku_store_df.head()

# COMMAND ----------

sku_store_df.loc[
    (sku_store_df['MINQTY'].isnull()) &(sku_store_df['GRADE']=='C') ,
    ['MINQTY','MAXQTY']] = (1, 1)

sku_store_df.loc[
    (sku_store_df['MINQTY'].isnull()) &(sku_store_df['GRADE']=='B'), 
    ['MINQTY','MAXQTY']] = (1, 2)

sku_store_df.loc[
    (sku_store_df['MINQTY'].isnull()) &(sku_store_df['GRADE']=='A'), 
    ['MINQTY','MAXQTY']] = (2, 3)

# COMMAND ----------

sku_store_df.fillna(0, inplace=True)

# COMMAND ----------

size_code_stock_df = sku_store_df.groupby(['LOCATION_CODE','OPTION_CODE','SIZE_CODE'], as_index=False).agg({'TOTAL_NEW_STORE_STOCK':'sum'})

option_stock_df = (
    size_code_stock_df
    .groupby(['LOCATION_CODE', 'OPTION_CODE'])['TOTAL_NEW_STORE_STOCK']
    .sum()
    .reset_index()
    .rename(columns={'TOTAL_NEW_STORE_STOCK': 'OPTION_TOTAL_STOCK'})
)

option_stock_size_df = (
    size_code_stock_df
    .groupby(['LOCATION_CODE', 'OPTION_CODE'])
    .apply(lambda x: dict(zip(x['SIZE_CODE'], x['TOTAL_NEW_STORE_STOCK'])))
    .reset_index(name='SIZE_CODE_STOCK_DICT')
)

option_stock_df = option_stock_size_df.merge(option_stock_df, on=['LOCATION_CODE','OPTION_CODE'], how='left')

# COMMAND ----------

sku_store_df = sku_store_df.merge(option_stock_df, on=['LOCATION_CODE', 'OPTION_CODE'], how='left')
sku_store_df.head()

# COMMAND ----------

# sku_store_df.loc[
#     (sku_store_df['DEMAND_COVERAGE'] == 0) &
#     (sku_store_df['TOTAL_NEW_STORE_STOCK'] == 0) &
#     (sku_store_df['OPTION_TOTAL_STOCK'] > 0),
#     'DEMAND_COVERAGE'
# ]  = sku_store_df.loc[
#     (sku_store_df['DEMAND_COVERAGE'] == 0) &
#     (sku_store_df['TOTAL_NEW_STORE_STOCK'] == 0) &
#     (sku_store_df['OPTION_TOTAL_STOCK'] > 0),
#     'MINQTY'
# ]

# COMMAND ----------

warehouse_qty_df = warehouse_sku_df.groupby(['WAREHOUSE_CODE','SKU_CODE','COUNTRY'],as_index=False).agg({'WH_QTY':'sum'})

# COMMAND ----------

warehouse_qty_df.head()

# COMMAND ----------

# --- 1.  Attach warehouse stock -------------------------------------------
final_sku_stock_df = (sku_store_df
      .merge(warehouse_qty_df[['WAREHOUSE_CODE','SKU_CODE','COUNTRY','WH_QTY']],
             on=['COUNTRY', 'SKU_CODE'],
             how='left')
      .fillna({'WH_QTY': 0}))

# COMMAND ----------

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='KUWAIT'),
                   'WAREHOUSE_CODE'
                   ] = 'K9901'

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='BAHRAIN'),
                   'WAREHOUSE_CODE'
                   ] = 'B97'

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='UAE'),
                   'WAREHOUSE_CODE'
                   ] = 'U019901'

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='SAUDI ARABIA'),
                   'WAREHOUSE_CODE'
                   ] = 'S99'


final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='QATAR'),
                   'WAREHOUSE_CODE'
                   ] = 'Q9901'

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='OMAN'),
                   'WAREHOUSE_CODE'
                   ] = 'O019901'

# COMMAND ----------

WEEK_COLS = weekly_sales_qty_cols.copy()
STOCK_COLS = list(hist_stock_qty_cols).copy()

pairwise_good = [
    final_sku_stock_df[week].where(final_sku_stock_df[stock] > 0, 0)          # keep sales only if opening stock > 0
    for week, stock in zip(WEEK_COLS, STOCK_COLS)
]
good_sales_total = pd.concat(pairwise_good, axis=1).sum(axis=1)
good_weeks_count = (final_sku_stock_df[STOCK_COLS] > 0).sum(axis=1)       # how many weeks had stock

# daily ROS = total sales / (good_weeks × 7)
final_sku_stock_df["ROS_DAY"] = (
    good_sales_total /
    (good_weeks_count.replace(0, np.nan) * 16)
).fillna(0)

miss_mask          = final_sku_stock_df[STOCK_COLS].eq(0) & final_sku_stock_df[WEEK_COLS].eq(0)
miss_weeks_cnt     = miss_mask.sum(axis=1)
# final_sku_stock_df["MISSED_UNITS"]  = (final_sku_stock_df["ROS_DAY"] * 7 * miss_weeks_cnt).round()

# COMMAND ----------

final_sku_stock_df = final_sku_stock_df.merge(host_warehouse_stock[['SKU_CODE','HOSTWATEHOUSE_STOCK']], how='left')
final_sku_stock_df.head()

# COMMAND ----------

final_sku_stock_df['STOCK_LAST_4W'] = final_sku_stock_df[hist_stock_qty_cols[-4:]].sum(axis=1)

# COMMAND ----------

final_sku_stock_df[final_sku_stock_df['OPTION_CODE']=='101109-25120-024']

# COMMAND ----------

condition = (
    (final_sku_stock_df['STOCK_LAST_4W'] == 0) &
    (final_sku_stock_df['DEMAND_COVERAGE'] == 0) &
    ((final_sku_stock_df['WH_QTY'] + final_sku_stock_df['HOSTWATEHOUSE_STOCK']) > 0) &
    (final_sku_stock_df['ROS_DAY'] > 0.1)
)


final_sku_stock_df.loc[condition,'DEMAND_COVERAGE'] = np.round(final_sku_stock_df.loc[condition,'ROS_DAY'] * 7)

# COMMAND ----------

# sku_transfer_out_df = spark.sql("""
# SELECT 
# SKU_CODE,
# FROM_LOCATION AS LOCATION_CODE,
# TO_LOCATION,
# DATE(TRANS_DT) TRANSFER_DATE,
# QUANTITY AS QUANTITY_TRANSFERED,
# TRANSFER_TYPE
#  FROM gold.`custom-analysis`.OI_CARDEX_DUP
#  WHERE TRANS_DT>'2024'
# """).toPandas()

# final_sku_stock_df = final_sku_stock_df.merge(sku_transfer_out_df, on=['SKU_CODE', 'LOCATION_CODE'], how='left')

# COMMAND ----------

final_sku_stock_df = final_sku_stock_df.merge(broken_return_option_df, on=['LOCATION_CODE','OPTION_CODE'], how='left')
final_sku_stock_df.head()

# COMMAND ----------

mask = (
    (final_sku_stock_df[WEEK_COLS[-2:]].sum(axis=1) >=final_sku_stock_df['DEMAND_COVERAGE']) & 
    (final_sku_stock_df['DEMAND_COVERAGE']>0) &
    (final_sku_stock_df[WEEK_COLS[-2:]].sum(axis=1)<=5)
)
final_sku_stock_df.loc[mask, 'DEMAND_COVERAGE'] = np.round(final_sku_stock_df.loc[mask, WEEK_COLS[-2:]].sum(axis=1) * 1.5)

# COMMAND ----------

mask = (
    (final_sku_stock_df[WEEK_COLS[-2:]].sum(axis=1) >=final_sku_stock_df['DEMAND_COVERAGE']) & 
    (final_sku_stock_df['DEMAND_COVERAGE']>0) &
    (final_sku_stock_df[WEEK_COLS[-2:]].sum(axis=1)>5)
)
final_sku_stock_df.loc[mask, 'DEMAND_COVERAGE'] = np.round(final_sku_stock_df.loc[mask, WEEK_COLS[-2:]].sum(axis=1) * 1.2)

# COMMAND ----------

final_sku_stock_df.loc[(final_sku_stock_df['OPTION_CODE']=='101108-25129-067') & (final_sku_stock_df['COUNTRY']=='KUWAIT') & (final_sku_stock_df['LOCATION_CODE']=='K1005')
                       ,['LOCATION_CODE','OPTION_CODE','SKU_CODE'] + WEEK_COLS+['DEMAND_COVERAGE']+['TOTAL_NEW_STORE_STOCK']]

# COMMAND ----------

final_sku_stock_df[
    (final_sku_stock_df['COUNTRY']=='KUWAIT') &
(final_sku_stock_df['SKU_CODE']=='101108-25129-067-MED')
]

# COMMAND ----------

final_sku_stock_df.loc[
    (final_sku_stock_df['healthy_cov'].notnull()),
    'DEMAND_COVERAGE'
    ] = 0

# COMMAND ----------

MISSED_LAMBDA = 0.20                             # weight on missed units
# High‑priority order: lower number = higher priority
STORE_PRIORITY_MAP = {"A": 0, "B": 1, "C": 2, "OUTLET": 3}

# COMMAND ----------

final_sku_stock_df["PRIORITY_RANK"]  = final_sku_stock_df["GRADE"].map(STORE_PRIORITY_MAP).fillna(99).astype(int)

# COMMAND ----------

# mask = (final_sku_stock_df['DEMAND_COVERAGE']>0) & (final_sku_stock_df['DEMAND_COVERAGE'] < final_sku_stock_df['MINQTY'])
# final_sku_stock_df.loc[mask, 'DEMAND_COVERAGE'] = final_sku_stock_df.loc[mask, 'MINQTY']

# COMMAND ----------

final_sku_stock_df["RAW_NEED"] = (final_sku_stock_df['DEMAND_COVERAGE'].astype(float) - final_sku_stock_df["TOTAL_NEW_STORE_STOCK"].astype(float)).clip(lower=0)
#final_sku_stock_df["ADJ_NEED"] = final_sku_stock_df["RAW_NEED"].astype(float) + final_sku_stock_df["MISSED_UNITS"].astype(float)

# COMMAND ----------

def compute_need(adj, lo, hi):
    if adj == 0:
        return 0                               # ① no demand
    elif adj <=lo:
        return lo                              # ② bump up to minimum                            # ③ cap at maximum
    else:
        return adj                             # ④ use adj as‑is

final_sku_stock_df["NEED"] = final_sku_stock_df.apply(
    lambda r: compute_need(r["RAW_NEED"], r["MINQTY"], r["MAXQTY"]),
    axis=1
).astype(int)


# COMMAND ----------

final_need_df = final_sku_stock_df[['LOCATION_CODE','STORE_TYPE','COUNTRY','OPTION_CODE','SKU_CODE','BRAND_NAME','SUB_BRAND_NAME','GROUP_NAME','DEMAND_COVERAGE','TOTAL_NEW_STORE_STOCK','WH_QTY','NEED','WAREHOUSE_CODE']]

# COMMAND ----------

final_need_df.rename({'WH_QTY':'WH_STOCK_QTY'}, axis=1, inplace=True)

# COMMAND ----------

final_need_df[
    (final_need_df['COUNTRY']=='KUWAIT') &
(final_need_df['SKU_CODE']=='101108-25129-067-MED')
]['NEED'].sum()

# COMMAND ----------

final_need_df.loc[(final_need_df['SKU_CODE']=='101108-25129-067-MED') &
(final_need_df['COUNTRY']=='KUWAIT')]

# COMMAND ----------

final_need_df.head()

# COMMAND ----------

total_store_stock_df = final_need_df.groupby(['COUNTRY', 'SKU_CODE'], as_index=False).agg({'TOTAL_NEW_STORE_STOCK': 'sum'}).rename({'TOTAL_NEW_STORE_STOCK':'TOTAL_STORE_STOCK'})

# COMMAND ----------

country_sku_demand = (
    final_need_df.groupby(['COUNTRY','BRAND_NAME','SUB_BRAND_NAME','GROUP_NAME','WAREHOUSE_CODE','SKU_CODE'])
    .agg(
        TOTAL_NEED=('NEED', 'sum'),
        TOTAL_LOCAL_WH_STOCK=('WH_STOCK_QTY', 'first')
    )
    .reset_index()
)

# COMMAND ----------

country_sku_demand = country_sku_demand[country_sku_demand['TOTAL_NEED']>0]

# COMMAND ----------

country_sku_demand

# COMMAND ----------

spark.conf.set('spark.sql.ansi.enabled', False)

# COMMAND ----------

country_df = spark.sql("""WITH country_sales AS (
    SELECT 
        CASE 
            WHEN Market = 'UAE' THEN 'UAE'
            WHEN Market = 'KWT' THEN 'KUWAIT'
            WHEN Market = 'BAH' THEN 'BAHRAIN'
            WHEN Market = 'OMN' THEN 'OMAN'
            WHEN Market = 'SUD' THEN 'SAUDI ARABIA'
            WHEN Market = 'QA'  THEN 'QATAR'
        END AS COUNTRY,
        SKU_CODE,
        SUM(SaleQty) AS SALES_QTY,
        SUM(InQty) AS RECIEVED_QTY
    FROM gold.`custom-analysis`.sku_host_to_local
    WHERE Market IN ('UAE','SUD','BAH','KWT','OMN','QA')
      AND SKU_CODE IN 
      (select distinct SKU_CODE  from gold.`custom-analysis`.product_attributes 
      WHERE SEASON_NAME_YEAR IN ('SPRING SUMMER 2025','AUTUMN WINTER 2025'))
    GROUP BY 
        CASE 
            WHEN Market = 'UAE' THEN 'UAE'
            WHEN Market = 'KWT' THEN 'KUWAIT'
            WHEN Market = 'BAH' THEN 'BAHRAIN'
            WHEN Market = 'OMN' THEN 'OMAN'
            WHEN Market = 'SUD' THEN 'SAUDI ARABIA'
            WHEN Market = 'QA'  THEN 'QATAR'
        END,
        SKU_CODE
),
global_sales AS (
    SELECT 
        SKU_CODE,
        SUM(SALES_QTY) AS GLOBAL_SALES_QTY
    FROM country_sales
    GROUP BY SKU_CODE
),
global_received AS (
    SELECT 
        SKU_CODE,
        SUM(RECIEVED_QTY) AS GLOBAL_RECIEVED
    FROM country_sales
    GROUP BY SKU_CODE
)
SELECT 
    cs.COUNTRY,
    cs.SKU_CODE,
    cs.SALES_QTY,
    cs.RECIEVED_QTY,
    gs.GLOBAL_SALES_QTY,
    gr.GLOBAL_RECIEVED,
    cs.SALES_QTY / gs.GLOBAL_SALES_QTY AS SALES_MIX,
    cs.RECIEVED_QTY / gr.GLOBAL_RECIEVED AS RECIVE_MIX
FROM country_sales cs
LEFT JOIN global_sales gs ON cs.SKU_CODE = gs.SKU_CODE
LEFT JOIN global_received gr ON cs.SKU_CODE = gr.SKU_CODE
""").toPandas()



df = country_df.copy() 
df['MIX_GAP']        = df['SALES_MIX'] - df['RECIVE_MIX']
# 1️⃣  Mix-gap drives the priority
df['MIX_GAP'] = (
    df['SALES_MIX'] - df['RECIVE_MIX']
)

# 2️⃣  Rank countries inside each SKU (1 = replenish first)
df['COUNTRY_PRIORITY'] = (
    df
        .groupby('SKU_CODE')['MIX_GAP']          # per SKU
        .rank(method='dense',                    # 1,2,3… without ties gaps
              ascending=False)                   # bigger gap → higher priority
)


# COMMAND ----------

country_sku_demand = country_sku_demand.merge(df, on=['COUNTRY','SKU_CODE'], how='left').fillna(0)

# COMMAND ----------

region_stock_df = spark.sql("""
select  SKU_CODE,  
        CASE 
            WHEN Market = 'UAE' THEN 'UAE'
            WHEN Market = 'KWT' THEN 'KUWAIT'
            WHEN Market = 'BAH' THEN 'BAHRAIN'
            WHEN Market = 'OMN' THEN 'OMAN'
            WHEN Market = 'SUD' THEN 'SAUDI ARABIA'
            WHEN Market = 'QA'  THEN 'QATAR'
        END AS COUNTRY, 
        TOTAL_STOCK as TOTAL_REGION_STOCK
        from gold.`custom-analysis`.sku_host_to_local
        where Market IN ('UAE','KWT','OMN','SUD','QA','BAH')
        """).toPandas()
country_sku_demand = country_sku_demand.merge(region_stock_df, on=['SKU_CODE','COUNTRY'], how='left')

# COMMAND ----------

country_sku_demand

# COMMAND ----------

sku_demand = final_need_df.groupby(['COUNTRY','SKU_CODE'], as_index=False).agg({'DEMAND_COVERAGE':'sum'}).rename({'DEMAND_COVERAGE':'DEMAND'}, axis=1)

# COMMAND ----------

sku_demand

# COMMAND ----------

country_sku_demand = country_sku_demand.merge(sku_demand, on=['SKU_CODE','COUNTRY'], how='left')
country_sku_demand.drop('TOTAL_NEED', axis=1, inplace=True)

# COMMAND ----------

country_sku_demand.loc[country_sku_demand['DEMAND']>0,'DEMAND'] += 1

# COMMAND ----------

country_sku_demand.loc[(country_sku_demand['DEMAND']>0) & (country_sku_demand['COUNTRY'].isin(['KUWAIT','SAUDI ARABIA','UAE'])),'DEMAND'] += 2

# COMMAND ----------

country_sku_demand.rename({'DEMAND':'TOTAL_NEED'}, axis=1,inplace=True)

# COMMAND ----------

country_sku_demand['SHORTFALL'] = np.where(
    country_sku_demand['TOTAL_NEED'] > country_sku_demand['TOTAL_REGION_STOCK'],
    country_sku_demand['TOTAL_NEED'] - country_sku_demand['TOTAL_REGION_STOCK'],
    0
)

# COMMAND ----------

country_sku_demand

# COMMAND ----------

country_sku_demand.isnull().sum()

# COMMAND ----------

country_sku_demand.dropna(inplace=True)

# COMMAND ----------

country_sku_demand.isnull().sum()

# COMMAND ----------

host_warehouse_stock_df = host_warehouse_stock.groupby(['SKU_CODE','OPTION_CODE'], as_index=False).agg({'HOSTWATEHOUSE_STOCK': 'sum'})
host_warehouse_stock_df.head()

# COMMAND ----------

final_sku_replenishment_df = country_sku_demand.merge(host_warehouse_stock_df, on=['SKU_CODE'], how='left')

# COMMAND ----------

final_sku_replenishment_df.loc[(final_sku_replenishment_df['SKU_CODE']=='101109-25009-005-XSM') &
                   (final_sku_replenishment_df['COUNTRY']=='UAE') ,
                             ]

# COMMAND ----------

final_sku_replenishment_df['HOSTWATEHOUSE_STOCK'].fillna(0, inplace=True)

# COMMAND ----------

def allocate_host_stock(group):
    available_stock = float(group['HOSTWATEHOUSE_STOCK'].iloc[0])
    allocations = []

    # Prioritize higher performance SKUs first
    group = group.sort_values('COUNTRY_PRIORITY', ascending=True)

    for idx, row in group.iterrows():
        if available_stock <= 0:
            allocations.append(0)
            continue
        
        #import pdb;pdb.set_trace()
        qty = min(float(row['SHORTFALL']), available_stock)
        allocations.append(qty)
        available_stock -= float(qty)

    group['ALLOCATED_QTY'] = allocations
    return group

final_allocation = final_sku_replenishment_df.groupby('SKU_CODE').apply(allocate_host_stock).reset_index(drop=True)

# COMMAND ----------

final_allocation.drop('TOTAL_LOCAL_WH_STOCK', axis=1, inplace=True)

# COMMAND ----------

# final_allocation.loc[final_allocation['TOTAL_REGION_STOCK'] > final_allocation['TOTAL_NEED'], 'TOTAL_NEED'] = 0

# COMMAND ----------

last_2_week_sales = spark.sql("""
        SELECT COUNTRY, SKU_CODE, SUM(TOTAL_QUANTITY) AS LAST_2W_SALES
        FROM gold.`custom-analysis`.sku_clustering_temp_sales_transfer
        WHERE SALES_DATE >= CURRENT_DATE() - INTERVAL 14 DAY
        AND STORE_TYPE not in ('ONLINE STORE') 
        GROUP BY COUNTRY,SKU_CODE
          """).toPandas()

# COMMAND ----------

# final_allocation.merge(last_2_week_sales, on=['COUNTRY','SKU_CODE'], how='left').to_csv("host_to_local_replenishment_June_29_2025_new_v2_added.csv")

# COMMAND ----------

final_allocation[final_allocation['OPTION_CODE']=='101101-25043-013']

# COMMAND ----------

#final_allocation.to_csv('host_to_local_replenishment_Aug_10_2025_new_v1.csv')

# COMMAND ----------

host_sku_template = final_allocation.copy()
host_sku_template.head()

# COMMAND ----------

host_sku_template.rename({'WAREHOUSE_CODE':'TO_LOCATION','ALLOCATED_QTY':'REPLENISHED_QTY',
                          'SALES_QTY':'30DAYS_SALES','SHORTFALL':'REQ FOR 101',
                          'HOSTWATEHOUSE_STOCK':'HOST WH STK'
                          }, axis=1, inplace=True)

# COMMAND ----------

host_sku_template['FROM_LOCATION'] = 101
host_sku_template['WH_QTY'] = 0
host_sku_template['MINQTY'] = 0	
host_sku_template['MAXQTY'] = 0
host_sku_template['CURRENT_STORE_STOCK'] = 0	
host_sku_template['LOCAL_INTRANSIT_QTY'] = 0
host_sku_template['FRGN_INTRANSIT'] = 0	
host_sku_template['INTRANSIT_QTY'] = 0	
host_sku_template['OPENORDERQTY']  = 0

# COMMAND ----------

host_to_local_template = host_sku_template[['FROM_LOCATION','TO_LOCATION','SKU_CODE','REPLENISHED_QTY','WH_QTY','30DAYS_SALES','MINQTY','MAXQTY','CURRENT_STORE_STOCK',	'LOCAL_INTRANSIT_QTY','FRGN_INTRANSIT', 'INTRANSIT_QTY', 'OPENORDERQTY','REQ FOR 101','HOST WH STK']]
host_to_local_template.head()

# COMMAND ----------

host_to_local_template[host_to_local_template['REPLENISHED_QTY']>0].to_csv("host_to_local_replenishment_wms_sept_14_2025_v1.csv", index=False)

# COMMAND ----------

host_to_local_template.shape

# COMMAND ----------

host_to_local_template.shape

# COMMAND ----------

