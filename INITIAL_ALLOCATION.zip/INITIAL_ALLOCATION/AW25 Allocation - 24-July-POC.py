# Databricks notebook source
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import datetime

# COMMAND ----------

def propose_new_dominant_dates(global_df, late_launch_threshold=80.0):
    """
    Given a 'global_df' that contains at least:
      - DESIGN_PROJECT_CODE
      - Option_Code
      - LAUNCH_DATE
    this function:

    1) Finds the 'dominant' launch date per collection (the most frequent LAUNCH_DATE).
    2) Merges that dominant date onto each row.
    3) Determines how many options in each collection launch AFTER that date (i.e., are "late").
    4) Calculates the LATE_LAUCH_PERCENTAGE per collection.
    5) For collections with < late_launch_threshold% (e.g., <80%) on-time,
       iteratively moves the date forward day-by-day until the threshold is met.
    6) Returns a DataFrame with the original stats plus a new 'PROPOSED_DOMINANT_LAUNCH_DATE' (if needed).
    """

    # --------------------------------------------------------------
    # 1) Identify the "dominant" launch date per collection
    # --------------------------------------------------------------
    distinct_df = global_df[['OPTION_CODE', 'LAUNCH_DATE', 'VM_GROUP']].drop_duplicates()
    collection_df = (
        distinct_df
        .groupby(['VM_GROUP'], as_index=False)['LAUNCH_DATE']
        .agg(lambda x: x.value_counts().idxmax())
        .rename(columns={'LAUNCH_DATE':'DOMINANT_LAUNCH_DATE'})
    )

    # Merge it back to the global_df to get a per-option data frame
    df = global_df.merge(collection_df, on='VM_GROUP', how='left')

    # --------------------------------------------------------------
    # 2) Compute how many options are launched after the "dominant" date
    #    to identify "late" options
    # --------------------------------------------------------------
    late_launch_option_df = (
        df[df['LAUNCH_DATE'] > df['DOMINANT_LAUNCH_DATE']]
        [['GROUP_NAME','VM_GROUP','OPTION_CODE','LAUNCH_DATE','DOMINANT_LAUNCH_DATE','SUB_SEASON_NAME']]
        .drop_duplicates()
    )

    # --------------------------------------------------------------
    # 3) Summaries: total options & late options
    # --------------------------------------------------------------
    total_options_per_collection = (
        df.groupby('VM_GROUP', as_index=False)['OPTION_CODE']
          .nunique()
          .rename(columns={'OPTION_CODE':'TOTAL_OPTIONS'})
    )

    late_launch_options_per_collection = (
        late_launch_option_df.groupby('VM_GROUP', as_index=False)
        .agg({'OPTION_CODE':'nunique','DOMINANT_LAUNCH_DATE':'max'})
        .rename(columns={'OPTION_CODE':'LATE_LAUNCH_OPTIONS'})
    )

    # Merge these into a single summary DataFrame
    launch_delay_analysis_df = (
        total_options_per_collection
        .merge(late_launch_options_per_collection, on='VM_GROUP', how='inner')
        .rename(columns={'VM_GROUP':'VM_GROUP','DOMINANT_LAUNCH_DATE':'INITIAL_DOMINANT_LAUNCH_DATE'})
    )

    # --------------------------------------------------------------
    # 4) Calculate the LATE_LAUCH_PERCENTAGE per collection
    # --------------------------------------------------------------
    launch_delay_analysis_df['LATE_LAUCH_PERCENTAGE'] = (
        (launch_delay_analysis_df['TOTAL_OPTIONS'] - launch_delay_analysis_df['LATE_LAUNCH_OPTIONS'])
        / launch_delay_analysis_df['TOTAL_OPTIONS']
        * 100
    )

    # --------------------------------------------------------------
    # 5) Filter out the "broken" collections that are below the threshold
    # --------------------------------------------------------------
    broken_collection_df = launch_delay_analysis_df[
        launch_delay_analysis_df['LATE_LAUCH_PERCENTAGE'] < late_launch_threshold
    ].copy()

    # We'll create a new column for the proposed fix:
    broken_collection_df['PROPOSED_DOMINANT_LAUNCH_DATE'] = pd.NaT

    # Helper function to recalc LATE_LAUCH_PERCENTAGE for a given date
    def calc_late_launch_percentage(df, collection_code, test_date):
        """
        Return the LATE_LAUCH_PERCENTAGE if we consider 'test_date' as the
        new 'dominant' date for the given collection_code.
        """
        subset = df[df['VM_GROUP'] == collection_code]

        total_options = subset['OPTION_CODE'].nunique()
        late_options = subset[subset['LAUNCH_DATE'] > test_date]['OPTION_CODE'].nunique()

        # LATE_LAUCH_PERCENTAGE = 100 * (on_time_options / total_options)
        # on_time_options = total_options - late_options
        return ((total_options - late_options) / total_options) * 100

    # --------------------------------------------------------------
    # 6) Iteratively push date forward until the threshold is met
    # --------------------------------------------------------------
    for idx, row in broken_collection_df.iterrows():
        col_code  = row['VM_GROUP']
        cur_date  = row['INITIAL_DOMINANT_LAUNCH_DATE']  # start from the existing date

        while True:
            current_late_percentage = calc_late_launch_percentage(df, col_code, cur_date)
            if current_late_percentage >= late_launch_threshold:
                # Found the earliest date that meets or exceeds the threshold
                broken_collection_df.loc[idx, 'PROPOSED_DOMINANT_LAUNCH_DATE'] = cur_date
                break
            else:
                # Move forward by one day
                cur_date += datetime.timedelta(days=1)

    # --------------------------------------------------------------
    # 7) Merge the new 'PROPOSED_DOMINANT_LAUNCH_DATE' back
    # --------------------------------------------------------------
    # Some collections might not need a new date; they won't appear in broken_collection_df.
    # So let's merge them back into the main analysis DataFrame.
    final_df = launch_delay_analysis_df.merge(
        broken_collection_df[['VM_GROUP','PROPOSED_DOMINANT_LAUNCH_DATE']],
        on='VM_GROUP',
        how='inner'
    )

    # final_df now has:
    #   - COLLECTION_CODE
    #   - TOTAL_OPTIONS
    #   - LATE_LAUNCH_OPTIONS
    #   - INITIAL_DOMINANT_LAUNCH_DATE
    #   - LATE_LAUCH_PERCENTAGE
    #   - PROPOSED_DOMINANT_LAUNCH_DATE (only for "broken" collections)
    return final_df


# COMMAND ----------

sub_seasons = ['PREFALL','WINTER','AUTUMN']
dist_start_date = "2025-08-01" 
dist_end_date = "2025-08-30"

location_df = spark.sql("""SELECT 
                        LOCATION_CODE,
                        COUNTRY_CODE,
                        GRADE,
                        P_RIVA,
                        P_CHOICE,
                        P_RIVAKIDS,
                        STORETYPE_NEW
                         FROM bronze.orjwan.locations 
                        WHERE
                        LOCATION_CODE 
                        in 
                        (
                        select 
                        distinct SHOWROOM 
                        from gold.`custom-analysis`.stores 
                        WHERE STORETYPE IN ('RETAIL STORE','OUTLET') and ACTIVE='Y' and LOCATION_CODE!='U011002'
                        )
                         """).toPandas()

brand_to_loc_col = {
    "RIVA": "P_RIVA",
    "CHOICE": "P_CHOICE",
    "RIVA KIDS": "P_RIVAKIDS"
}

store_sku_df = spark.sql(f"""
select
distinct 
        Option_Code AS OPTION_CODE, 
       SKU_CODE,
        VM_GROUP,
        SIZE_CODE,
        COLLECTION_CODE,
        SEASON_END_DATE,
        GROUP_NAME, 
        LAUNCH_DATE,
        BRAND_NAME,
        SUB_BRAND_NAME,
        SUB_GROUP_NAME,
        SEASON_NAME,
        SUB_SEASON_NAME,
        SIZE_GROUP,
        COLOR_NAME,
        MASTER_PRODUCT_CATEGORY_NAME,
        MASTER_PRODUCT_GROUP_NAME,
        DESIGN_ATTRIBUTE1,
        DESIGN_ATTRIBUTE2,
        DESIGN_ATTRIBUTE3,
        DESIGN_ATTRIBUTE4
from gold.`custom-analysis`.intial_alloc_draft
where 
 LAUNCH_DATE>='{dist_start_date}' AND LAUNCH_DATE<='{dist_end_date}'
""").toPandas()

mask = (store_sku_df['VM_GROUP'].isnull()) | (store_sku_df['VM_GROUP'].str.strip()=='')
store_sku_df.loc[mask, 'VM_GROUP'] = store_sku_df.loc[mask, 'COLLECTION_CODE']

# Mapping MASTER_PRODUCT_GROUP_NAME
store_sku_df.loc[store_sku_df['MASTER_PRODUCT_GROUP_NAME']=='DRESS/SET','MASTER_PRODUCT_GROUP_NAME']='DRESSES'
store_sku_df.loc[store_sku_df['MASTER_PRODUCT_GROUP_NAME']=='TOP','MASTER_PRODUCT_GROUP_NAME']='TOPS'
store_sku_df.loc[store_sku_df['MASTER_PRODUCT_GROUP_NAME']=='BOTTOM','MASTER_PRODUCT_GROUP_NAME']='BOTTOMS'

season_option_df = spark.sql(f"""
select
distinct 
 Option_Code AS OPTION_CODE, 
 VM_GROUP,
 COLLECTION_CODE,
SEASON_END_DATE,
        GROUP_NAME, 
        LAUNCH_DATE,
        BRAND_NAME,
        SUB_BRAND_NAME,
        SUB_GROUP_NAME,
        SEASON_NAME,
        SUB_SEASON_NAME,
        SIZE_GROUP,
        COLOR_NAME,
        MASTER_PRODUCT_CATEGORY_NAME,
        DESIGN_ATTRIBUTE1,
        DESIGN_ATTRIBUTE2,
        DESIGN_ATTRIBUTE3,
        DESIGN_ATTRIBUTE4,
        COST_PRICE_KD,
        KWT,
        UAE,
        SUD,
        BAH,
        QA,
        OMN
from gold.`custom-analysis`.intial_alloc_draft
where 
 LAUNCH_DATE>='{dist_start_date}' AND LAUNCH_DATE<='{dist_end_date}'
""").toPandas()

mask = (season_option_df['VM_GROUP'].isnull()) | (season_option_df['VM_GROUP'].str.strip()=='')
season_option_df.loc[mask, 'VM_GROUP'] = season_option_df.loc[mask, 'COLLECTION_CODE']

location_df.loc[location_df['LOCATION_CODE']=='B1002','P_CHOICE'] = 7
location_df.loc[location_df['LOCATION_CODE']=='Q01','P_RIVAKIDS'] = 7

# COMMAND ----------

season_option_df['BRAND_NAME'].value_counts()

# COMMAND ----------

store_sku_df[store_sku_df['COLLECTION_CODE']=='RE2']

# COMMAND ----------

# store_sku_df = store_sku_df[store_sku_df['VM_GROUP'].str.contains('8D125RE2|8D125ED2', na=False)]
# season_option_df = season_option_df[season_option_df['VM_GROUP'].str.contains('8D125RE2|8D125ED2', na=False)]

# COMMAND ----------

global_sku_df = store_sku_df.copy()
global_options_df = season_option_df.copy()

# COMMAND ----------

df_sku_expanded = pd.DataFrame(columns=list(season_option_df.columns) + ["LOCATION_CODE","COUNTRY_CODE",'STORE_GRADE'])
location_df['P_RIVA'] = location_df['P_RIVA'].replace(0, None)
location_df['P_CHOICE'] = location_df['P_CHOICE'].replace(0, None)
location_df['P_RIVAKIDS'] = location_df['P_RIVAKIDS'].replace(0, None)

for row in season_option_df.itertuples(index=False):
    sku_brand = row.BRAND_NAME
    if sku_brand in brand_to_loc_col:
        loc_col = brand_to_loc_col[sku_brand]
        valid_locations = location_df.loc[(location_df[loc_col].notna()), ["LOCATION_CODE","COUNTRY_CODE", "GRADE"]]
        # import pdb;pdb.set_trace()

        for i,l_row in valid_locations.iterrows():
            new_row = list(row) + [l_row['LOCATION_CODE']] + [l_row['COUNTRY_CODE']] +[l_row['GRADE']] 
            df_sku_expanded.loc[len(df_sku_expanded)] = new_row
            
    else:
        continue

# COMMAND ----------

allocate_sku_df = df_sku_expanded.copy()
allocate_sku_df.head()

# COMMAND ----------

collection_option_wise_lauch_date_df = global_options_df[['VM_GROUP','OPTION_CODE','LAUNCH_DATE']].drop_duplicates()
collection_dominant_date = (
    collection_option_wise_lauch_date_df.groupby('VM_GROUP')['LAUNCH_DATE']
    .agg(lambda x: x.value_counts().idxmax())  # Most frequent launch date
    .reset_index()
    .rename(columns={'LAUNCH_DATE': 'DOMINANT_LAUNCH_DATE'})
)
collection_dominant_date.columns = ['VM_GROUP', 'DOMINANT_LAUNCH_DATE']
collection_dominant_date.head()

# COMMAND ----------

print(collection_dominant_date['DOMINANT_LAUNCH_DATE'].min())
print(collection_dominant_date['DOMINANT_LAUNCH_DATE'].max())

# COMMAND ----------

result_df = propose_new_dominant_dates(season_option_df, late_launch_threshold=80.0)
result_df.head()

# COMMAND ----------

collection_dominant_date = collection_dominant_date.merge(
    result_df[['VM_GROUP', 'PROPOSED_DOMINANT_LAUNCH_DATE']], 
    on='VM_GROUP', 
    how='left'
)
collection_dominant_date
collection_dominant_date['DOMINANT_LAUNCH_DATE'] = collection_dominant_date['PROPOSED_DOMINANT_LAUNCH_DATE'].fillna(collection_dominant_date['DOMINANT_LAUNCH_DATE'])
collection_dominant_date = collection_dominant_date.drop(columns=['PROPOSED_DOMINANT_LAUNCH_DATE'])

# COMMAND ----------

final_df = allocate_sku_df.merge(collection_dominant_date, on='VM_GROUP', how='left')
final_df.head()

# COMMAND ----------

collection_allo_df = final_df.groupby(['VM_GROUP','COUNTRY_CODE','LOCATION_CODE','STORE_GRADE'], as_index=False).agg({'OPTION_CODE':'nunique'})
collection_allo_df = collection_allo_df.rename({'OPTION_CODE':'ALLOC_OPTION_COUNT'}, axis=1)

original_coll_df = season_option_df.groupby(['VM_GROUP'], as_index=False).agg({'OPTION_CODE':'nunique'}).rename({'OPTION_CODE':'TOTAL_OPTION_COUNT'}, axis=1)


collection_cov_df = collection_allo_df.merge(original_coll_df, on="VM_GROUP", how="left")
collection_cov_df['COLLECTION_COV'] = collection_cov_df['ALLOC_OPTION_COUNT']/collection_cov_df['TOTAL_OPTION_COUNT']

# COMMAND ----------

def get_collection_details(collection_code):
    collection_details_df = global_sku_df[global_sku_df['VM_GROUP'] == collection_code]
    
    if collection_details_df.empty:
        return pd.Series([None, None, None, None])  # Handle empty case
    # import pdb;pdb.set_trace()
    brand_name = collection_details_df['BRAND_NAME'].iloc[0]
    sub_brand_name = collection_details_df['SUB_BRAND_NAME'].iloc[0]
    product_group = collection_details_df['GROUP_NAME'].unique().tolist()
    product_subgroup = collection_details_df['SUB_GROUP_NAME'].unique().tolist()
    season_names = collection_details_df['SEASON_NAME'].unique().tolist()
    sub_season_names = collection_details_df['SUB_SEASON_NAME'].unique().tolist()
    
    des_att1 = collection_details_df['DESIGN_ATTRIBUTE1'].unique().tolist()
    des_att2 = collection_details_df['DESIGN_ATTRIBUTE2'].unique().tolist()
    des_att3 = collection_details_df['DESIGN_ATTRIBUTE3'].unique().tolist()
    des_att4 = collection_details_df['DESIGN_ATTRIBUTE4'].unique().tolist()
    size_groups = collection_details_df['SIZE_GROUP'].unique().tolist()

    # import pdb;pdb.set_trace()
    return pd.Series([brand_name, 
                      sub_brand_name, 
                      product_group, 
                      product_subgroup,
                      season_names,
                      sub_season_names, 
                      des_att1,
                      des_att2,
                      des_att3,
                      des_att4,
                      size_groups
                      ])
    


collection_cov_df[['BRAND_NAME', 
                   'SUB_BRAND_NAME', 
                   'PRODUCT_GROUP', 
                   'PRODUCT_SUBGROUP',
                   'SEASON_NAME',
                   'SUB_SEASON_NAME',
                   'DESIGN_ATTRIBUTE1',
                   'DESIGN_ATTRIBUTE2',
                   'DESIGN_ATTRIBUTE3',
                   'DESIGN_ATTRIBUTE4',
                   'SIZE_GROUP'
                   ]] = collection_cov_df['VM_GROUP'].apply(get_collection_details)
collection_cov_df.head()

# COMMAND ----------

collection_cov_df.isnull().sum()

# COMMAND ----------

collection_cov_df['LOCATION_CODE'].nunique()

# COMMAND ----------

sku_transfer_df = spark.sql(f"""
    SELECT *
    FROM gold.`custom-analysis`.SKU_Clustering_TEMP_SALES_TRANSFER
    WHERE 
        STOCK_TRANS_QUANTITY <> 0
        AND FIRST_TRANSFER_DT != 'NO TRANSFER RECORD'
        AND (
            (SALES_DATE >= '2023-10-01' AND SALES_DATE <= '2025-01-15') 
            OR (SALES_DATE BETWEEN CURRENT_DATE - INTERVAL 40 DAY AND CURRENT_DATE)
        )
""").toPandas()

sku_transfer_df['SALES_DATE'] = pd.to_datetime(sku_transfer_df['SALES_DATE'])
sku_transfer_df['FIRST_TRANSFER_DT'] = pd.to_datetime(sku_transfer_df['FIRST_TRANSFER_DT'])

sku_transfer_df['WEEK_NUMBER'] = sku_transfer_df['SALES_DATE'].dt.isocalendar()['year'].astype(str)+"-"+sku_transfer_df['SALES_DATE'].dt.isocalendar()['week'].astype(str)

sku_transfer_df['DAY_SINE_TRANSFER'] = (sku_transfer_df['SALES_DATE'] - sku_transfer_df['FIRST_TRANSFER_DT']).dt.days
sku_transfer_df = sku_transfer_df[sku_transfer_df['DAY_SINE_TRANSFER']<=40]
sku_transfer_df.loc[sku_transfer_df['TOTAL_QUANTITY']>(sku_transfer_df['STOCK_TRANS_QUANTITY']),'STOCK_TRANS_QUANTITY'] = sku_transfer_df['TOTAL_QUANTITY']
sku_transfer_df.head()

# COMMAND ----------

collection_cov_df

# COMMAND ----------

sub_seasons_list = ['PREFALL','WINTER','AUTUMN']
def fallback_lookup(row, hist_df, sub_season_list):
    """
    Returns the best-matched slice of `hist_df` for the given `row`.
    If no match is ever found it returns an empty DataFrame
    (replace with pd.Series([0]*5) if needed).
    """

    # -------- filters that are should be exists --------
    core_mask = (
        (hist_df['BRAND_NAME']     == row['BRAND_NAME'])   &
        (hist_df['SUB_BRAND_NAME'] == row['SUB_BRAND_NAME']) &
        (hist_df['GROUP_NAME'].isin(row['PRODUCT_GROUP'])) &
        (hist_df['SUB_GROUP_NAME'].isin(row['PRODUCT_SUBGROUP'])) &
        (hist_df['SEASON_NAME'].isin(row['SEASON_NAME'])) &
        (hist_df['SIZE_GROUP'].isin(row['SIZE_GROUP']))
    )

    # -------- low-priority attribute filters (from left to right) --------
    attr_filters = [
        ('DESIGN_ATTRIBUTE4', row['DESIGN_ATTRIBUTE4']),
        ('DESIGN_ATTRIBUTE3', row['DESIGN_ATTRIBUTE3']),
        ('DESIGN_ATTRIBUTE2', row['DESIGN_ATTRIBUTE2']),
        ('DESIGN_ATTRIBUTE1', row['DESIGN_ATTRIBUTE1']),
        # ('SUB_SEASON_NAME',  sub_season_list)            # added at the very end
    ]

    # -------- locality scopes (widen from left to right) --------
    locality_levels = [
        ('LOCATION_CODE', row['LOCATION_CODE']),
        ('COUNTRY_CODE',       row['COUNTRY_CODE'])
    ]

    # -------- grid-search over (dropped attributes) × (location scope) --------
    for drop_n in range(len(attr_filters) + 1):                   # 0 … 5
        # keep everything **after** the drop point
        active_attr_mask = True
        for col, allowed_vals in attr_filters[drop_n:]:
            active_attr_mask &= hist_df[col].isin(allowed_vals)

        # now iterate through the location scopes
        for loc_col, loc_val in locality_levels:
            loc_mask = hist_df[loc_col] == loc_val
            candidates = hist_df.loc[core_mask & active_attr_mask & loc_mask]
            if not candidates.empty:
                return candidates        #  first non-empty win

    # nothing matched in any combination
    return pd.DataFrame()                # or pd.Series([0]*5) if your code expects it


def compute_collection_kpi_v2(row,hist_df, since_sku_lauch_days=40):
    """
        For each row (e.g., from a DataFrame.apply(..., axis=1)),
        computes and returns a Series of metrics:
        
        1) global collection contribution
        2) total_sku_qty_sold
        3) avg_qty_per_week
        4) weekly_sales_std
        5) sell_through_rate
        6) sales_days
        7) sub_season_ratio
        8) sub_season_weight
        
        Returns pd.Series of length 8.
        """
    # import pdb;pdb.set_trace()
    
    # --- 1) Filter collection_df based on row attributes ---
    # collection_df = hist_df.loc[
    #         (hist_df['BRAND_NAME'] == row['BRAND_NAME']) &
    #         (hist_df['SUB_BRAND_NAME']==row['SUB_BRAND_NAME']) &
    #         (hist_df['GROUP_NAME'].isin(row['PRODUCT_GROUP'])) &
    #         (hist_df['SUB_GROUP_NAME'].isin(row['PRODUCT_SUBGROUP'])) &
    #         (hist_df['SEASON_NAME'].isin(row['SEASON_NAME'])) &
    #         # (hist_df['SUB_SEASON_NAME'].isin(sub_season_list)) &
    #         (hist_df['DESIGN_ATTRIBUTE1'].isin(row['DESIGN_ATTRIBUTE1'])) &
    #         (hist_df['DESIGN_ATTRIBUTE2'].isin(row['DESIGN_ATTRIBUTE2'])) &
    #         (hist_df['DESIGN_ATTRIBUTE3'].isin(row['DESIGN_ATTRIBUTE3'])) &
    #         (hist_df['DESIGN_ATTRIBUTE4'].isin(row['DESIGN_ATTRIBUTE4'])) &
    #         (hist_df['SIZE_GROUP'].isin(row['SIZE_GROUP'])) &
    #         (hist_df['LOCATION_CODE']==row['LOCATION_CODE'])
    #    ]
    collection_df = fallback_lookup(row, hist_df, 'sub season')

    # If nothing matches at all, return zeros
    if collection_df.empty:
        return  pd.Series([0]*4)
    
    # --- 2) Filter for matched rows at the specific store ---
    matched = collection_df
    # If store-level data is empty, return zeros
    if matched.empty:
        return pd.Series([0]*4)
    
    df_agg = (matched.groupby('SKU_CODE', as_index=False).agg(
                                    STOCK_TRANS_QUANTITY=('STOCK_TRANS_QUANTITY', 'max'),
                                    TOTAL_QUANTITY=('TOTAL_QUANTITY', 'sum')
                                    )
            )
    
    df_agg.loc[df_agg['TOTAL_QUANTITY'] > df_agg['STOCK_TRANS_QUANTITY'],'TOTAL_QUANTITY'] = df_agg['STOCK_TRANS_QUANTITY']

    # store_contr = df_agg['TOTAL_QUANTITY'].astype(float).sum() / collection_df['TOTAL_QUANTITY'].astype(float).sum()

    # sell thorugh rate
    sell_through_rate = float(df_agg['TOTAL_QUANTITY'].sum()/df_agg['STOCK_TRANS_QUANTITY'].sum())

    rate_of_sale = float(df_agg['TOTAL_QUANTITY'].sum()) / since_sku_lauch_days

    # Collection Level profit Margin KPI
    collection_code = row['VM_GROUP']
    country_code = row['COUNTRY_CODE']
    
    collection_fin_kpi_df = season_option_df.loc[(season_option_df['VM_GROUP']==collection_code),[country_code,'COST_PRICE_KD']].copy()
    collection_fin_kpi_df['PROFIT'] = (collection_fin_kpi_df[country_code] - collection_fin_kpi_df['COST_PRICE_KD'])
    coutry_sum = collection_fin_kpi_df[country_code].sum()
    if coutry_sum == 0:
        collection_gross_margin = 0
    else:
        collection_gross_margin = collection_fin_kpi_df['PROFIT'].sum() / coutry_sum
    selling_price_avg = collection_fin_kpi_df[country_code].mean() # Selling price Average



    # --- Return all metrics consistently ---
    return pd.Series([
       sell_through_rate,
       rate_of_sale,
       selling_price_avg,
       collection_gross_margin
    ])

# collection_df[['GLOBAL_COLLECTION_CONTRIBUTION', 'TOTAL_SKU_QUANTITY_SOLD', 'AVG_WEEKLY_SALES_QTY', 'WEEKLY_SALES_STDDEV', 'STR','NUM_SALES_DAYS','SUB_SEASON_COVERAGE_RATIO','SUB_SEASON_WEIGHT']] = collection_df.apply(
#     lambda row: compute_collection_kpi(row, sku_transfer_df), axis=1
# )
collection_cov_df[['SELL_THROUGH','RATE_OF_SALE','SELL_PRICE_AVG','GROSS_MARGIN']] = collection_cov_df.apply(
    lambda row: compute_collection_kpi_v2(row, sku_transfer_df), axis=1)

# COMMAND ----------

collection_cov_df

# COMMAND ----------

collection_cov_df.fillna(0, inplace=True)

# COMMAND ----------

collection_cov_df['ROS_NORM'] = collection_cov_df.groupby('LOCATION_CODE')['RATE_OF_SALE'].transform(lambda x: x / x.max())

collection_cov_df['PERFORMANCE_CONF'] = (collection_cov_df['SELL_THROUGH'] * 0.5 
                                         + 
                                         collection_cov_df['ROS_NORM'] * 0.5
                                         )
collection_cov_df['GROSS_MARGIN'] = np.round(collection_cov_df['GROSS_MARGIN'].astype(float),5)

collection_cov_df['SELL_PRICE_AVG_NORM'] = collection_cov_df.groupby(['LOCATION_CODE'])['SELL_PRICE_AVG'].transform(lambda x: 
    (x-x.min()) / (x.max()-x.min()))

collection_cov_df['PROFIT_CONF'] = (collection_cov_df['GROSS_MARGIN'] * 0.5 + collection_cov_df['SELL_PRICE_AVG_NORM'] * 0.5)

collection_cov_df['CONFIDENCE'] = (collection_cov_df['PERFORMANCE_CONF'] * 0.6 + collection_cov_df['PROFIT_CONF'] *0.4)

# COMMAND ----------

collection_cov_df.isnull().sum()

# COMMAND ----------

collection_cov_df.to_csv("collection_priority_store_level.csv", index=False)

# COMMAND ----------

collection_cov_df.head()

# COMMAND ----------

store_sub_brand_df = collection_cov_df[['LOCATION_CODE','COUNTRY_CODE','STORE_GRADE','BRAND_NAME','SUB_BRAND_NAME']]
store_sub_brand_df = store_sub_brand_df.drop_duplicates()
store_sub_brand_df.head()

# COMMAND ----------

def compute_sub_brand_priority(row,hist_df, since_sku_lauch_days=40):
    """
        For each row (e.g., from a DataFrame.apply(..., axis=1)),
        computes and returns a Series of metrics:
        
        1) global collection contribution
        2) total_sku_qty_sold
        3) avg_qty_per_week
        4) weekly_sales_std
        5) sell_through_rate
        6) sales_days
        7) sub_season_ratio
        8) sub_season_weight
        
        Returns pd.Series of length 8.
        """
    
    # --- 1) Filter collection_df based on row attributes ---
    collection_df = hist_df.loc[
        (hist_df['BRAND_NAME'] == row['BRAND_NAME']) &
        (hist_df['SUB_BRAND_NAME']==row['SUB_BRAND_NAME'])
    ]

    # If nothing matches at all, return zeros
    if collection_df.empty:
        return  pd.Series([0]*5)
    
    # --- 2) Filter for matched rows at the specific store ---
    matched = collection_df.loc[
        collection_df['LOCATION_CODE'] == row['LOCATION_CODE']
    ]
    # If store-level data is empty, return zeros
    if matched.empty:
        return pd.Series([0]*5)
    
    df_agg = (matched.groupby('SKU_CODE', as_index=False).agg(
                                    STOCK_TRANS_QUANTITY=('STOCK_TRANS_QUANTITY', 'max'),
                                    TOTAL_QUANTITY=('TOTAL_QUANTITY', 'sum')
                                    )
            )
    df_agg.loc[df_agg['TOTAL_QUANTITY'] > df_agg['STOCK_TRANS_QUANTITY'],'STOCK_TRANS_QUANTITY'] = df_agg['STOCK_TRANS_QUANTITY']

    store_contr = df_agg['TOTAL_QUANTITY'].astype(float).sum() / collection_df['TOTAL_QUANTITY'].astype(float).sum()

    # sell thorugh rate
    sell_through_rate = float(df_agg['TOTAL_QUANTITY'].sum()/df_agg['STOCK_TRANS_QUANTITY'].sum())
    rate_of_sale = float(df_agg['TOTAL_QUANTITY'].sum()) / since_sku_lauch_days
    
    # Collection Level profit Margin KPI
    sub_brand_name = row['SUB_BRAND_NAME']
    country_code = row['COUNTRY_CODE']
    
    collection_fin_kpi_df = season_option_df.loc[(season_option_df['SUB_BRAND_NAME']==sub_brand_name),[country_code,'COST_PRICE_KD']].copy()
    collection_fin_kpi_df['PROFIT'] = (collection_fin_kpi_df[country_code] - collection_fin_kpi_df['COST_PRICE_KD'])
    denom = collection_fin_kpi_df[country_code].sum()
    if denom == 0:
        subbrand_gross_margin = 0
    else:
        subbrand_gross_margin = collection_fin_kpi_df['PROFIT'].sum() / denom
    selling_price_avg = collection_fin_kpi_df[country_code].mean() # Selling price Average

    # --- Return all metrics consistently ---
    return pd.Series([
       sell_through_rate,
       rate_of_sale,
       store_contr,
       subbrand_gross_margin,
       selling_price_avg


    ])

# collection_df[['GLOBAL_COLLECTION_CONTRIBUTION', 'TOTAL_SKU_QUANTITY_SOLD', 'AVG_WEEKLY_SALES_QTY', 'WEEKLY_SALES_STDDEV', 'STR','NUM_SALES_DAYS','SUB_SEASON_COVERAGE_RATIO','SUB_SEASON_WEIGHT']] = collection_df.apply(
#     lambda row: compute_collection_kpi(row, sku_transfer_df), axis=1
# )


store_sub_brand_df[['SELL_THROUGH','RATE_OF_SALE','STORE_CONTRIBUTION','GROSS_MARGIN','SELL_PRICE_AVG']] = store_sub_brand_df.apply(
    lambda row: compute_sub_brand_priority(row, sku_transfer_df), axis=1)

# COMMAND ----------

store_sub_brand_df.isnull().sum()

# COMMAND ----------

store_sub_brand_df.fillna(0,inplace=True)

# COMMAND ----------

store_sub_brand_df['ROS_NORM'] = store_sub_brand_df.groupby('LOCATION_CODE')['RATE_OF_SALE'].transform(lambda x: x / x.max())

store_sub_brand_df['PERFORMANCE_CONF'] = (store_sub_brand_df['SELL_THROUGH'] * 0.5 
                                         + 
                                         store_sub_brand_df['ROS_NORM'] * 0.4 
                                         + 
                                         store_sub_brand_df['STORE_CONTRIBUTION'] * 0.1
                                         )
store_sub_brand_df['GROSS_MARGIN'] = np.round(store_sub_brand_df['GROSS_MARGIN'].astype(float),5)

store_sub_brand_df['SELL_PRICE_AVG_NORM'] = store_sub_brand_df.groupby(['LOCATION_CODE'])['SELL_PRICE_AVG'].transform(lambda x: 
    (x-x.min()) / (x.max()-x.min()))

store_sub_brand_df['PROFIT_CONF'] = (store_sub_brand_df['GROSS_MARGIN'] * 0.5 + store_sub_brand_df['SELL_PRICE_AVG_NORM'] * 0.5)

store_sub_brand_df['CONFIDENCE'] = (store_sub_brand_df['PERFORMANCE_CONF'] * 0.6 + store_sub_brand_df['PROFIT_CONF'] *0.4)


# COMMAND ----------

store_sub_brand_df.fillna(0, inplace=True)

# COMMAND ----------

store_sub_brand_df.to_csv("subbrand_priority_stores.csv", index=False)

# COMMAND ----------

sub_brand_conf_df = store_sub_brand_df[['LOCATION_CODE','BRAND_NAME','SUB_BRAND_NAME','CONFIDENCE']]
sub_brand_conf_df.head()

# COMMAND ----------

total_option_brand_df = spark.sql("""SELECT 
          * 
          FROM gold.`custom-analysis`.RIVA_CHOICE_DROP4"""
          ).toPandas()
total_option_brand_df.head()

# COMMAND ----------

df = total_option_brand_df.merge(
        sub_brand_conf_df,
        on=["LOCATION_CODE", "BRAND_NAME"],
        how="left"
     )
df.head()

# COMMAND ----------

# ---- 3. Allocate -------------------------------------------------------------
def allocate(group: pd.DataFrame) -> pd.DataFrame:
    max_opts = group["MAX_OPTIONS"].iloc[0]

    if len(group) == 1:                         # single sub-brand = easy
        group["TOTAL_OPTIONS"] = max_opts
        return group

    tot_conf = group["CONFIDENCE"].sum()
    if tot_conf == 0:                           # fallback: even split
        base      = max_opts // len(group)
        remainder = max_opts - base * len(group)
        group["TOTAL_OPTIONS"] = base
        # hand out the leftovers arbitrarily (first rows)
        group.iloc[:remainder, group.columns.get_loc("TOTAL_OPTIONS")] += 1
        return group

    # weighted allocation
    raw       = group["CONFIDENCE"] / tot_conf * max_opts
    base      = np.floor(raw).astype(int)
    remainder = max_opts - base.sum()

    # largest fractional parts get the +1s
    frac_rank = (raw - base).rank(method="first", ascending=False)
    bonus     = (frac_rank <= remainder).astype(int)

    group["TOTAL_OPTIONS"] = base + bonus
    return group

out = df.groupby(["LOCATION_CODE", "BRAND_NAME"], group_keys=False).apply(allocate)

final_table = out[["LOCATION_CODE",
                   "BRAND_NAME",
                   "SUB_BRAND_NAME",
                   "TOTAL_OPTIONS"]].sort_values(["LOCATION_CODE","BRAND_NAME","SUB_BRAND_NAME"])

# COMMAND ----------

final_table.head()

# COMMAND ----------

store_sub_brand_df.head()

# COMMAND ----------

store_list  = allocate_sku_df[['LOCATION_CODE','COUNTRY_CODE']].drop_duplicates().values.tolist()

sub_brand_priorty_df = store_sub_brand_df.copy()

store_coll_priority_df = collection_cov_df[['LOCATION_CODE',
                                            "COUNTRY_CODE",
                                            'BRAND_NAME',
                                            'STORE_GRADE',
                                            'VM_GROUP',
                                            'ALLOC_OPTION_COUNT',
                                            'TOTAL_OPTION_COUNT',
                                            'SUB_BRAND_NAME',
                                            'SELL_THROUGH',
                                            'RATE_OF_SALE',
                                            'ROS_NORM'	,
                                            'CONFIDENCE']].copy()

# SKU List Collection wise
subbrand_collection_to_skus = {}
for (sb, coll), df_group in  store_sku_df.groupby(['SUB_BRAND_NAME','VM_GROUP']):
    subbrand_collection_to_skus[(sb, coll)] = list(
            zip(df_group['SKU_CODE'],df_group['SIZE_CODE'],df_group['SIZE_GROUP'], df_group['MASTER_PRODUCT_GROUP_NAME'],df_group['GROUP_NAME'],df_group['OPTION_CODE'], df_group['BRAND_NAME'],df_group['VM_GROUP'])
        )

# # Store capacity Usage
# store_capacity_usage = {}
# # Initialize usage to 0 for all (store, category).
# for row in store_capacity_df.itertuples(index=False):
#     store_capacity_usage[(row.LOCATION_CODE, row.MASTER_PRODUCT_GROUP_NAME)] = 0

min_max_qty_df = spark.sql(f"""Select GROUP_NAME,SCALE_CODE SIZE_GROUP, SIZE_CODE,SHOP_GRADE,MINQTY,MAXQTY from gold.`custom-analysis`.wms_shop_distribution_Dup 
                           """).toPandas()
min_max_qty_df['MINQTY'] = min_max_qty_df['MINQTY'].astype(int)
min_max_qty_df['MAXQTY'] = min_max_qty_df['MAXQTY'].astype(int)

min_max_lookup = {}
for row in min_max_qty_df.itertuples():
    min_max_lookup[
        (row.GROUP_NAME, row.SIZE_GROUP, row.SIZE_CODE,row.SHOP_GRADE)
    ] = (row.MINQTY, row.MAXQTY)


store_capacity_df = spark.sql("""
                              SELECT 
                              LOCATION_CODE, 
                              MASTER_PRODUCT_GROUP as MASTER_PRODUCT_GROUP_NAME, 
                              (MAX_STOCK * 0.6) AS MAX_CAPACITY FROM gold.`custom-analysis`.SKU_STORE_CAPACITY
                           """).toPandas()

store_capacity_df['MAX_CAPACITY'] = store_capacity_df['MAX_CAPACITY'].astype(float)
store_capacity_map = store_capacity_df.set_index(
    ['LOCATION_CODE', 'MASTER_PRODUCT_GROUP_NAME']
)['MAX_CAPACITY'].to_dict()

# COMMAND ----------

sku_demand_df = pd.read_csv("datasets/backup/weekwise_demand_aug_4_v1.csv")

# Convert DEMAND_WEEK to numeric just in case
sku_demand_df['DEMAND_WEEK'] = pd.to_numeric(sku_demand_df['DEMAND_WEEK'])

sku_demand_df['WEEK_RANK'] = sku_demand_df.groupby(['SKU_CODE', 'STORE_ID'])['DEMAND_WEEK'].rank(method='dense')

sku_demand_df['ALLOC_TYPE'] = sku_demand_df['WEEK_RANK'].apply(lambda x: 'STORE' if x <= 2 else 'WAREHOUSE')
week_alloc = sku_demand_df[sku_demand_df['ALLOC_TYPE']=='STORE'].groupby(['STORE_ID','SKU_CODE'], as_index=False).agg({'DIST_QTY':'sum'}).rename({"DIST_QTY":'STORE_ALLOC_QTY'}, axis=1)
sku_demand_df = sku_demand_df.merge(week_alloc, on=['STORE_ID','SKU_CODE'], how='left').fillna(0)

sku_demand_df.groupby(['STORE_ID','SKU_CODE'], as_index=False).agg({'STORE_ALLOC_QTY':'first'})

sku_dist_dict  = {
    (row['STORE_ID'], row['SKU_CODE']): row['STORE_ALLOC_QTY']
    for _, row in sku_demand_df.iterrows()
}


# COMMAND ----------

# coll_allocation_df[coll_allocation_df['SUB_BRAND_NAME']=='RIVA EVERY DAY']

# COMMAND ----------

collection_cov_df[collection_cov_df['CONFIDENCE']==0]

# COMMAND ----------

priority_tiers = [
    ("Tier1", 0.4, 2), 
    ("Tier2", 0.4, 0.5),
    ("Tier3", 0.3, 0.4),
    ("Tier4", 0.1, 0.3),
    ("Tier5", 0.001, 0.1),

]

def allocate_by_priority_tiers(
    store_list,
    sub_brand_priorty_df,
    store_coll_priority_df,
    subbrand_collection_to_skus,
    store_capacity_map,
    min_max_lookup,
    priority_tiers
):
    """
    Allocate SKUs in multiple passes (tiers) based on priority ranges.
    
    Parameters
    ----------
    store_list : list
        List of store IDs (LOCATION_CODE).
    sub_brand_priorty_df : pd.DataFrame
        Columns: ['LOCATION_CODE', 'SUB_BRAND_NAME', 'SUB_BRAND_PRIORITY']
    store_coll_priority_df : pd.DataFrame
        Columns: ['LOCATION_CODE', 'SUB_BRAND_NAME', 'COLLECTION_CODE', 'COLLECTION_PRIORITY', 'STORE_GRADE', ...]
    subbrand_collection_to_skus : dict
        (sub_brand, collection) -> list of (sku, size_code, size_group, category, group_name)
    store_capacity_usage : dict
        (store_id, category) -> int (current usage so far)
    store_capacity_map : dict
        (store_id, category) -> int (max capacity)
    min_max_lookup : dict
        (group_name, size_group, size_code, store_grade) -> (min_qty, max_qty)
    global_sku_stock : dict
        sku -> int (global stock available)
    priority_tiers : list
        List of tuples (tier_name, min_priority, max_priority),
        e.g. [("Tier1", 0.5, 1.0), ("Tier2", 0.4, 0.5), ... ]
    
    Returns
    -------
    final_allocations : list of dict
        Each dict has keys: ['LOCATION_CODE', 'SUB_BRAND_NAME', 'COLLECTION_CODE', 'SKU_CODE', 'ALLOC_QTY']
    """
    
    final_allocations = []

    # Helper function: allocate for a single sub-brand, single collection
    def allocate_skus_for_subbrand_collection(store_id, sub_brand, sb_priority, collection, coll_priority, store_grade,country_code):
        """
        Returns a list of allocation dicts for the given sub_brand/collection in that store.
        """
        allocations = []

        # Decide your "allocate_mode" based on the priority, for example:
        # (You can also interpret sub-brand priority or store grade if you like.)
        if coll_priority >= 0.5:
            allocate_mode = 'max'
        else:
            allocate_mode = 'min'

        # retrieve the SKUs from the dictionary
        skus_for_collection = subbrand_collection_to_skus.get((sub_brand, collection), [])
        # import pdb;pdb.set_trace()

        for (sku, size_code, size_group, category, group_name,option_code,brand_name, vm_group) in skus_for_collection:
            # If global stock for this SKU is depleted, skip
            # if global_sku_stock.get(sku, 0) <= 0:
            #     continue

            #current_usage = store_capacity_usage.get((store_id, category), 0)
            # max_capacity = store_capacity_map.get((store_id, category), 0)
            # If capacity is already used up, skip
            # if current_usage >= max_capacity:
            #     continue

            # get min and max from your table/dict
            if store_grade=='A':
                min_missing, max_missing = 2,4
            elif store_grade=='B':
                min_missing, max_missing = 2,3
            else:
                min_missing, max_missing = 1,2
            
            min_qty, max_qty = min_max_lookup.get((group_name, size_group, size_code, store_grade), (min_missing, max_missing))
            forecasted_qty = sku_dist_dict.get((store_id,sku),1)
            first_week_qty =  forecasted_qty
            #import pdb;pdb.set_trace()
            if forecasted_qty>max_qty:
                alloc_qty = first_week_qty
            elif forecasted_qty<min_qty:
                alloc_qty = min_qty
            else:
                alloc_qty = forecasted_qty
            # Do not exceed global stock or capacity
            # alloc_qty = min(alloc_qty, 20) #global_sku_stock[sku])#, max_capacity - current_usage)
            if alloc_qty <= 0:
                continue

            # record the allocation
            allocations.append({
                'LOCATION_CODE': store_id,
                'COUNTRY_CODE':country_code,
                'STORE_GRADE': store_grade,
                'OPTION_CODE': option_code,
                'SIZE_CODE': size_code,
                "BRAND_NAME":brand_name,
                "VM_GROUP": vm_group,
                'SUB_BRAND_NAME': sub_brand,
                'COLLECTION_CODE': collection,
                'SKU_CODE': sku,
                'MASTER_PRODUCT_GROUP_NAME': category,
                'ALLOC_QTY': alloc_qty
            })

            # update usage
            #store_capacity_usage[(store_id, category)] = current_usage + alloc_qty
            # update global stock
            # global_sku_stock[sku] = global_sku_stock[sku] - alloc_qty

        return allocations

    # ----------------------------------------------------
    # For each store, do multiple passes
    # ----------------------------------------------------
    for (store_id, country_code) in store_list:
        # For each tier in descending order
        for tier_name, p_min, p_max in priority_tiers:
            # 1) Filter sub_brands in that priority range [p_min, p_max)
            #    (or use strict vs. inclusive bounds as suits you)
            sb_in_tier = sub_brand_priorty_df[
                (sub_brand_priorty_df['LOCATION_CODE'] == store_id) &
                (sub_brand_priorty_df['CONFIDENCE'] >= p_min) &
                (sub_brand_priorty_df['CONFIDENCE'] <p_max)
            ].sort_values('CONFIDENCE', ascending=False)
            

            # For each sub_brand in that tier
            for _, sb_row in sb_in_tier.iterrows():
                sub_brand = sb_row['SUB_BRAND_NAME']
                sb_priority = sb_row['CONFIDENCE']
                

                # 2) Filter collections in that same priority range
                coll_in_tier = store_coll_priority_df[
                    (store_coll_priority_df['LOCATION_CODE'] == store_id) &
                    (store_coll_priority_df['SUB_BRAND_NAME'] == sub_brand) #&
                    # (store_coll_priority_df['CONFIDENCE']>0)
                ].sort_values('CONFIDENCE', ascending=False)

                for _, c_row in coll_in_tier.iterrows():
                    collection = c_row['VM_GROUP']
                    coll_priority = c_row['CONFIDENCE']
                    store_grade = c_row['STORE_GRADE']

                    # Allocate
                    local_allocations = allocate_skus_for_subbrand_collection(
                        store_id,
                        sub_brand,
                        sb_priority,
                        collection,
                        coll_priority,
                        store_grade,
                        country_code
                    )
                    final_allocations.extend(local_allocations)
    return final_allocations


final_allocs = allocate_by_priority_tiers(
    store_list,
    sub_brand_priorty_df,
    store_coll_priority_df,
    subbrand_collection_to_skus,
    store_capacity_map,
    min_max_lookup,
    priority_tiers
)
allocations_df = pd.DataFrame(final_allocs)

# COMMAND ----------

allocations_df[(allocations_df['LOCATION_CODE']=='S011601') &
               (allocations_df['OPTION_CODE']=='168101-25007-038')
               ]

# COMMAND ----------

print(allocations_df.shape)
allocations_df = allocations_df.drop_duplicates()
print(allocations_df.shape)

# COMMAND ----------

allocated_col_df = allocations_df.groupby(['COUNTRY_CODE','LOCATION_CODE','STORE_GRADE','SUB_BRAND_NAME','VM_GROUP'], as_index=False).agg({'OPTION_CODE':'nunique'})


allocatd_collection_cov_df = allocated_col_df.merge(original_coll_df, on="VM_GROUP", how="left")
allocatd_collection_cov_df['COLLECTION_COV'] = allocatd_collection_cov_df['OPTION_CODE'] / allocatd_collection_cov_df['TOTAL_OPTION_COUNT']
allocatd_collection_cov_df.sort_values('COLLECTION_COV', ascending=True).head()

# COMMAND ----------

store_room_capacity_df = (
    spark.sql("SELECT * FROM gold.`custom-analysis`.location_option_count_Dup")
    .toPandas()
    .astype({
        'MIN_OPTIONS': 'int',
        'TOTAL_ROOMS': 'int',
        'MAX_OPTIONS': 'int',
        'MAX_STOCK_LEVEL': 'int'
    })
)
store_room_capacity_df.head()
store_room_capacity_df['MIN_OPTIONS_PER_ROOM'] = np.round(store_room_capacity_df['MIN_OPTIONS'] / store_room_capacity_df['TOTAL_ROOMS'])
store_room_capacity_df['MAX_OPTIONS_PER_ROOM'] = np.round(store_room_capacity_df['MAX_OPTIONS'] / store_room_capacity_df['TOTAL_ROOMS'])
store_room_capacity_df.head()

# COMMAND ----------

final_table['TOTAL_OPTIONS'] = 100000

# COMMAND ----------

allocation_results = []

# COMMAND ----------

for store in final_table['LOCATION_CODE'].unique():
    location_code = store
    pullout_store_sku_df = final_table[final_table['LOCATION_CODE'] == location_code] # get all pullout brands with number of collections
    brand_list = pullout_store_sku_df['BRAND_NAME'].unique() # list unique brands to the store
    for brand in brand_list:
        brand_capacity_df = store_room_capacity_df[
            (store_room_capacity_df['LOCATION_CODE'] == location_code) & 
            (store_room_capacity_df['BRAND_NAME'] == brand)
            ] # Storeroom capacity
        brand_option_pullout_df = pullout_store_sku_df[pullout_store_sku_df['BRAND_NAME'] == brand]
        total_option_pullout = brand_option_pullout_df['TOTAL_OPTIONS'].sum()
        
        if brand_capacity_df.empty:
            continue

        max_allocated_rooms = int(np.round(total_option_pullout / brand_capacity_df['MAX_OPTIONS_PER_ROOM'].iloc[0]))
        sub_brand_mask = ((sub_brand_priorty_df['LOCATION_CODE']==location_code) &  
                          (sub_brand_priorty_df['BRAND_NAME']==brand) &
                          (sub_brand_priorty_df['CONFIDENCE']>0)
                          )
        
        sub_brand_df = sub_brand_priorty_df[sub_brand_mask].sort_values('CONFIDENCE', 
                                                                        ascending=False)
        
        # We'll track how many options are left to allocate for this brand
        remaining_to_allocate = total_option_pullout
        for _, subbrand_row in sub_brand_df.iterrows():
            sub_brand_name = subbrand_row['SUB_BRAND_NAME']
            col_mask = ((store_coll_priority_df['LOCATION_CODE']==location_code) &  
                        (store_coll_priority_df['BRAND_NAME']==brand) & 
                        (store_coll_priority_df['SUB_BRAND_NAME']==sub_brand_name) &
                        (store_coll_priority_df['CONFIDENCE']>0)
                        )
            collection_priority = store_coll_priority_df[col_mask].sort_values('CONFIDENCE', 
                                                                                     ascending=False)
            for _, col_row in collection_priority.iterrows():
                if remaining_to_allocate <= 0:
                    break  # No more needed
                
                coll_code = col_row['VM_GROUP']
                coll_option_count = col_row['TOTAL_OPTION_COUNT']
                
                if remaining_to_allocate >= coll_option_count:
                    # Allocate full collection
                    allocation_results.append({
                        'LOCATION_CODE': location_code,
                        'BRAND_NAME': brand,
                        'TOTAL_OPTIONS':coll_option_count,
                        'SUB_BRAND_NAME': sub_brand_name,
                        'VM_GROUP': coll_code,
                        'ALLOCATED_OPTIONS': coll_option_count,
                        "MAX_ALLOCATED_ROOMS": max_allocated_rooms
                    })
                    remaining_to_allocate -= coll_option_count
                
                else:
                    ratio = remaining_to_allocate / coll_option_count
                    if ratio > 0.75: #or location_code in ['K1006','Q01','R03','R06','U011004','U041001']:
                        # Allocate full collection (even though it’s more than leftover)
                        allocation_results.append({
                            'LOCATION_CODE': location_code,
                            'BRAND_NAME': brand,
                            'TOTAL_OPTIONS':coll_option_count,
                            'SUB_BRAND_NAME': sub_brand_name,
                            'COLLECTION_CODE': coll_code,
                            'ALLOCATED_OPTIONS': remaining_to_allocate,
                            "MAX_ALLOCATED_ROOMS": max_allocated_rooms
                        })
                        remaining_to_allocate = 0
                    else:
                        # skip the collections
                        pass


            
            if remaining_to_allocate <= 0:
                # Done allocating for this brand
                break

coll_allocation_df = pd.DataFrame(allocation_results)

# COMMAND ----------

coll_allocation_df

# COMMAND ----------

coll_allocation_df['LOCATION_CODE'].nunique()

# COMMAND ----------

coll_allocation_df['COLLECTION_COV'] = coll_allocation_df['ALLOCATED_OPTIONS'] / coll_allocation_df['TOTAL_OPTIONS']

# COMMAND ----------

coll_allocation_df.sort_values('COLLECTION_COV', ascending=True)

# COMMAND ----------

coll_allocation_df['BRAND_NAME'].unique()

# COMMAND ----------

allocated_collection_list= []

# COMMAND ----------

for i, row in coll_allocation_df.iterrows():
    location_code = row['LOCATION_CODE']
    brand = row['BRAND_NAME']
    sub_brand = row['SUB_BRAND_NAME']
    coll_code = row['VM_GROUP']
    allocated_options = row['ALLOCATED_OPTIONS']
    max_allocated_rooms = row['MAX_ALLOCATED_ROOMS']
    coll_cov = row['COLLECTION_COV']
    total_coll_option = row['TOTAL_OPTIONS']

    allocated_collection_sku_df = allocations_df.loc[
                        (allocations_df['LOCATION_CODE']==location_code) & 
                        (allocations_df['BRAND_NAME']==brand) & 
                        (allocations_df['SUB_BRAND_NAME']==sub_brand) &
                        (allocations_df['VM_GROUP']==coll_code),
                        ]
    
    if coll_cov==1:
        allocated_collection_list.append(allocated_collection_sku_df)
    else:
        # Group by OPTION_CODE and sum the allocated quantity
        option_summary = allocated_collection_sku_df.groupby(['OPTION_CODE']).agg({'ALLOC_QTY': 'sum'}).reset_index()
        option_summary = option_summary.sort_values(by='ALLOC_QTY', ascending=False)
        top_n_options = option_summary.head(allocated_options)['OPTION_CODE'].unique()
        allocated_collection_sku_df = allocated_collection_sku_df[allocated_collection_sku_df['OPTION_CODE'].isin(top_n_options)]
        allocated_collection_list.append(allocated_collection_sku_df)

# COMMAND ----------

final_sku_collection_df = pd.concat(allocated_collection_list, axis=0, ignore_index=True)
final_sku_collection_df.head()

# COMMAND ----------

global_sku_stock = spark.sql(f"""
                            select SKU_CODE, round(sum(RETAIL_ALLOCATION) *0.8) as RETAIL_ALLOCATED_COUNT 
                            from gold.`custom-analysis`.intial_alloc_draft
                            --WHERE
                            -- OPTION_CODE 
                            --in 
                            -- {tuple(global_options_df['OPTION_CODE'].tolist())}
                            group by SKU_CODE
                               """
                             ).toPandas() # total global SKU count
global_sku_stock.head()

# COMMAND ----------

mask = final_sku_collection_df['COUNTRY_CODE'] == 'OMN'
final_sku_collection_df.loc[mask, 'ALLOC_QTY'] = final_sku_collection_df.loc[mask, 'ALLOC_QTY'].clip(upper=3)

# COMMAND ----------

# final_sku_collection_df = final_sku_collection_df[~(final_sku_collection_df['VM_GROUP'].str.contains('RW9|RE8|REFF|RE2|ED2', na=False))]

# COMMAND ----------

store_df = sku_demand_df[(sku_demand_df['ALLOC_TYPE']=='WAREHOUSE')]
pivot_df = store_df.pivot_table(
    index=['STORE_ID', 'SKU_CODE'], 
    columns='DEMAND_WEEK', 
    values='STORE_ALLOC_QTY'
).reset_index()
pivot_df.rename({'STORE_ID':'LOCATION_CODE'}, axis=1, inplace=True)

store_allocated_qty_df = final_sku_collection_df.copy()
store_allocated_qty_df = store_allocated_qty_df.merge(pivot_df, on=['LOCATION_CODE','SKU_CODE'], how='left')
store_allocated_qty_df[store_allocated_qty_df[202534].isnull()]

# COMMAND ----------

store_allocated_qty_df.isnull().sum()

# COMMAND ----------

sku_allocated_df = final_sku_collection_df.groupby(['SKU_CODE','VM_GROUP','SUB_BRAND_NAME'], as_index=False).agg({'ALLOC_QTY':'sum'}) # Total Allocated SKU Count
global_sku_df = sku_allocated_df.merge(global_sku_stock[['SKU_CODE','RETAIL_ALLOCATED_COUNT']], on='SKU_CODE', how='left')
global_sku_df.head()

# COMMAND ----------

global_sku_df['ALLOC_QTY'] = global_sku_df['ALLOC_QTY'].astype(float)
global_sku_df['RETAIL_ALLOCATED_COUNT'] = global_sku_df['RETAIL_ALLOCATED_COUNT'].astype(float)
overallocated_sku_df = global_sku_df[global_sku_df['ALLOC_QTY']>global_sku_df['RETAIL_ALLOCATED_COUNT']]
overallocated_sku_df['OVER_ALLOC_QTY'] = overallocated_sku_df['ALLOC_QTY'] - overallocated_sku_df['RETAIL_ALLOCATED_COUNT']

# COMMAND ----------

overallocated_sku_df = overallocated_sku_df.sort_values('OVER_ALLOC_QTY', ascending=False)
overallocated_sku_df

# COMMAND ----------

overallocated_sku_df[(overallocated_sku_df['RETAIL_ALLOCATED_COUNT']==0) & (overallocated_sku_df['VM_GROUP']=='RE2')]

# COMMAND ----------

for i,row in overallocated_sku_df.iterrows():
    sku_code = row['SKU_CODE']
    over_allocated_qty = row['OVER_ALLOC_QTY']
    coll_code = row['VM_GROUP']
    
    while over_allocated_qty>0:
        
        # 1) Get all rows for this SKU, sort descending by ALLOC_QTY
        if coll_code in ['CHO1']:
            sku_df = final_sku_collection_df[
            (final_sku_collection_df['SKU_CODE'] == sku_code) &
            (final_sku_collection_df['STORE_GRADE'].isin(['A','B']))].sort_values('ALLOC_QTY', ascending=True)
        else:
            sku_df = final_sku_collection_df[
                (final_sku_collection_df['SKU_CODE'] == sku_code) &
                (final_sku_collection_df['STORE_GRADE'].isin(['C']))

            ].sort_values('ALLOC_QTY', ascending=True)
        
        #2) Find reduceble SKU's
        reducible_df = sku_df[sku_df['ALLOC_QTY'] > 0]
        if reducible_df.empty:
            break
        # import pdb;pdb.set_trace()

        # 3) Pick the top row (the largest ALLOC_QTY)
        largest_index = reducible_df.index[0]  # first row in the sorted data
        
        # 4) Reduce that store's allocation by exactly 1
        current_alloc = final_sku_collection_df.at[largest_index, 'ALLOC_QTY']
        final_sku_collection_df.at[largest_index, 'ALLOC_QTY'] = 0 # current_alloc - 1
        # 5) Decrement the over-allocated amount by 1
        over_allocated_qty -= current_alloc

# COMMAND ----------

sku_allocated_df = final_sku_collection_df.groupby(['SKU_CODE','VM_GROUP','SUB_BRAND_NAME'], as_index=False).agg({'ALLOC_QTY':'sum'}) # Total Allocated SKU Count
global_sku_df = sku_allocated_df.merge(global_sku_stock, on='SKU_CODE', how='left')
global_sku_df.head()

overallocated_sku_df = global_sku_df[global_sku_df['ALLOC_QTY']>global_sku_df['RETAIL_ALLOCATED_COUNT']]
overallocated_sku_df['OVER_ALLOC_QTY'] = overallocated_sku_df['ALLOC_QTY'] - overallocated_sku_df['RETAIL_ALLOCATED_COUNT'].astype(float)

overallocated_sku_df = overallocated_sku_df.sort_values('OVER_ALLOC_QTY', ascending=False)
overallocated_sku_df

# COMMAND ----------

for i,row in overallocated_sku_df.iterrows():
    sku_code = row['SKU_CODE']
    over_allocated_qty = row['OVER_ALLOC_QTY']
    coll_code = row['VM_GROUP']
    
    while over_allocated_qty>0:
        
        # 1) Get all rows for this SKU, sort descending by ALLOC_QTY
        if coll_code in ['CHO1']:
            sku_df = final_sku_collection_df[
            (final_sku_collection_df['SKU_CODE'] == sku_code) &
            (final_sku_collection_df['STORE_GRADE'].isin(['A','B','C']))].sort_values('ALLOC_QTY', ascending=True)
        else:
            sku_df = final_sku_collection_df[
                (final_sku_collection_df['SKU_CODE'] == sku_code) &
                (final_sku_collection_df['STORE_GRADE'].isin(['B']))

            ].sort_values('ALLOC_QTY', ascending=True)
        
        #2) Find reduceble SKU's
        reducible_df = sku_df[sku_df['ALLOC_QTY'] > 0]
        if reducible_df.empty:
            break
        # import pdb;pdb.set_trace()

        # 3) Pick the top row (the largest ALLOC_QTY)
        largest_index = reducible_df.index[0]  # first row in the sorted data
        
        # 4) Reduce that store's allocation by exactly 1
        current_alloc = final_sku_collection_df.at[largest_index, 'ALLOC_QTY']
        final_sku_collection_df.at[largest_index, 'ALLOC_QTY'] = 0 # current_alloc - 1
        # 5) Decrement the over-allocated amount by 1
        over_allocated_qty -= current_alloc

# COMMAND ----------

sku_allocated_df = final_sku_collection_df.groupby(['SKU_CODE','VM_GROUP','SUB_BRAND_NAME'], as_index=False).agg({'ALLOC_QTY':'sum'}) # Total Allocated SKU Count
global_sku_df = sku_allocated_df.merge(global_sku_stock, on='SKU_CODE', how='left')
global_sku_df.head()

overallocated_sku_df = global_sku_df[global_sku_df['ALLOC_QTY']>global_sku_df['RETAIL_ALLOCATED_COUNT']]
overallocated_sku_df['OVER_ALLOC_QTY'] = overallocated_sku_df['ALLOC_QTY'] - overallocated_sku_df['RETAIL_ALLOCATED_COUNT'].astype(float)

overallocated_sku_df = overallocated_sku_df.sort_values('OVER_ALLOC_QTY', ascending=False)
overallocated_sku_df

# COMMAND ----------

for i,row in overallocated_sku_df.iterrows():
    sku_code = row['SKU_CODE']
    over_allocated_qty = row['OVER_ALLOC_QTY']
    coll_code = row['VM_GROUP']
    
    while over_allocated_qty>0:
        
        # 1) Get all rows for this SKU, sort descending by ALLOC_QTY
        if coll_code in ['CHO1']:
            sku_df = final_sku_collection_df[
            (final_sku_collection_df['SKU_CODE'] == sku_code) &
            (final_sku_collection_df['STORE_GRADE'].isin(['A','B','C']))].sort_values('ALLOC_QTY', ascending=True)
        else:
            sku_df = final_sku_collection_df[
                (final_sku_collection_df['SKU_CODE'] == sku_code) &
                (final_sku_collection_df['STORE_GRADE'].isin(['A']))

            ].sort_values('ALLOC_QTY', ascending=True)
        
        #2) Find reduceble SKU's
        reducible_df = sku_df[sku_df['ALLOC_QTY'] > 0]
        if reducible_df.empty:
            break
        # import pdb;pdb.set_trace()

        # 3) Pick the top row (the largest ALLOC_QTY)
        largest_index = reducible_df.index[0]  # first row in the sorted data
        
        # 4) Reduce that store's allocation by exactly 1
        current_alloc = final_sku_collection_df.at[largest_index, 'ALLOC_QTY']
        final_sku_collection_df.at[largest_index, 'ALLOC_QTY'] = 0 # current_alloc - 1
        # 5) Decrement the over-allocated amount by 1
        over_allocated_qty -= current_alloc


# COMMAND ----------

global_option_df = store_sku_df.groupby(
    'OPTION_CODE', 
    as_index=False).agg(
        {'SKU_CODE':'nunique'}
        ).rename({'SKU_CODE':'TOTAL_SIZES'}, axis=1)

filtered_df = final_sku_collection_df[final_sku_collection_df['ALLOC_QTY'] >= 1]
allocated_option_df = filtered_df.groupby(['LOCATION_CODE','OPTION_CODE'], as_index=False).agg({'SIZE_CODE':'nunique'}).rename({'SIZE_CODE':'ALLOC_SIZE'}, axis=1)

option_alloc_df = allocated_option_df.merge(global_option_df, on=['OPTION_CODE'], how='left')
option_alloc_df['OPTION_COV'] = np.round(option_alloc_df['ALLOC_SIZE']/option_alloc_df['TOTAL_SIZES'],2)
option_alloc_df.sort_values('OPTION_COV', ascending=True)

# COMMAND ----------

final_sku_collection_df = final_sku_collection_df.merge(option_alloc_df[['LOCATION_CODE','OPTION_CODE','ALLOC_SIZE','TOTAL_SIZES','OPTION_COV']], on=['LOCATION_CODE','OPTION_CODE'], how='left')
final_sku_collection_df.head()

# COMMAND ----------

final_sku_collection_df[final_sku_collection_df['VM_GROUP']=='RE2']

# COMMAND ----------

final_sku_collection_df['OPTION_COV'].fillna(0, inplace=True)

# COMMAND ----------

allocated_collection_df = final_sku_collection_df[final_sku_collection_df['OPTION_COV']>=0.5].groupby(['COUNTRY_CODE','LOCATION_CODE','STORE_GRADE','SUB_BRAND_NAME','VM_GROUP'], as_index=False).agg({'OPTION_CODE':'nunique'})

allocatd_collection_cov_df = allocated_collection_df.merge(original_coll_df, on="VM_GROUP", how="left")
allocatd_collection_cov_df['COLLECTION_COV'] = allocatd_collection_cov_df['OPTION_CODE'] / allocatd_collection_cov_df['TOTAL_OPTION_COUNT']
allocatd_collection_cov_df.sort_values('COLLECTION_COV', ascending=True).head()


final_sku_collection_df = final_sku_collection_df.merge(allocatd_collection_cov_df[['LOCATION_CODE','VM_GROUP','COLLECTION_COV']]
                              , on=['LOCATION_CODE','VM_GROUP'], how='left')

# COMMAND ----------

final_sku_collection_df

# COMMAND ----------

final_sku_collection_df['COLLECTION_COV'].fillna(0, inplace=True)

# COMMAND ----------

final_sku_collection_df[(final_sku_collection_df['VM_GROUP']=='RE2') & (final_sku_collection_df['ALLOC_QTY']>0)]

# COMMAND ----------

final_sku_collection_df = final_sku_collection_df[~(final_sku_collection_df['COLLECTION_COV']<0.70)]

# COMMAND ----------

final_sku_collection_df = final_sku_collection_df[~(final_sku_collection_df['ALLOC_QTY']<=0)]
final_sku_collection_df = final_sku_collection_df[~(final_sku_collection_df['OPTION_COV']<0.5)]

# COMMAND ----------

final_sku_collection_df[final_sku_collection_df['VM_GROUP'].str.contains("ED2")]

# COMMAND ----------

demand_df = pd.read_csv("datasets/backup/weekwise_demand_aug_4_v1.csv")
demand_df

# COMMAND ----------

# demand_df = pd.read_csv("weekwise_demand_july_28.csv")

# Step 1: Sum ALLOC_QTY by size, per location and collection
size_alloc = final_sku_collection_df.groupby(['LOCATION_CODE', 'VM_GROUP', 'SIZE_CODE'])['ALLOC_QTY'].sum().reset_index()

# Step 2: Sum total ALLOC_QTY per location and collection
total_alloc = size_alloc.groupby(['LOCATION_CODE', 'VM_GROUP'])['ALLOC_QTY'].sum().reset_index()
total_alloc = total_alloc.rename(columns={'ALLOC_QTY': 'TOTAL_ALLOC_QTY'})

# Step 3: Merge to get total into the size-level DataFrame
size_alloc = size_alloc.merge(total_alloc, on=['LOCATION_CODE', 'VM_GROUP'])

# Step 4: Calculate percentage
size_alloc['ALLOC_PCT'] = (size_alloc['ALLOC_QTY'] / size_alloc['TOTAL_ALLOC_QTY']) * 100

# Optional: Round percentage for readability
size_alloc['ALLOC_PCT'] = size_alloc['ALLOC_PCT'].round(2)

# COMMAND ----------

# Step 1: Calculate total ALLOC_QTY per LOCATION_CODE + COLLECTION_CODE
alloc_sum = (
    final_sku_collection_df
    .groupby(['LOCATION_CODE', 'VM_GROUP'])['ALLOC_QTY']
    .sum()
    .reset_index()
)
# Step 2:
size_alloc_dict = (
    size_alloc
    .groupby(['LOCATION_CODE', 'VM_GROUP'])
    .apply(lambda g: dict(zip(g['SIZE_CODE'], g['ALLOC_PCT'])))
    .reset_index(name='SIZE_DISTRIBUTION')
)

# Step 2: Merge with SIZE_DISTRIBUTION dict DataFrame
final_with_qty = size_alloc_dict.merge(
    alloc_sum,
    on=['LOCATION_CODE', 'VM_GROUP'],
    how='left'
)

# COMMAND ----------

sku_summary_df = coll_allocation_df[['LOCATION_CODE','BRAND_NAME','SUB_BRAND_NAME','VM_GROUP','TOTAL_OPTIONS','ALLOCATED_OPTIONS']]
sku_summary_df.rename({'TOTAL_OPTIONS':"TOTAL_OPTION_PURCHASE",'ALLOCATED_OPTIONS':'TOTAL_OPTIONS_DISTRIBUTE'},axis=1,inplace=True)

# COMMAND ----------

demand_df.rename({'COLLECTION_CODE':'VM_GROUP'}, axis=1, inplace=True)

# COMMAND ----------

allocation_demand_df = demand_df.groupby(['STORE_ID','SKU_CODE','VM_GROUP'], as_index=False).agg({'DIST_QTY':'sum'})
allocation_demand_df.head()
allocation_demand_df = allocation_demand_df.rename({'DIST_QTY':'FORECASTED_QTY','STORE_ID':'LOCATION_CODE'}, axis=1)

# COMMAND ----------

final_alloc_df = final_sku_collection_df.merge(allocation_demand_df[['LOCATION_CODE','SKU_CODE','FORECASTED_QTY']], on=['LOCATION_CODE','SKU_CODE'], how='left')

# COMMAND ----------

final_alloc_df['FORECASTED_QTY'] = final_alloc_df['FORECASTED_QTY'].apply(
    lambda x: np.random.choice([1,2,3]) if pd.isna(x) else x
)

# COMMAND ----------

mask = (final_alloc_df['ALLOC_QTY'] > final_alloc_df['FORECASTED_QTY']) & (final_alloc_df['FORECASTED_QTY'] != 0)

final_alloc_df.loc[mask, 'FORECASTED_QTY'] = final_alloc_df.loc[mask].apply(
    lambda row: row['ALLOC_QTY'] + np.random.choice([0, 1]), axis=1
)

# COMMAND ----------

final_alloc_df['WAREHOUSE_QTY'] = final_alloc_df['FORECASTED_QTY'] - final_alloc_df['ALLOC_QTY']
final_alloc_df.loc[final_alloc_df['WAREHOUSE_QTY']<=0,'WAREHOUSE_QTY'] = 0

# COMMAND ----------

warehouse_df = spark.sql("""select  LOCATION_CODE, COUNTRY_CODE from bronze.orjwan.locations where STORETYPE_NEW='LOCAL WAREHOUSE' and active=1""").toPandas()
warehouse_df

# COMMAND ----------

warehouse_df = warehouse_df[warehouse_df['LOCATION_CODE']!='U019901']

# COMMAND ----------

country_wise_sku_df = final_alloc_df.groupby(['COUNTRY_CODE','SKU_CODE'], as_index=False).agg({'WAREHOUSE_QTY':'sum'})
warehouse_df = country_wise_sku_df.merge(warehouse_df, on=['COUNTRY_CODE'], how='left')

# COMMAND ----------

warehouse_df['WAREHOUSE_CODE_NEW'] = warehouse_df['COUNTRY_CODE'] +"-" + warehouse_df['LOCATION_CODE']

# COMMAND ----------

global_df = spark.sql("""
select *
 from gold.`custom-analysis`.product_attributes
 """).toPandas()

# COMMAND ----------

glob = global_df[['SKU_CODE',
           'LAUNCH_DATE',
           'BRAND_NAME','SUB_BRAND_NAME','SIZE_GROUP','DESIGN_CODE','VM_GROUP',
           'DESIGN_PROJECT_CODE','SEASON_NAME',	'SUB_SEASON_NAME'	,'COLOR_NAME'	,'GROUP_NAME',	'SUB_GROUP_NAME'	,'MASTER_PRODUCT_CATEGORY_NAME'	,'MASTER_PRODUCT_GROUP_NAME'	,'DESIGN_ATTRIBUTE1',	'DESIGN_ATTRIBUTE2'	,'DESIGN_ATTRIBUTE3'	,'DESIGN_ATTRIBUTE4'
           ]].drop_duplicates()
glob.rename({'ItemCode':'SKU_CODE'}, axis=1, inplace=True)

# COMMAND ----------

warehouse_qty_df = warehouse_df.merge(glob, on='SKU_CODE', how='left')
warehouse_qty_df.head()

# COMMAND ----------

country_wise_allo_df = final_sku_collection_df.groupby(['COUNTRY_CODE','SKU_CODE'], as_index=False).agg({'ALLOC_QTY':'sum'})

# COMMAND ----------

pivot_df1 = warehouse_qty_df.pivot_table(
    index=[
           'SKU_CODE',
           'LAUNCH_DATE',
           'BRAND_NAME'	,
           'SUB_BRAND_NAME',
           'SIZE_GROUP'	,'DESIGN_CODE'	,'DESIGN_PROJECT_CODE'	,'SEASON_NAME',	'SUB_SEASON_NAME'	,'COLOR_NAME',	'GROUP_NAME'	,'SUB_GROUP_NAME',	'MASTER_PRODUCT_CATEGORY_NAME',	'MASTER_PRODUCT_GROUP_NAME'	,'DESIGN_ATTRIBUTE1'	,'DESIGN_ATTRIBUTE2',	'DESIGN_ATTRIBUTE3',	'DESIGN_ATTRIBUTE4'	,
           ],
    columns='WAREHOUSE_CODE_NEW',
    values='WAREHOUSE_QTY',
    aggfunc='sum',  # or 'first' if there's no duplication
    fill_value=0    # optional: fill NaNs with 0
).add_prefix("TOTAL_SKU_BY_WAREHOUSE_").reset_index()

# COMMAND ----------

country_alloc_df = warehouse_qty_df.merge(country_wise_allo_df, on=['SKU_CODE','COUNTRY_CODE'], how='left').fillna(0).rename({'ALLOC_QTY':'TOTAL_ALLOCATED_BY_REGION'}, axis=1)

# COMMAND ----------

pivot_df2 = country_alloc_df.pivot_table(
    index=[
           'SKU_CODE',
           'LAUNCH_DATE',
           'BRAND_NAME'	,
           'SUB_BRAND_NAME',
           'SIZE_GROUP'	,'DESIGN_CODE'	,'DESIGN_PROJECT_CODE'	,'SEASON_NAME',	'SUB_SEASON_NAME'	,'COLOR_NAME',	'GROUP_NAME'	,'SUB_GROUP_NAME',	'MASTER_PRODUCT_CATEGORY_NAME',	'MASTER_PRODUCT_GROUP_NAME'	,'DESIGN_ATTRIBUTE1'	,'DESIGN_ATTRIBUTE2',	'DESIGN_ATTRIBUTE3',	'DESIGN_ATTRIBUTE4'	,
           ],
    columns='WAREHOUSE_CODE_NEW',
    values='TOTAL_ALLOCATED_BY_REGION',
    aggfunc='sum',  # or 'first' if there's no duplication
    fill_value=0    # optional: fill NaNs with 0
).add_prefix("SKU_ALLOC_BY_STORE_REGION_").reset_index()

# COMMAND ----------

final_df = pd.merge(pivot_df1, pivot_df2[['SKU_CODE','SKU_ALLOC_BY_STORE_REGION_BAH-B97','SKU_ALLOC_BY_STORE_REGION_KWT-K9901','SKU_ALLOC_BY_STORE_REGION_OMN-O019901'	,'SKU_ALLOC_BY_STORE_REGION_QA-Q9901',	'SKU_ALLOC_BY_STORE_REGION_SUD-S99'	,'SKU_ALLOC_BY_STORE_REGION_UAE-D98']], on=['SKU_CODE'], how='inner')
final_df.shape

# COMMAND ----------

global_sku_stock = spark.sql("""
                             select SKU_CODE, round(RETAIL_ALLOCATION * 0.80) as GLOBAL_RETAIL_STOCK
                             from 
                             gold.`custom-analysis`.intial_alloc_draft"""
                             ).toPandas() # total global SKU count
global_sku_stock.head()

# COMMAND ----------

sku_summary_global_df = final_df.merge(global_sku_stock, on='SKU_CODE', how='left').fillna(0)

# COMMAND ----------

params = {'WAREHOUSE':['TOTAL_SKU_BY_WAREHOUSE_BAH-B97',	'TOTAL_SKU_BY_WAREHOUSE_KWT-K9901'	,'TOTAL_SKU_BY_WAREHOUSE_OMN-O019901',	'TOTAL_SKU_BY_WAREHOUSE_QA-Q9901'	,'TOTAL_SKU_BY_WAREHOUSE_SUD-S99',	'TOTAL_SKU_BY_WAREHOUSE_UAE-D98'],
'STORE'	:['SKU_ALLOC_BY_STORE_REGION_BAH-B97'	,'SKU_ALLOC_BY_STORE_REGION_KWT-K9901'	,'SKU_ALLOC_BY_STORE_REGION_OMN-O019901',	'SKU_ALLOC_BY_STORE_REGION_QA-Q9901',	'SKU_ALLOC_BY_STORE_REGION_SUD-S99'	,'SKU_ALLOC_BY_STORE_REGION_UAE-D98',
]}

# COMMAND ----------

sku_summary_global_df['TOTAl_WAREHOUSE_QTY'] = sku_summary_global_df[params['WAREHOUSE']].sum(axis=1)
sku_summary_global_df['TOTAl_WAREHOUSE_QTY'] = sku_summary_global_df[params['WAREHOUSE']].sum(axis=1)
sku_summary_global_df['TOTAl_STORE_ALLOC_QTY'] = sku_summary_global_df[params['STORE']].sum(axis=1)

sku_summary_global_df['REMANING_STOCK'] = sku_summary_global_df['GLOBAL_RETAIL_STOCK'].astype(float) - sku_summary_global_df['TOTAl_WAREHOUSE_QTY'].astype(float) - sku_summary_global_df['TOTAl_STORE_ALLOC_QTY'].astype(float)

# COMMAND ----------

warehouse_cols = params['WAREHOUSE']

# COMMAND ----------

def reduce_to_target(nums, target_sum):
    nums = nums.copy()
    total = sum(nums)

    while total > target_sum:
        for i in range(len(nums)):
            if total <= target_sum:
                break
            if nums[i] > 0 and nums[i] == max(nums):  # only reduce highest values
                nums[i] -= 1
                total -= 1
    return nums

over_alloc_df = sku_summary_global_df.loc[
    sku_summary_global_df['REMANING_STOCK'] <= 0
].copy()

n_stores = len(warehouse_cols)
x = 1
for idx, row in over_alloc_df.iterrows():
    over_allocated_qty = abs(row['REMANING_STOCK'])
    total_capacity = [row[col] for col in warehouse_cols]
    capping_target_value =  sum(total_capacity)  - over_allocated_qty
    print(total_capacity, capping_target_value,over_allocated_qty,idx)
    qty = reduce_to_target(total_capacity, capping_target_value)
    sku_summary_global_df.loc[idx, warehouse_cols] = qty
    print(x)
    x += 1    

# COMMAND ----------

sku_summary_global_df.head()

# COMMAND ----------

sku_summary_global_df['TOTAl_WAREHOUSE_QTY'] = sku_summary_global_df[params['WAREHOUSE']].sum(axis=1)
sku_summary_global_df['TOTAl_STORE_ALLOC_QTY'] = sku_summary_global_df[params['STORE']].sum(axis=1)
sku_summary_global_df['REMANING_STOCK'] = sku_summary_global_df['GLOBAL_RETAIL_STOCK'].astype(float) - sku_summary_global_df['TOTAl_WAREHOUSE_QTY'].astype(float) - sku_summary_global_df['TOTAl_STORE_ALLOC_QTY'].astype(float)

# COMMAND ----------

localwarehouse_cols = params['WAREHOUSE']

# COMMAND ----------

sku_summary_global_df

# COMMAND ----------

final_sku_collection_df = final_sku_collection_df.merge(collection_cov_df[['VM_GROUP','LOCATION_CODE','CONFIDENCE']], on=['VM_GROUP','LOCATION_CODE'], how='left')
final_sku_collection_df.head()

# COMMAND ----------

min_wh_stock     = 4          # we want every warehouse to end up with ≥ 4 pcs
low_wh_threshold = 3          # treat ≤ 3 as a shortage
grade_floor = {"A": 3, "B": 2, "C": 1}          # never strip a store below 1 pc of a size/SKU

localwarehouses  = ['TOTAL_SKU_BY_WAREHOUSE_BAH-B97',
 'TOTAL_SKU_BY_WAREHOUSE_KWT-K9901',
 'TOTAL_SKU_BY_WAREHOUSE_OMN-O019901',
 'TOTAL_SKU_BY_WAREHOUSE_QA-Q9901',
 'TOTAL_SKU_BY_WAREHOUSE_SUD-S99',
 'TOTAL_SKU_BY_WAREHOUSE_UAE-D98']

for sku_idx, sku_row in sku_summary_global_df.query("REMANING_STOCK == 0").iterrows():
    sku_code = sku_row["SKU_CODE"]
    
    for wh_col in localwarehouses:
        wh_stock = sku_row[wh_col]
        if wh_stock > low_wh_threshold:
            continue
        country_code = wh_col.split("_")[-1].split("-")[0]
        need_qty     = int(min_wh_stock - wh_stock)
        # import pdb;pdb.set_trace()
        if need_qty<=0:
            continue
        
        candidates = (
            final_sku_collection_df[
                (final_sku_collection_df["SKU_CODE"]     == sku_code) &
                (final_sku_collection_df["COUNTRY_CODE"] == country_code)
            ]
            .sort_values("CONFIDENCE", ascending=True)   # low priority first
        )
        # import pdb;pdb.set_trace()
        for st_idx, st_row in candidates.iterrows():
            if need_qty == 0:
                break
            
            grade        = st_row["STORE_GRADE"]
            min_display  = grade_floor.get(grade, 1)   
            surplus_here = int(max(st_row["ALLOC_QTY"] - min_display, 0))
            take_qty     = int(min(surplus_here, need_qty))
            if take_qty <= 0:
                continue
            final_sku_collection_df.at[st_idx, "ALLOC_QTY"] -= take_qty
            sku_summary_global_df.at[sku_idx, wh_col]       += take_qty
            sku_summary_global_df.at[sku_idx, "TOTAl_WAREHOUSE_QTY"] -= take_qty
            region = [x for x in sku_summary_global_df.columns if x.startswith(f"SKU_ALLOC_BY_STORE_REGION_{country_code}")][0]
            sku_summary_global_df.at[sku_idx, region] -= take_qty
            need_qty -= take_qty
        if need_qty > 0:
            print(
                f"[WARN] SKU {sku_code} | {country_code}: "
                f"still short by {need_qty} pcs after skimming stores."
            )

# COMMAND ----------

# ── config ─────────────────────────────────────────────────
localwarehouses   = [
    "TOTAL_SKU_BY_WAREHOUSE_BAH-B97",
    "TOTAL_SKU_BY_WAREHOUSE_KWT-K9901",
    "TOTAL_SKU_BY_WAREHOUSE_OMN-O019901",
    "TOTAL_SKU_BY_WAREHOUSE_QA-Q9901",
    "TOTAL_SKU_BY_WAREHOUSE_SUD-S99",
    "TOTAL_SKU_BY_WAREHOUSE_UAE-D98",
]

min_wh_stock      = 5        # target level
low_wh_threshold  = 3        # “needs stock” if ≤ 3

# ── allocate central REMANING_STOCK to local warehouses ──
for sku_idx, sku_row in sku_summary_global_df.query("REMANING_STOCK > 0").iterrows():

    remaining_central = int(sku_row["REMANING_STOCK"])
    if remaining_central <= 0:
        continue

    for wh_col in localwarehouses:

        if remaining_central == 0:          # nothing left to give
            break

        current_wh_stock = sku_row[wh_col]

        # only top‑up warehouses that are really low
        if current_wh_stock > low_wh_threshold:
            continue

        # how many pieces do we need to reach the safe level?
        need_qty = int(min(min_wh_stock - current_wh_stock, remaining_central))
        if need_qty <= 0:
            continue

        # ---------- mutate the dataframe in‑place ----------
        sku_summary_global_df.at[sku_idx, wh_col]                  += need_qty
        sku_summary_global_df.at[sku_idx, "TOTAl_WAREHOUSE_QTY"]    += need_qty
        sku_summary_global_df.at[sku_idx, "REMANING_STOCK"]         -= need_qty

        remaining_central -= need_qty

    # optional: flag SKUs that still have central leftovers
    if remaining_central > 0:
        print(
            f"[INFO] SKU {sku_row['SKU_CODE']} still has "
            f"{remaining_central} pcs in DC after warehouse top‑up."
        )


# COMMAND ----------

sku_summary_global_df['TOTAl_WAREHOUSE_QTY'] = sku_summary_global_df[params['WAREHOUSE']].sum(axis=1)
sku_summary_global_df['TOTAl_STORE_ALLOC_QTY'] = sku_summary_global_df[params['STORE']].sum(axis=1)

sku_summary_global_df['REMANING_STOCK'] = sku_summary_global_df['GLOBAL_RETAIL_STOCK'].astype(float) - sku_summary_global_df['TOTAl_WAREHOUSE_QTY'].astype(float) - sku_summary_global_df['TOTAl_STORE_ALLOC_QTY'].astype(float)

# COMMAND ----------

sku_summary_global_df

# COMMAND ----------

sku_summary_global_df[sku_summary_global_df['REMANING_STOCK']>=100]

# COMMAND ----------

sku_summary_global_df['REMANING_STOCK'].max()

# COMMAND ----------

global_sku_df = spark.sql("""select RETAIL_ALLOCATION, SKU_CODE,ECOM_ALLOCATION, round((RETAIL_ALLOCATION * 0.2)) as REPLENISHMENT_QTY from gold.`custom-analysis`.intial_alloc_draft""").toPandas()
global_sku_df.head()

# COMMAND ----------

sku_summary_global_df.merge(global_sku_df, on='SKU_CODE', how='left')

# COMMAND ----------

sku_summary_global_df['REPLNISHMENT_QTY'] = (round(sku_summary_global_df['GLOBAL_RETAIL_STOCK'].astype(float)/0.8) - sku_summary_global_df['GLOBAL_RETAIL_STOCK'].astype(float))

# COMMAND ----------

# ── config ─────────────────────────────────────────────────
localwarehouses   = [
    "TOTAL_SKU_BY_WAREHOUSE_BAH-B97",
    "TOTAL_SKU_BY_WAREHOUSE_KWT-K9901",
    "TOTAL_SKU_BY_WAREHOUSE_OMN-O019901",
    "TOTAL_SKU_BY_WAREHOUSE_QA-Q9901",
    "TOTAL_SKU_BY_WAREHOUSE_SUD-S99",
    "TOTAL_SKU_BY_WAREHOUSE_UAE-D98",
]

min_wh_stock      = 2        # target level
low_wh_threshold  = 0        # “needs stock” if ≤ 3

# ── allocate central REMANING_STOCK to local warehouses ──
for sku_idx, sku_row in sku_summary_global_df.iterrows():

    remaining_central = int(sku_row["REPLNISHMENT_QTY"])
    if remaining_central <= 0:
        continue

    for wh_col in localwarehouses:
        country_code = wh_col.split("_")[-1].split("-")[0]
        if country_code in ('BAH','OMN','QA'):
            continue

        if remaining_central == 0:          # nothing left to give
            break

        current_wh_stock = sku_row[wh_col]

        # only top‑up warehouses that are really low
        if current_wh_stock > low_wh_threshold:
            continue

        # how many pieces do we need to reach the safe level?
        need_qty = int(min(min_wh_stock - current_wh_stock, remaining_central))
        if need_qty <= 0:
            continue

        # ---------- mutate the dataframe in‑place ----------
        sku_summary_global_df.at[sku_idx, wh_col]                  += need_qty
        sku_summary_global_df.at[sku_idx, "TOTAl_WAREHOUSE_QTY"]    += need_qty
        sku_summary_global_df.at[sku_idx, "REPLNISHMENT_QTY"]         -= need_qty

        remaining_central -= need_qty

    # optional: flag SKUs that still have central leftovers
    if remaining_central > 0:
        print(
            f"[INFO] SKU {sku_row['SKU_CODE']} still has "
            f"{remaining_central} pcs in DC after warehouse top‑up."
        )


# COMMAND ----------

mask = (sku_summary_global_df['REPLNISHMENT_QTY']==0)

sku_summary_global_df.loc[mask,'REPLNISHMENT_QTY'] = sku_summary_global_df.loc[mask,'REPLENISHMENT_AND_REMANING_QTY'] 

# COMMAND ----------

sku_summary_global_df['TOTAl_WAREHOUSE_QTY'] = sku_summary_global_df[params['WAREHOUSE']].sum(axis=1)
sku_summary_global_df['TOTAl_STORE_ALLOC_QTY'] = sku_summary_global_df[params['STORE']].sum(axis=1)

sku_summary_global_df['REMANING_STOCK'] = sku_summary_global_df['GLOBAL_RETAIL_STOCK'].astype(float) - sku_summary_global_df['TOTAl_WAREHOUSE_QTY'].astype(float) - sku_summary_global_df['TOTAl_STORE_ALLOC_QTY'].astype(float)

sku_summary_global_df['REPLENISHMENT_AND_REMANING_QTY'] = sku_summary_global_df['REPLNISHMENT_QTY'] + sku_summary_global_df['REMANING_STOCK'] 

# COMMAND ----------

sku_summary_global_df['REPLENISHMENT_AND_REMANING_QTY'] = sku_summary_global_df['REPLNISHMENT_QTY'] + sku_summary_global_df['REMANING_STOCK'] 

# COMMAND ----------

sku_summary_global_df.sort_values(['REMANING_STOCK'], ascending=False).head()

# COMMAND ----------

sku_summary_global_df[sku_summary_global_df['REMANING_STOCK']<0]

# COMMAND ----------

sub_brand_conf_df.rename({"CONFIDENCE":'SB_CONFIDENCE'}, axis=1, inplace=True)

# COMMAND ----------

# --- parameters --------------------------------------------------------------
grade_order        = ("A", "B",'C')     # only fill A → B priority
low_stock_thresh   = 2              # ≤ 2 pieces at a store = needs stock

# only the SKUs that still have > 10 units to give away
surplus_df = (
    sku_summary_global_df
    .loc[sku_summary_global_df["REMANING_STOCK"] > 10,
         ["SKU_CODE", "REMANING_STOCK"]]
    .copy()
)

# --- allocation loop ---------------------------------------------------------
for sku_code, surplus_qty in surplus_df.itertuples(index=False):

    if surplus_qty <= 0:                     # just in case the row changed upstream
        continue

    # 1️⃣ Stores that actually need this SKU
    need_mask = (
        (final_sku_collection_df["SKU_CODE"]   == sku_code) &
        (final_sku_collection_df["ALLOC_QTY"]  <= low_stock_thresh) &
        (final_sku_collection_df["STORE_GRADE"].isin(grade_order))
    )

    candidate_stores = (
        final_sku_collection_df[need_mask]
        .merge(
            sub_brand_conf_df,
            on=["LOCATION_CODE", "BRAND_NAME", "SUB_BRAND_NAME"],
            how="left"
        )
        .sort_values("SB_CONFIDENCE", ascending=False)          # highest confidence first
    )

    # 2️⃣ Loop through the best stores, one unit at a time
    for _, store_row in candidate_stores.head(int(surplus_qty)).iterrows():

        loc_code     = store_row["LOCATION_CODE"]
        country_code = store_row["COUNTRY_CODE"]

        # ── column that holds central stock for this country ────────────────
        region_col = (
            sku_summary_global_df
            .filter(regex=rf"^SKU_ALLOC_BY_STORE_REGION_{country_code}")
            .columns[0]          # first (and usually only) match
        )

        # ---------- update store‑level dataframe ----------
        store_sel = (
            (final_sku_collection_df["LOCATION_CODE"] == loc_code) &
            (final_sku_collection_df["SKU_CODE"]      == sku_code)   # 🐞 FIXED (was location_code)
        )
        final_sku_collection_df.loc[store_sel, "ALLOC_QTY"] += 1

        # ---------- update global SKU summary ----------
        sku_sel = sku_summary_global_df["SKU_CODE"] == sku_code
        sku_summary_global_df.loc[sku_sel, region_col]                        -= 1
        sku_summary_global_df.loc[sku_sel, "REMANING_STOCK"]                  -= 1  # 🐞 was overwriting with -1
        sku_summary_global_df.loc[sku_sel, "TOTAl_STORE_ALLOC_QTY"]           += 1
        sku_summary_global_df.loc[sku_sel, "REPLENISHMENT_AND_REMANING_QTY"]  -= 1  # 🐞 was overwriting with -1

        # keep the loop in sync with what we just gave away
        surplus_qty -= 1
        if surplus_qty == 0:
            break


# COMMAND ----------

# sku_summary_global_df['REPLENISHMENT_AND_REMANING_QTY'] = sku_summary_global_df['REPLNISHMENT_QTY'] + sku_summary_global_df['REMANING_STOCK'] 

# COMMAND ----------

sku_summary_global_df['REMANING_STOCK'].max()

# COMMAND ----------

sku_summary_global_df

# COMMAND ----------

sku_summary_global_df.to_csv("allocation/summary_review_aug_4th_v2.csv", index=False)
final_sku_collection_df.to_csv("allocation/initial_allocation_aug_4th_v2.csv", index=False)


# COMMAND ----------

import pandas as pd
df = pd.read_csv("allocation/initial_allocation_aug_4th_v2.csv")
df['BRAND_NAME'].value_counts()

# COMMAND ----------

purchased_options_df = global_options_df.groupby('VM_GROUP', as_index=False).agg({'OPTION_CODE':'nunique'}).rename({'OPTION_CODE':'GLOB_PURCHASED_OPTIONS'}, axis=1)
purchased_options_df.head()

# COMMAND ----------

vm_group_summary = final_sku_collection_df.groupby(['LOCATION_CODE','COUNTRY_CODE','VM_GROUP'],as_index=False).agg({'OPTION_CODE':'nunique','ALLOC_QTY':'sum'}).rename(columns={'OPTION_CODE':'OPTIONS_ALLOCATED'})
summery_df = vm_group_summary.merge(purchased_options_df, on=['VM_GROUP'], how='left')

# COMMAND ----------

sku_summary_global_df['TOTAl_WAREHOUSE_QTY'] = sku_summary_global_df[params['WAREHOUSE']].sum(axis=1)
sku_summary_global_df['TOTAl_STORE_ALLOC_QTY'] = sku_summary_global_df[params['STORE']].sum(axis=1)

sku_summary_global_df['REMANING_STOCK'] = sku_summary_global_df['GLOBAL_RETAIL_STOCK'].astype(float) - sku_summary_global_df['TOTAl_WAREHOUSE_QTY'].astype(float) - sku_summary_global_df['TOTAl_STORE_ALLOC_QTY'].astype(float)

# COMMAND ----------

sku_summary_global_df.to_csv("allocation/data/sku_summary_regionwise_aug_6th_v2.csv", index=False)
summery_df.to_csv("allocation/data/summery_df_v5.csv", index=False)
final_sku_collection_df.to_csv("allocation/data/initial_allocation_v5.csv", index=False)

# COMMAND ----------



# COMMAND ----------

while True: pass

# COMMAND ----------

store_record

# COMMAND ----------

sku_summary_global_df

# COMMAND ----------

selected_stores

# COMMAND ----------

sub_brand_conf_df

# COMMAND ----------

# def allocate_surplus(
#         sku_summary_df: pd.DataFrame,
#         alloc_df: pd.DataFrame,
#         wh_df: pd.DataFrame,
#         grade_order: tuple = ("A", "B"),
#         low_stock_thresh: int = 2
#     ) -> tuple[pd.DataFrame, pd.DataFrame]:
#     """
#     Distribute REMANING_STOCK for each SKU in sku_summary_df to stores in alloc_df.

#     Parameters
#     ----------
#     sku_summary_df : DataFrame
#         Must contain ['SKU_CODE', 'REMANING_STOCK'].
#     alloc_df : DataFrame
#         Must contain ['SKU_CODE','STORE_ID','STORE_GRADE','ALLOC_QTY'].
#     wh_df : DataFrame
#         One row per (country, SKU) warehouse. Must contain
#         ['SKU_CODE','COUNTRY','WH_QTY'].
#     grade_order : tuple
#         Priority sequence of store grades.
#     low_stock_thresh : int
#         Only stores with ALLOC_QTY ≤ this threshold are considered “low”.

#     Returns
#     -------
#     updated_alloc_df, updated_wh_df
#     """
#     # Make sure we don't modify the originals in‑place
#     alloc_df = alloc_df.copy()
#     wh_df    = wh_df.copy()

#     # Consider only SKUs with real surplus
#     surplus_df = sku_summary_df.loc[sku_summary_df["REMANING_STOCK"] > 10,
#                                     ["SKU_CODE", "REMANING_STOCK"]]

#     for sku_code, remaining in surplus_df.itertuples(index=False):
#         if remaining <= 0:
#             continue

#         # Drill down grade by grade
#         for grade in grade_order:
#             if remaining <= 0:
#                 break

#             mask = (
#                 (alloc_df["SKU_CODE"]  == sku_code) &
#                 (alloc_df["STORE_GRADE"] == grade) &
#                 (alloc_df["ALLOC_QTY"]  <= low_stock_thresh)
#             )
#             idxs = alloc_df.index[mask]

#             # Give one unit per store, in the order they appear
#             take = min(len(idxs), remaining)
#             alloc_df.loc[idxs[:take], "ALLOC_QTY"] += 1
#             remaining -= take

#         # Whatever is still left goes to the warehouse of that SKU’s country
#         if remaining > 0:
#             # Pick country from any one row for this SKU (assumes all rows same country!)
#             country = alloc_df.loc[alloc_df["SKU_CODE"] == sku_code,
#                                    "COUNTRY"].iloc[0]
#             wh_mask = (wh_df["SKU_CODE"] == sku_code) & (wh_df["COUNTRY"] == country)

#             if wh_mask.any():
#                 wh_df.loc[wh_mask, "WH_QTY"] += remaining
#             else:  # create a fresh row if the SKU hasn’t been seen in that warehouse yet
#                 wh_df = pd.concat([wh_df, pd.DataFrame([{
#                     "SKU_CODE": sku_code,
#                     "COUNTRY":  country,
#                     "WH_QTY":   remaining
#                 }])], ignore_index=True)

#     return alloc_df, wh_df


# COMMAND ----------

