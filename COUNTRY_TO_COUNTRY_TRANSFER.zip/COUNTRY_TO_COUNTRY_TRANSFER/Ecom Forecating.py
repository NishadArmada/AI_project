# Databricks notebook source
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# COMMAND ----------

ecom_sales_df = spark.sql("""
        select SALES_DATE,
        SUB_GROUP_NAME,
        SUB_SEASON_NAME,
        SEASON_NAME,
        OPTION_CODE,
        SUB_BRAND_NAME,
        SKU_CODE,
        DESIGN_ATTRIBUTE1,
        DESIGN_ATTRIBUTE2,
        DESIGN_ATTRIBUTE3,
        DESIGN_ATTRIBUTE4,
        sum(TOTAL_QUANTITY) as QTY_SOLD,
        avg(UNIT_PRICE_KD) as UNIT_PRICE_KD,
        avg(DISC_PRICE_KD) as DISC_PRICE_KD
        from gold.`custom-analysis`.sku_clustering_temp_sales_transfer where STORE_TYPE='ONLINE STORE' 
        group by SALES_DATE,SUB_BRAND_NAME,
        OPTION_CODE,SKU_CODE,GROUP_NAME,SUB_GROUP_NAME,SUB_SEASON_NAME,SEASON_NAME,
        DESIGN_ATTRIBUTE1,
        DESIGN_ATTRIBUTE2,
        DESIGN_ATTRIBUTE3,
        DESIGN_ATTRIBUTE4
    """).toPandas()

# COMMAND ----------

ecom_sales_df['SALES_DATE'] = pd.to_datetime(ecom_sales_df['SALES_DATE'])

# COMMAND ----------

ecom_sales_df["DISCOUNT_PCT"] = 1 - (ecom_sales_df["DISC_PRICE_KD"] / ecom_sales_df["UNIT_PRICE_KD"].replace(0, pd.NA))
ecom_sales_df["is_discounted"] = (ecom_sales_df["DISC_PRICE_KD"] < ecom_sales_df["UNIT_PRICE_KD"]).astype(int)
ecom_sales_df["day_of_week"] = ecom_sales_df["SALES_DATE"].dt.dayofweek
ecom_sales_df["week_of_year"] = ecom_sales_df["SALES_DATE"].dt.isocalendar().week
ecom_sales_df["days_since_launch"] = (ecom_sales_df["SALES_DATE"] - ecom_sales_df.groupby("OPTION_CODE")["SALES_DATE"].transform("min")).dt.days

# ---- Grouped EDA ----
daily_sales = ecom_sales_df.groupby("SALES_DATE")["QTY_SOLD"].sum()
brand_sales = ecom_sales_df.groupby("SUB_BRAND_NAME")["QTY_SOLD"].sum()
season_sales = ecom_sales_df.groupby("SEASON_NAME")["QTY_SOLD"].sum()


# COMMAND ----------


# -----------------------------
# Helpers
# -----------------------------

def standardize_columns(df: pd.DataFrame) -> pd.DataFrame:
    mapping = {c: c.strip().upper() for c in df.columns}
    df = df.rename(columns=mapping)
    # Minimal required columns
    required = ["SALES_DATE","OPTION_CODE","QTY_SOLD","UNIT_PRICE_KD","DISC_PRICE_KD"]
    for col in required:
        if col not in df.columns:
            raise ValueError(f"Missing required column: {col}")
    return df

def parse_dates_and_types(df: pd.DataFrame) -> pd.DataFrame:
    df["SALES_DATE"] = pd.to_datetime(df["SALES_DATE"], errors="coerce")
    # coerce numerics
    for col in ["QTY_SOLD","UNIT_PRICE_KD","DISC_PRICE_KD"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    # clean text columns (fill NA to 'Unknown')
    for col in ["SUB_GROUP_NAME","SUB_SEASON_NAME","SEASON_NAME","SUB_BRAND_NAME",
                "DESIGN_ATTRIBUTE1","DESIGN_ATTRIBUTE2","DESIGN_ATTRIBUTE3","DESIGN_ATTRIBUTE4",
                "SKU_CODE"]:
        if col in df.columns:
            df[col] = df[col].fillna("Unknown").astype(str)
    return df.dropna(subset=["SALES_DATE"])

def add_derived_columns(df: pd.DataFrame) -> pd.DataFrame:
    # Effective price (if discounted price is nonzero and positive, use it; else use unit price)
    eff_disc = df["DISC_PRICE_KD"].fillna(0.0)
    unit_price = df["UNIT_PRICE_KD"].replace(0, np.nan)
    effective_price = np.where(eff_disc > 0, eff_disc, unit_price)
    df["EFFECTIVE_PRICE_KD"] = pd.Series(effective_price, index=df.index)
    # Discount pct (clipped between 0 and 1, NaNs to 0)
    disc_pct = 1.0 - (df["EFFECTIVE_PRICE_KD"] / unit_price)
    df["DISCOUNT_PCT"] = disc_pct.replace([np.inf, -np.inf], np.nan).fillna(0.0).clip(0, 1)
    df["IS_DISCOUNTED"] = (df["DISCOUNT_PCT"] > 1e-6).astype(int)

    # Temporal features
    df["DOW"] = df["SALES_DATE"].dt.dayofweek
    df["WEEKOFYEAR"] = df["SALES_DATE"].dt.isocalendar().week.astype(int)
    df["IS_WEEKEND"] = df["DOW"].isin([5,6]).astype(int)

    # Launch date per option (approx: first sale date)
    df["FIRST_SALE_DATE"] = df.groupby("OPTION_CODE")["SALES_DATE"].transform("min")
    df["DAYS_SINCE_LAUNCH"] = (df["SALES_DATE"] - df["FIRST_SALE_DATE"]).dt.days

    # Revenue at effective price
    df["REVENUE_KD"] = df["QTY_SOLD"] * df["EFFECTIVE_PRICE_KD"]

    # Fill missing categorical columns
    for c in ["SEASON_NAME","SUB_SEASON_NAME","SUB_GROUP_NAME","SUB_BRAND_NAME"]:
        if c not in df.columns:
            df[c] = "Unknown"

    return df

# COMMAND ----------

ecom_sales_df = standardize_columns(ecom_sales_df)
ecom_sales_df = parse_dates_and_types(ecom_sales_df)

# COMMAND ----------

ecom_sales_df = add_derived_columns(ecom_sales_df)

# COMMAND ----------

def chart_seasonality(df):
    pivot = (df.groupby(["SALES_DATE","SEASON_NAME"])["QTY_SOLD"].sum()
               .reset_index()
               .pivot(index="SALES_DATE", columns="SEASON_NAME", values="QTY_SOLD")
               .fillna(0))
    plt.figure(figsize=(10,5))
    pivot.plot(ax=plt.gca())
    plt.title("Daily Sales by Season")
    plt.xlabel("Date"); plt.ylabel("Units Sold")
    plt.tight_layout()

def chart_lifecycle(df, top_n=10):
    totals = df.groupby("OPTION_CODE")["QTY_SOLD"].sum().sort_values(ascending=False).head(top_n).index
    sub = df[df["OPTION_CODE"].isin(totals)].copy()
    grp = sub.groupby(["OPTION_CODE","DAYS_SINCE_LAUNCH"])["QTY_SOLD"].sum().reset_index()
    pivot = grp.pivot(index="DAYS_SINCE_LAUNCH", columns="OPTION_CODE", values="QTY_SOLD").fillna(0)
    plt.figure(figsize=(10,5))
    pivot.plot(ax=plt.gca())
    plt.title(f"Lifecycle Curves (Top {top_n} Options)")
    plt.xlabel("Days Since Launch"); plt.ylabel("Units Sold")
    plt.tight_layout()

# COMMAND ----------

chart_seasonality(ecom_sales_df)

# COMMAND ----------

chart_lifecycle(ecom_sales_df)

# COMMAND ----------

def chart_subbrand_contribution(df, top_n=15):
    contrib = (df.groupby("SUB_BRAND_NAME")["QTY_SOLD"].sum()
                 .sort_values(ascending=True))
    plt.figure(figsize=(8, max(4, len(contrib)/2)))
    contrib.plot(kind="barh")
    plt.title("Sales Contribution by Sub-Brand")
    plt.xlabel("Units Sold"); plt.ylabel("Sub-Brand")
    plt.tight_layout()

# COMMAND ----------

chart_subbrand_contribution(ecom_sales_df)

# COMMAND ----------

def chart_discount_vs_sales(df):
    agg = (df.groupby("OPTION_CODE")
             .agg(units=("QTY_SOLD","sum"),
                  avg_disc=("DISCOUNT_PCT","mean"),
                  revenue=("REVENUE_KD","sum"))
             .reset_index())
    plt.figure(figsize=(8,6))
    sizes = np.sqrt(agg["revenue"].fillna(0) + 1.0) * 2.0  # bubble size
    plt.scatter(agg["avg_disc"], agg["units"], s=sizes)
    plt.xlabel("Avg Discount %"); plt.ylabel("Total Units Sold")
    plt.title("Discount vs Sales (bubble size ~ revenue)")
    plt.tight_layout()

# COMMAND ----------

chart_discount_vs_sales(ecom_sales_df)

# COMMAND ----------

def chart_top_subgroups(df, top_n=20):
    sg = (df.groupby("SUB_GROUP_NAME")["QTY_SOLD"].sum()
            .sort_values(ascending=True).tail(top_n))
    plt.figure(figsize=(8, max(4, top_n/2)))
    sg.plot(kind="barh")
    plt.title(f"Top {top_n} Sub-Groups by Units Sold")
    plt.xlabel("Units Sold"); plt.ylabel("Sub-Group")
    plt.tight_layout()

# COMMAND ----------

chart_top_subgroups(ecom_sales_df)

# COMMAND ----------

def chart_sellthrough_velocity(df, top_n=6):
    totals = df.groupby("OPTION_CODE")["QTY_SOLD"].sum().sort_values(ascending=False).head(top_n).index
    sub = df[df["OPTION_CODE"].isin(totals)].copy()
    sub = sub.sort_values(["OPTION_CODE","SALES_DATE"])
    # cumulative by date per option
    sub["CUM_UNITS"] = sub.groupby("OPTION_CODE")["QTY_SOLD"].cumsum()
    max_units = sub.groupby("OPTION_CODE")["CUM_UNITS"].transform("max")
    sub["CUM_FRAC"] = sub["CUM_UNITS"] / max_units.replace(0, np.nan)

    plt.figure(figsize=(10,6))
    for opt, g in sub.groupby("OPTION_CODE", sort=False):
        g = g.drop_duplicates("SALES_DATE")
        plt.plot(g["SALES_DATE"], g["CUM_FRAC"], label=str(opt))
    plt.title(f"Sell-Through Velocity (Top {top_n} Options)")
    plt.xlabel("Date"); plt.ylabel("Cumulative Fraction of Total Units")
    plt.legend(loc="best")
    plt.tight_layout()

# COMMAND ----------

chart_sellthrough_velocity(ecom_sales_df)

# COMMAND ----------

def chart_pareto(df):
    agg = (df.groupby("OPTION_CODE")["QTY_SOLD"].sum()
             .sort_values(ascending=False)
             .reset_index())
    agg["cum_units"] = agg["QTY_SOLD"].cumsum()
    agg["cum_share"] = agg["cum_units"] / agg["QTY_SOLD"].sum()
    agg["item_rank"] = np.arange(1, len(agg)+1)
    plt.figure(figsize=(9,5))
    plt.plot(agg["item_rank"]/len(agg), agg["cum_share"])
    plt.xlabel("Cumulative Share of Options"); plt.ylabel("Cumulative Share of Units")
    plt.title("Pareto Curve (Option Contribution to Sales)")
    plt.tight_layout()

# COMMAND ----------

chart_pareto(ecom_sales_df)

# COMMAND ----------

