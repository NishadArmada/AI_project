# Databricks notebook source
import pandas as pd
import re
import numpy as np
from datetime import date, timedelta
from pyspark.sql.functions import col, date_format, weekofyear, year, lpad, concat_ws
from pyspark.sql import functions as F

from scipy.stats import norm

# COMMAND ----------

warehouse_sku_df = spark.sql("""
          SELECT 
          distinct LOCATION_CODE as WAREHOUSE_CODE,
          SKU_CODE,
          OPTION_CODE,
          SIZE_CODE,
          COUNTRY,
          WAREHOUSE_STOCK_1 as WH_QTY
          FROM 
          gold.`custom-analysis`.SKU_BOX_QUANTITY
          where LOCATION_CODE not in ('101')
          """).toPandas()
warehouse_sku_df.head()

# COMMAND ----------

host_warehouse_stock = spark.sql("""
          SELECT 
          LOCATION_CODE as WAREHOUSE_CODE,
          SKU_CODE,
          OPTION_CODE,
          SIZE_CODE,
          COUNTRY,
          BOXQTY,
          WAREHOUSE_STOCK_1 as HOSTWATEHOUSE_STOCK
          FROM 
          gold.`custom-analysis`.SKU_BOX_QUANTITY
          WHERE LOCATION_CODE='101' 
          """).toPandas()
host_warehouse_stock.head()

# COMMAND ----------

host_warehouse_stock.head()

# COMMAND ----------

from pyspark.sql import functions as F
# Load the data
return_sku_df = spark.sql("""
                          SELECT 
                          DISTINCT SKU_CODE,
                          OPTION_CODE,
                          SIZE_CODE,
                          FROM_LOCATION AS LOCATION_CODE,
                          TO_LOCATION,
                          TRANSFER_TYPE
                           FROM gold.`custom-analysis`.oi_cardex_dup
                           WHERE
                           rn = 1
                           """)

store_current_stock = spark.sql(
                        """
                    SELECT 
                    ITEMCODE AS SKU_CODE, 
                    LOCATION_CODE,
                     (IN_STOCK + INTRANSIT_QTY) AS STORE_STOCK
                    from gold.`custom-analysis`.sku_stock_intransit_op_cur_stock
                    """
                    )

return_sku_df = return_sku_df.join(
    store_current_stock,
    on=['SKU_CODE', 'LOCATION_CODE'],
    how='left'
)


#  Step 1: Count unique SIZE_CODEs for TRANSFER OUT
transfer_out_counts = return_sku_df \
    .filter(
        (F.col("TRANSFER_TYPE") == "TRANSFER OUT") & 
        (F.col("STORE_STOCK") == 0)
    ).groupBy("LOCATION_CODE", "OPTION_CODE") \
    .agg(F.countDistinct("SIZE_CODE").alias("size_code_transfer_out_count"))

# Step 2: Count unique SIZE_CODEs overall
unique_sizes = return_sku_df \
    .groupBy("LOCATION_CODE", "OPTION_CODE") \
    .agg(F.countDistinct("SIZE_CODE").alias("unique_size_codes"))

# Step 3: Join both counts
result = unique_sizes.join(transfer_out_counts, on=["LOCATION_CODE", "OPTION_CODE"], how="left") \
    .withColumn("size_code_transfer_out_count", F.coalesce(F.col("size_code_transfer_out_count"), F.lit(0))) \
    .withColumn("unhealthy_option_cov", F.col("size_code_transfer_out_count") / F.col("unique_size_codes")) \
    .withColumn("healthy_cov", F.lit(1.0) - F.col("unhealthy_option_cov"))


option_cov_df = result.toPandas()
option_cov_df.head()
broken_return_option_df = option_cov_df[option_cov_df['healthy_cov']<0.50]
broken_return_option_df.head()

# COMMAND ----------

historic_sku_sales_df = spark.sql(
    """
        SELECT 
        SALES_DATE,
        LOCATION_CODE,STORE_TYPE,
        GRADE,COUNTRY,GROUP_NAME,
        SKU_CODE, OPTION_CODE,
        SIZE_CODE,LAUNCH_DATE,
        BRAND_NAME,SUB_BRAND_NAME,
        SIZE_GROUP,SEASON_NAME, SUB_SEASON_NAME,
        SUM(TOTAL_QUANTITY) AS TOTAL_QUANTITY
        FROM gold.`custom-analysis`.sku_clustering_temp_sales_transfer
        WHERE SALES_DATE BETWEEN DATE(CURRENT_DATE - INTERVAL 56 DAY) AND CURRENT_DATE
        AND      
        SKU_CODE in 
        (select distinct SKU_CODE  from gold.`custom-analysis`.product_attributes WHERE SEASON_NAME_YEAR in ('SPRING SUMMER 2025','AUTUMN WINTER 2025'))
        AND
        TRANS_ACTIVE='1'
        AND
        BRAND_NAME in ('RIVA','CHOICE','RIVA KIDS')
        GROUP BY
        SALES_DATE,SIZE_GROUP,
        LOCATION_CODE,STORE_TYPE,
        GRADE,COUNTRY,GROUP_NAME,
        SKU_CODE, OPTION_CODE,
        SIZE_CODE,LAUNCH_DATE,
        BRAND_NAME,SUB_BRAND_NAME,
        SEASON_NAME, SUB_SEASON_NAME
    """).toPandas()

historic_sku_sales_df['SALES_DATE'] = pd.to_datetime(historic_sku_sales_df['SALES_DATE'])

# COMMAND ----------

historic_sku_sales_df['SALES_DATE']     = pd.to_datetime(historic_sku_sales_df['SALES_DATE'])
historic_sku_sales_df['TOTAL_QUANTITY'] = pd.to_numeric(historic_sku_sales_df['TOTAL_QUANTITY'], errors='coerce').fillna(0)
cutoff = historic_sku_sales_df['SALES_DATE'].max() - pd.Timedelta(days=56)
final_historical_sales_df = historic_sku_sales_df[historic_sku_sales_df['SALES_DATE'] >= cutoff]

# COMMAND ----------

today = final_historical_sales_df['SALES_DATE'].max().normalize()
days_diff   = (today - final_historical_sales_df['SALES_DATE']).dt.days
week_number = days_diff // 7              # 0 = most-recent week, 1 = previous, 

# --- 4.  Compute the window-end and window-start for each row -------------
window_end   = today - pd.to_timedelta(week_number * 7,  unit='D')
window_start = window_end - pd.Timedelta(days=7)   # 7 days back from the end date

# --- 5.  Build a nice label like  “2025-02-05-2025-02-12” ----------------
final_historical_sales_df['WEEK_LABEL'] = (
        window_start.dt.strftime('%Y-%m-%d')
        + '-'
        + window_end.dt.strftime('%Y-%m-%d')
)

# optional: order by time so most-recent week appears first
final_historical_sales_df.sort_values(['WEEK_LABEL', 'SALES_DATE'], ascending=[True, True], inplace=True)

# COMMAND ----------

weekly_sales_qty_cols = sorted(final_historical_sales_df['WEEK_LABEL'].unique())

# COMMAND ----------

id_cols = [
    'LOCATION_CODE', 'STORE_TYPE', 'COUNTRY',
    'SKU_CODE', 'OPTION_CODE', 'SIZE_CODE', 'LAUNCH_DATE',
    'BRAND_NAME', 'SUB_BRAND_NAME','GRADE','GROUP_NAME','SIZE_GROUP'
    ]

# COMMAND ----------

agg = (final_historical_sales_df
       .groupby(id_cols + ['WEEK_LABEL'], as_index=False)
       .agg(QTY_SOLD=('TOTAL_QUANTITY', 'sum')))

# COMMAND ----------

pivot = (agg
         .pivot_table(index=id_cols,
                      columns='WEEK_LABEL',
                      values='QTY_SOLD',
                      aggfunc='sum',
                      fill_value=0
                      )).reset_index()

# COMMAND ----------

# ---------------------------------------------------------------------------
# libraries
# ---------------------------------------------------------------------------
from pyspark.sql import functions as F
from pyspark.sql.window import Window
import pandas as pd

# ---------------------------------------------------------------------------
# 1. Pull the last 42 calendar days of stock history
# ---------------------------------------------------------------------------
historical_week_stock_df = spark.sql("""
    SELECT
        STK_DATE,
        LOCATION_CODE,
        ITEMCODE        AS SKU_CODE,
        STOCK           AS CURRENT_STORE_STOCK
    FROM  gold.`custom-analysis`.SKU_STOCK_HISTORY_DUP
    WHERE STK_DATE BETWEEN DATE(CURRENT_DATE - INTERVAL 56 DAY) AND CURRENT_DATE
""")

# ---------------------------------------------------------------------------
# 2. Anchor the “today” reference at the latest STK_DATE in the dataset
# ---------------------------------------------------------------------------
today_str = (historical_week_stock_df
             .agg(F.max("STK_DATE").alias("today"))
             .collect()[0]["today"].strftime("%Y-%m-%d"))
today = F.lit(today_str).cast("date")

# ---------------------------------------------------------------------------
# 3. Work out which 7-day bucket each row belongs to
#    0 = most-recent week (today-7 → today], 1 = previous week, …
# ---------------------------------------------------------------------------
days_back   = F.datediff(today, F.col("STK_DATE"))
week_number = F.floor(days_back / 7).cast("int")            # INT is mandatory

week_offset_days = (week_number * 7).cast("int")            # still INT

window_end   = F.date_sub(today, week_offset_days)          # inclusive upper bound
window_start = F.date_sub(window_end, F.lit(7))             # exclusive lower bound

historical_week_stock_df = (historical_week_stock_df
    .withColumn("WEEK_NUM",  week_number)
    .withColumn("WIN_START", window_start)
    .withColumn("WIN_END",   window_end)
    .withColumn(
        "WEEK_LABEL",
        F.concat_ws("-",
            F.date_format("WIN_START", "yyyy-MM-dd"),
            F.date_format("WIN_END",   "yyyy-MM-dd")
        )
    )
)

# ---------------------------------------------------------------------------
# 4. Keep only the latest snapshot within each bucket / store / SKU
# ---------------------------------------------------------------------------
w = Window.partitionBy("LOCATION_CODE", "SKU_CODE", "WEEK_LABEL") \
          .orderBy(F.col("STK_DATE").desc())

latest_stock_df = (historical_week_stock_df
    .withColumn("rn", F.row_number().over(w))
    .filter("rn = 1")
    .select("LOCATION_CODE", "SKU_CODE", "WEEK_LABEL",
            F.round("CURRENT_STORE_STOCK").alias("CURRENT_STORE_STOCK"))
)

# ---------------------------------------------------------------------------
# 5. Spark → Pandas (you can keep it in Spark and use .pivot if you prefer)
# ---------------------------------------------------------------------------
pdf = latest_stock_df.toPandas()

# Clean negatives / nulls
pdf.loc[pdf["CURRENT_STORE_STOCK"] < 0, "CURRENT_STORE_STOCK"] = 0
pdf["CURRENT_STORE_STOCK"].fillna(0, inplace=True)

# ---------------------------------------------------------------------------
# 6. Pivot so every 7-day bucket becomes its own column
# ---------------------------------------------------------------------------
pdf = (pdf
    .pivot_table(index=["LOCATION_CODE", "SKU_CODE"],
                 columns="WEEK_LABEL",
                 values="CURRENT_STORE_STOCK",
                 aggfunc="first",
                 fill_value=0)
    .reset_index()
)

# ---------------------------------------------------------------------------
# 7. Add the -HIST suffix to bucket columns
# ---------------------------------------------------------------------------
pdf.columns = [c if c in ("LOCATION_CODE", "SKU_CODE") else f"{c}-HIST"
               for c in pdf.columns]

# ---------------------------------------------------------------------------
# 8. List the historical columns (optional) and preview
# ---------------------------------------------------------------------------
hist_stock_qty_cols = [c for c in pdf.columns
                       if c not in ("LOCATION_CODE", "SKU_CODE")]

print("HISTORICAL SKU Columns:", hist_stock_qty_cols)

# COMMAND ----------

pdf.head()

# COMMAND ----------

store_sku_df = pivot.merge(pdf, on=['LOCATION_CODE','SKU_CODE'], how='left')

# COMMAND ----------

week_cols = [c for c in store_sku_df.columns if re.match(r"\d{4}-\d{2}-\d{2}-\d{4}-\d{2}-\d{2}", c)]
week_cols = [c for c in week_cols if 'HIST' not in c]
# sort by the *start* date of the interval so left-to-right = oldest-→-newest
week_cols = sorted(week_cols,
                   key=lambda c: pd.to_datetime(c.split('-')[0]))   # 1st date in each lab

# COMMAND ----------

# ---------------- business rules (keep as‑is) -----------------
CYCLE_DAYS_HOST_TO_REGION   = 14      # review period (order frequency)
TRANSIT_DAYS_HOST_TO_REGION = 7       # lead time
SERVICE_LEVEL               = 0.60    # cycle‑service target
Z_VALUE = norm.ppf(1 - SERVICE_LEVEL / 2)   # ≈ 0.8416

# ---------------- new forecasting helper ----------------------
def store_next3_with_buffer(row):
    """
    Forecast next‑3‑week demand + one‑week safety stock, but
    return 0‑demand when the last 4 weeks were all zeros.
    """
    y   = row[week_cols].astype(float).to_numpy()
    y4  = y[-2:]                      # most‑recent 3 weeks

    # ⇲ Hard stop — no recent sales → no short‑term demand
    if y4.sum() == 0:
        return pd.Series([0, 0, 0], index=["NEXT_W1", "NEXT_W2", "NEXT_W3"])

    # Otherwise follow your original logic (slightly guarded)
    recent_non_zero = (y4 > 0).sum()
    ros = y4.mean() if recent_non_zero >= 2 else y.mean()

    # Sample std only if there was *any* recent activity, else 0
    std = y4.std(ddof=1) if recent_non_zero else 0.0
    ss  = max(0, Z_VALUE * std)       # one‑week safety stock

    f   = max(0, int(np.ceil(ros + ss)))
    return pd.Series([f, f, f], index=["NEXT_W1", "NEXT_W2", "NEXT_W3"])


# apply to your dataframe
store_sku_df[["NEXT_W1", "NEXT_W2", "NEXT_W3"]] = (
    store_sku_df.apply(store_next3_with_buffer, axis=1)
)


# COMMAND ----------

store_demand = (
    store_sku_df.groupby(["LOCATION_CODE","SKU_CODE"], as_index=False)
      [["NEXT_W2","NEXT_W3"]]
      .sum()
      .assign(DEMAND_COVERAGE=lambda x: x["NEXT_W2"])
)
store_sku_df = store_sku_df.merge(store_demand[['LOCATION_CODE','SKU_CODE','DEMAND_COVERAGE']], on=['LOCATION_CODE','SKU_CODE'], how='left')

# COMMAND ----------

store_sku_df.head()

# COMMAND ----------

# store_sku_df.loc[(store_sku_df[WEEK_COLS[-1]]>0) & (store_sku_df['DEMAND_COVERAGE']<=0)]

# COMMAND ----------

current_stock_df = spark.sql("""
                            select 
                            LOCATION_CODE,
                            ITEMCODE as SKU_CODE,
                            Intransit_QTY AS INTRANSIT_QTY,
                            INTERNATIONAL_INTRANSIT_QTY AS FRGN_INTRANSIT,
                            LOCAL_INTRANSIT_QTY,
                            Open_QTY AS OPEN_QTY,
                            (IN_STOCK + LOCAL_INTRANSIT_QTY+INTERNATIONAL_INTRANSIT_QTY + Open_QTY) AS TOTAL_NEW_STORE_STOCK,
                            IN_STOCK as CURRENT_STORE_STOCK
                            from gold.`custom-analysis`.SKU_stock_intransit_op_cur_stock 
                            WHERE  
                            ITEMCODE in (select distinct SKU_CODE  from gold.`custom-analysis`.product_attributes WHERE SEASON_NAME_YEAR IN ('SPRING SUMMER 2025','AUTUMN WINTER 2025'))
                            AND
                            BRAND_NAME 
                            IN 
                            ('RIVA','CHOICE', 'RIVA KIDS')
                            """).toPandas()

min_max_qty_df = spark.sql(f"""Select distinct GROUP_NAME,SCALE_CODE SIZE_GROUP, SIZE_CODE,SHOP_GRADE GRADE, MINQTY,MAXQTY from gold.`custom-analysis`.wms_shop_distribution_Dup 
                           """).toPandas()
min_max_qty_df['MINQTY'] = min_max_qty_df['MINQTY'].astype(int)
min_max_qty_df['MAXQTY'] = min_max_qty_df['MAXQTY'].astype(int)

current_stock_df.head()

# COMMAND ----------

sku_store_df = store_sku_df.merge(current_stock_df, on=['SKU_CODE', 'LOCATION_CODE'], how='left')
sku_store_df = sku_store_df.merge(min_max_qty_df, on=['GROUP_NAME','SIZE_GROUP','GRADE','SIZE_CODE'], how='left')
sku_store_df.head()

# COMMAND ----------

sku_store_df.loc[
    (sku_store_df['MINQTY'].isnull()) &(sku_store_df['GRADE']=='C') ,
    ['MINQTY','MAXQTY']] = (1, 1)

sku_store_df.loc[
    (sku_store_df['MINQTY'].isnull()) &(sku_store_df['GRADE']=='B'), 
    ['MINQTY','MAXQTY']] = (1, 2)

sku_store_df.loc[
    (sku_store_df['MINQTY'].isnull()) &(sku_store_df['GRADE']=='A'), 
    ['MINQTY','MAXQTY']] = (2, 3)

# COMMAND ----------

sku_store_df.fillna(0, inplace=True)

# COMMAND ----------

size_code_stock_df = sku_store_df.groupby(['LOCATION_CODE','OPTION_CODE','SIZE_CODE'], as_index=False).agg({'TOTAL_NEW_STORE_STOCK':'sum'})

option_stock_df = (
    size_code_stock_df
    .groupby(['LOCATION_CODE', 'OPTION_CODE'])['TOTAL_NEW_STORE_STOCK']
    .sum()
    .reset_index()
    .rename(columns={'TOTAL_NEW_STORE_STOCK': 'OPTION_TOTAL_STOCK'})
)

option_stock_size_df = (
    size_code_stock_df
    .groupby(['LOCATION_CODE', 'OPTION_CODE'])
    .apply(lambda x: dict(zip(x['SIZE_CODE'], x['TOTAL_NEW_STORE_STOCK'])))
    .reset_index(name='SIZE_CODE_STOCK_DICT')
)

option_stock_df = option_stock_size_df.merge(option_stock_df, on=['LOCATION_CODE','OPTION_CODE'], how='left')

# COMMAND ----------

sku_store_df = sku_store_df.merge(option_stock_df, on=['LOCATION_CODE', 'OPTION_CODE'], how='left')
sku_store_df.head()

# COMMAND ----------

# sku_store_df.loc[
#     (sku_store_df['DEMAND_COVERAGE'] == 0) &
#     (sku_store_df['TOTAL_NEW_STORE_STOCK'] == 0) &
#     (sku_store_df['OPTION_TOTAL_STOCK'] > 0),
#     'DEMAND_COVERAGE'
# ]  = sku_store_df.loc[
#     (sku_store_df['DEMAND_COVERAGE'] == 0) &
#     (sku_store_df['TOTAL_NEW_STORE_STOCK'] == 0) &
#     (sku_store_df['OPTION_TOTAL_STOCK'] > 0),
#     'MINQTY'
# ]

# COMMAND ----------

warehouse_qty_df = warehouse_sku_df.groupby(['WAREHOUSE_CODE','SKU_CODE','COUNTRY'],as_index=False).agg({'WH_QTY':'sum'})

# COMMAND ----------

warehouse_qty_df.head()

# COMMAND ----------

# --- 1.  Attach warehouse stock -------------------------------------------
final_sku_stock_df = (sku_store_df
      .merge(warehouse_qty_df[['WAREHOUSE_CODE','SKU_CODE','COUNTRY','WH_QTY']],
             on=['COUNTRY', 'SKU_CODE'],
             how='left')
      .fillna({'WH_QTY': 0}))

# COMMAND ----------

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='KUWAIT'),
                   'WAREHOUSE_CODE'
                   ] = 'K9901'

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='BAHRAIN'),
                   'WAREHOUSE_CODE'
                   ] = 'B97'

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='UAE'),
                   'WAREHOUSE_CODE'
                   ] = 'U019901'

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='SAUDI ARABIA'),
                   'WAREHOUSE_CODE'
                   ] = 'S99'


final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='QATAR'),
                   'WAREHOUSE_CODE'
                   ] = 'Q9901'

final_sku_stock_df.loc[(final_sku_stock_df['WAREHOUSE_CODE'].isnull()) & 
                   (final_sku_stock_df['COUNTRY']=='OMAN'),
                   'WAREHOUSE_CODE'
                   ] = 'O019901'

# COMMAND ----------

WEEK_COLS = weekly_sales_qty_cols.copy()
STOCK_COLS = list(hist_stock_qty_cols).copy()

pairwise_good = [
    final_sku_stock_df[week].where(final_sku_stock_df[stock] > 0, 0)          # keep sales only if opening stock > 0
    for week, stock in zip(WEEK_COLS, STOCK_COLS)
]
good_sales_total = pd.concat(pairwise_good, axis=1).sum(axis=1)
good_weeks_count = (final_sku_stock_df[STOCK_COLS] > 0).sum(axis=1)       # how many weeks had stock

# daily ROS = total sales / (good_weeks × 7)
final_sku_stock_df["ROS_DAY"] = (
    good_sales_total /
    (good_weeks_count.replace(0, np.nan) * 16)
).fillna(0)

miss_mask          = final_sku_stock_df[STOCK_COLS].eq(0) & final_sku_stock_df[WEEK_COLS].eq(0)
miss_weeks_cnt     = miss_mask.sum(axis=1)
# final_sku_stock_df["MISSED_UNITS"]  = (final_sku_stock_df["ROS_DAY"] * 7 * miss_weeks_cnt).round()

# COMMAND ----------

final_sku_stock_df = final_sku_stock_df.merge(host_warehouse_stock[['SKU_CODE','HOSTWATEHOUSE_STOCK']], how='left')
final_sku_stock_df.head()

# COMMAND ----------

final_sku_stock_df['STOCK_LAST_4W'] = final_sku_stock_df[hist_stock_qty_cols[-4:]].sum(axis=1)

# COMMAND ----------

final_sku_stock_df[final_sku_stock_df['OPTION_CODE']=='101109-25120-024']

# COMMAND ----------

condition = (
    (final_sku_stock_df['STOCK_LAST_4W'] == 0) &
    (final_sku_stock_df['DEMAND_COVERAGE'] == 0) &
    ((final_sku_stock_df['WH_QTY'] + final_sku_stock_df['HOSTWATEHOUSE_STOCK']) > 0) &
    (final_sku_stock_df['ROS_DAY'] > 0.1)
)


final_sku_stock_df.loc[condition,'DEMAND_COVERAGE'] = np.round(final_sku_stock_df.loc[condition,'ROS_DAY'] * 7)

# COMMAND ----------

# sku_transfer_out_df = spark.sql("""
# SELECT 
# SKU_CODE,
# FROM_LOCATION AS LOCATION_CODE,
# TO_LOCATION,
# DATE(TRANS_DT) TRANSFER_DATE,
# QUANTITY AS QUANTITY_TRANSFERED,
# TRANSFER_TYPE
#  FROM gold.`custom-analysis`.OI_CARDEX_DUP
#  WHERE TRANS_DT>'2024'
# """).toPandas()

# final_sku_stock_df = final_sku_stock_df.merge(sku_transfer_out_df, on=['SKU_CODE', 'LOCATION_CODE'], how='left')

# COMMAND ----------

final_sku_stock_df = final_sku_stock_df.merge(broken_return_option_df, on=['LOCATION_CODE','OPTION_CODE'], how='left')
final_sku_stock_df.head()

# COMMAND ----------

mask = (
    (final_sku_stock_df[WEEK_COLS[-2:]].sum(axis=1) >=final_sku_stock_df['DEMAND_COVERAGE']) & 
    (final_sku_stock_df['DEMAND_COVERAGE']>0) &
    (final_sku_stock_df[WEEK_COLS[-2:]].sum(axis=1)<=5)
)
final_sku_stock_df.loc[mask, 'DEMAND_COVERAGE'] = np.round(final_sku_stock_df.loc[mask, WEEK_COLS[-2:]].sum(axis=1) * 1.5)

# COMMAND ----------

mask = (
    (final_sku_stock_df[WEEK_COLS[-2:]].sum(axis=1) >=final_sku_stock_df['DEMAND_COVERAGE']) & 
    (final_sku_stock_df['DEMAND_COVERAGE']>0) &
    (final_sku_stock_df[WEEK_COLS[-2:]].sum(axis=1)>5)
)
final_sku_stock_df.loc[mask, 'DEMAND_COVERAGE'] = np.round(final_sku_stock_df.loc[mask, WEEK_COLS[-2:]].sum(axis=1) * 1.2)

# COMMAND ----------

final_sku_stock_df.loc[(final_sku_stock_df['OPTION_CODE']=='101108-25129-067') & (final_sku_stock_df['COUNTRY']=='KUWAIT') & (final_sku_stock_df['LOCATION_CODE']=='K1005')
                       ,['LOCATION_CODE','OPTION_CODE','SKU_CODE'] + WEEK_COLS+['DEMAND_COVERAGE']+['TOTAL_NEW_STORE_STOCK']]

# COMMAND ----------

final_sku_stock_df[
    (final_sku_stock_df['COUNTRY']=='KUWAIT') &
(final_sku_stock_df['SKU_CODE']=='101108-25129-067-MED')
]

# COMMAND ----------

final_sku_stock_df.loc[
    (final_sku_stock_df['healthy_cov'].notnull()),
    'DEMAND_COVERAGE'
    ] = 0

# COMMAND ----------

MISSED_LAMBDA = 0.20                             # weight on missed units
# High‑priority order: lower number = higher priority
STORE_PRIORITY_MAP = {"A": 0, "B": 1, "C": 2, "OUTLET": 3}

# COMMAND ----------

final_sku_stock_df["PRIORITY_RANK"]  = final_sku_stock_df["GRADE"].map(STORE_PRIORITY_MAP).fillna(99).astype(int)

# COMMAND ----------

# mask = (final_sku_stock_df['DEMAND_COVERAGE']>0) & (final_sku_stock_df['DEMAND_COVERAGE'] < final_sku_stock_df['MINQTY'])
# final_sku_stock_df.loc[mask, 'DEMAND_COVERAGE'] = final_sku_stock_df.loc[mask, 'MINQTY']

# COMMAND ----------

final_sku_stock_df["RAW_NEED"] = (final_sku_stock_df['DEMAND_COVERAGE'].astype(float) - final_sku_stock_df["TOTAL_NEW_STORE_STOCK"].astype(float)).clip(lower=0)
#final_sku_stock_df["ADJ_NEED"] = final_sku_stock_df["RAW_NEED"].astype(float) + final_sku_stock_df["MISSED_UNITS"].astype(float)

# COMMAND ----------

def compute_need(adj, lo, hi):
    if adj == 0:
        return 0                               # ① no demand
    elif adj <=lo:
        return lo                              # ② bump up to minimum                            # ③ cap at maximum
    else:
        return adj                             # ④ use adj as‑is

final_sku_stock_df["NEED"] = final_sku_stock_df.apply(
    lambda r: compute_need(r["RAW_NEED"], r["MINQTY"], r["MAXQTY"]),
    axis=1
).astype(int)


# COMMAND ----------

final_need_df = final_sku_stock_df[['LOCATION_CODE','STORE_TYPE','COUNTRY','OPTION_CODE','SKU_CODE','BRAND_NAME','SUB_BRAND_NAME','GROUP_NAME','DEMAND_COVERAGE','TOTAL_NEW_STORE_STOCK','WH_QTY','NEED','WAREHOUSE_CODE']]

# COMMAND ----------

final_need_df.rename({'WH_QTY':'WH_STOCK_QTY'}, axis=1, inplace=True)

# COMMAND ----------

final_need_df[
    (final_need_df['COUNTRY']=='KUWAIT') &
(final_need_df['SKU_CODE']=='101108-25129-067-MED')
]['NEED'].sum()

# COMMAND ----------

final_need_df.loc[(final_need_df['SKU_CODE']=='101108-25129-067-MED') &
(final_need_df['COUNTRY']=='KUWAIT')]

# COMMAND ----------

final_need_df.head()

# COMMAND ----------

total_store_stock_df = final_need_df.groupby(['COUNTRY', 'SKU_CODE'], as_index=False).agg({'TOTAL_NEW_STORE_STOCK': 'sum'}).rename({'TOTAL_NEW_STORE_STOCK':'TOTAL_STORE_STOCK'})

# COMMAND ----------

country_sku_demand = (
    final_need_df.groupby(['COUNTRY','BRAND_NAME','SUB_BRAND_NAME','GROUP_NAME','WAREHOUSE_CODE','SKU_CODE'])
    .agg(
        TOTAL_NEED=('NEED', 'sum'),
        TOTAL_LOCAL_WH_STOCK=('WH_STOCK_QTY', 'first')
    )
    .reset_index()
)

# COMMAND ----------

country_sku_demand = country_sku_demand[country_sku_demand['TOTAL_NEED']>0]

# COMMAND ----------

country_sku_demand

# COMMAND ----------

spark.conf.set('spark.sql.ansi.enabled', False)

# COMMAND ----------

country_df = spark.sql("""WITH country_sales AS (
    SELECT 
        CASE 
            WHEN Market = 'UAE' THEN 'UAE'
            WHEN Market = 'KWT' THEN 'KUWAIT'
            WHEN Market = 'BAH' THEN 'BAHRAIN'
            WHEN Market = 'OMN' THEN 'OMAN'
            WHEN Market = 'SUD' THEN 'SAUDI ARABIA'
            WHEN Market = 'QA'  THEN 'QATAR'
        END AS COUNTRY,
        SKU_CODE,
        SUM(SaleQty) AS SALES_QTY,
        SUM(InQty) AS RECIEVED_QTY
    FROM gold.`custom-analysis`.sku_host_to_local
    WHERE Market IN ('UAE','SUD','BAH','KWT','OMN','QA')
      AND SKU_CODE IN 
      (select distinct SKU_CODE  from gold.`custom-analysis`.product_attributes 
      WHERE SEASON_NAME_YEAR IN ('SPRING SUMMER 2025','AUTUMN WINTER 2025'))
    GROUP BY 
        CASE 
            WHEN Market = 'UAE' THEN 'UAE'
            WHEN Market = 'KWT' THEN 'KUWAIT'
            WHEN Market = 'BAH' THEN 'BAHRAIN'
            WHEN Market = 'OMN' THEN 'OMAN'
            WHEN Market = 'SUD' THEN 'SAUDI ARABIA'
            WHEN Market = 'QA'  THEN 'QATAR'
        END,
        SKU_CODE
),
global_sales AS (
    SELECT 
        SKU_CODE,
        SUM(SALES_QTY) AS GLOBAL_SALES_QTY
    FROM country_sales
    GROUP BY SKU_CODE
),
global_received AS (
    SELECT 
        SKU_CODE,
        SUM(RECIEVED_QTY) AS GLOBAL_RECIEVED
    FROM country_sales
    GROUP BY SKU_CODE
)
SELECT 
    cs.COUNTRY,
    cs.SKU_CODE,
    cs.SALES_QTY,
    cs.RECIEVED_QTY,
    gs.GLOBAL_SALES_QTY,
    gr.GLOBAL_RECIEVED,
    cs.SALES_QTY / gs.GLOBAL_SALES_QTY AS SALES_MIX,
    cs.RECIEVED_QTY / gr.GLOBAL_RECIEVED AS RECIVE_MIX
FROM country_sales cs
LEFT JOIN global_sales gs ON cs.SKU_CODE = gs.SKU_CODE
LEFT JOIN global_received gr ON cs.SKU_CODE = gr.SKU_CODE
""").toPandas()



df = country_df.copy() 
df['MIX_GAP']        = df['SALES_MIX'] - df['RECIVE_MIX']
# 1️⃣  Mix-gap drives the priority
df['MIX_GAP'] = (
    df['SALES_MIX'] - df['RECIVE_MIX']
)

# 2️⃣  Rank countries inside each SKU (1 = replenish first)
df['COUNTRY_PRIORITY'] = (
    df
        .groupby('SKU_CODE')['MIX_GAP']          # per SKU
        .rank(method='dense',                    # 1,2,3… without ties gaps
              ascending=False)                   # bigger gap → higher priority
)


# COMMAND ----------

country_sku_demand = country_sku_demand.merge(df, on=['COUNTRY','SKU_CODE'], how='left').fillna(0)

# COMMAND ----------

region_stock_df = spark.sql("""
select  SKU_CODE,  
        CASE 
            WHEN Market = 'UAE' THEN 'UAE'
            WHEN Market = 'KWT' THEN 'KUWAIT'
            WHEN Market = 'BAH' THEN 'BAHRAIN'
            WHEN Market = 'OMN' THEN 'OMAN'
            WHEN Market = 'SUD' THEN 'SAUDI ARABIA'
            WHEN Market = 'QA'  THEN 'QATAR'
        END AS COUNTRY, 
        TOTAL_STOCK as TOTAL_REGION_STOCK
        from gold.`custom-analysis`.sku_host_to_local
        where Market IN ('UAE','KWT','OMN','SUD','QA','BAH')
        """).toPandas()
country_sku_demand = country_sku_demand.merge(region_stock_df, on=['SKU_CODE','COUNTRY'], how='left')

# COMMAND ----------

country_sku_demand

# COMMAND ----------

sku_demand = final_need_df.groupby(['COUNTRY','SKU_CODE'], as_index=False).agg({'DEMAND_COVERAGE':'sum'}).rename({'DEMAND_COVERAGE':'DEMAND'}, axis=1)

# COMMAND ----------

sku_demand

# COMMAND ----------

country_sku_demand = country_sku_demand.merge(sku_demand, on=['SKU_CODE','COUNTRY'], how='left')
country_sku_demand.drop('TOTAL_NEED', axis=1, inplace=True)

# COMMAND ----------

country_sku_demand.loc[country_sku_demand['DEMAND']>0,'DEMAND'] += 1

# COMMAND ----------

country_sku_demand.loc[(country_sku_demand['DEMAND']>0) & (country_sku_demand['COUNTRY'].isin(['KUWAIT','SAUDI ARABIA','UAE'])),'DEMAND'] += 2

# COMMAND ----------

country_sku_demand.rename({'DEMAND':'TOTAL_NEED'}, axis=1,inplace=True)

# COMMAND ----------

country_sku_demand['SHORTFALL'] = np.where(
    country_sku_demand['TOTAL_NEED'] > country_sku_demand['TOTAL_REGION_STOCK'],
    country_sku_demand['TOTAL_NEED'] - country_sku_demand['TOTAL_REGION_STOCK'],
    0
)

# COMMAND ----------

country_sku_demand

# COMMAND ----------

country_sku_demand.isnull().sum()

# COMMAND ----------

country_sku_demand.dropna(inplace=True)

# COMMAND ----------

country_sku_demand.isnull().sum()

# COMMAND ----------

host_warehouse_stock_df = host_warehouse_stock.groupby(['SKU_CODE','OPTION_CODE'], as_index=False).agg({'HOSTWATEHOUSE_STOCK': 'sum'})
host_warehouse_stock_df.head()

# COMMAND ----------

final_sku_replenishment_df = country_sku_demand.merge(host_warehouse_stock_df, on=['SKU_CODE'], how='left')

# COMMAND ----------

final_sku_replenishment_df.loc[(final_sku_replenishment_df['SKU_CODE']=='101109-25009-005-XSM') &
                   (final_sku_replenishment_df['COUNTRY']=='UAE') ,
                             ]

# COMMAND ----------

final_sku_replenishment_df['HOSTWATEHOUSE_STOCK'].fillna(0, inplace=True)

# COMMAND ----------

# ============================================================
# Country → Country Transfer Planner (Retail / Fashion)
# Author: Nishad + ChatGPT
# ============================================================

import pandas as pd
from typing import Optional, Literal, Tuple

# ------------------------------------------------------------
# 0) Configuration / Display
# ------------------------------------------------------------
pd.set_option("display.max_rows", 150)
pd.set_option("display.max_columns", 150)
pd.set_option("display.width", 160)

# ------------------------------------------------------------
# 1) Helpers: Validation, Normalization, Diagnostics
# ------------------------------------------------------------

REQUIRED_COLS = {
    "COUNTRY","BRAND_NAME","SUB_BRAND_NAME","GROUP_NAME","WAREHOUSE_CODE","SKU_CODE",
    "TOTAL_LOCAL_WH_STOCK","SALES_QTY","RECIEVED_QTY","GLOBAL_SALES_QTY","GLOBAL_RECIEVED",
    "SALES_MIX","RECIVE_MIX","MIX_GAP","COUNTRY_PRIORITY","TOTAL_REGION_STOCK","TOTAL_NEED",
    "SHORTFALL","OPTION_CODE","HOSTWATEHOUSE_STOCK"
}

NUM_COLS = [
    "TOTAL_LOCAL_WH_STOCK","SALES_QTY","RECIEVED_QTY","GLOBAL_SALES_QTY","GLOBAL_RECIEVED",
    "SALES_MIX","RECIVE_MIX","MIX_GAP","COUNTRY_PRIORITY","TOTAL_REGION_STOCK","TOTAL_NEED",
    "SHORTFALL","HOSTWATEHOUSE_STOCK"
]

def assert_required_columns(df: pd.DataFrame):
    missing = [c for c in REQUIRED_COLS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

def normalize_fields(df: pd.DataFrame) -> pd.DataFrame:
    """
    - Upper/strip countries to avoid 'UAE ' vs 'UAE'
    - Coerce numeric columns
    - Fill obvious NAs
    """
    x = df.copy()
    if "COUNTRY" in x.columns:
        x["COUNTRY"] = x["COUNTRY"].astype(str).str.strip().str.upper()
    if "BRAND_NAME" in x.columns:
        x["BRAND_NAME"] = x["BRAND_NAME"].astype(str).str.strip()
    if "OPTION_CODE" in x.columns:
        x["OPTION_CODE"] = x["OPTION_CODE"].astype(str).str.strip()
    if "SKU_CODE" in x.columns:
        x["SKU_CODE"] = x["SKU_CODE"].astype(str).str.strip()

    for c in NUM_COLS:
        if c in x.columns:
            x[c] = pd.to_numeric(x[c], errors="coerce").fillna(0)

    # Guard against negative shortfalls/needs
    if "SHORTFALL" in x.columns:
        x["SHORTFALL"] = x["SHORTFALL"].clip(lower=0)
    if "TOTAL_NEED" in x.columns:
        x["TOTAL_NEED"] = x["TOTAL_NEED"].clip(lower=0)

    return x

def debug_country_xfer(df: pd.DataFrame):
    x = normalize_fields(df)
    x["SURPLUS"] = (x["TOTAL_REGION_STOCK"] - x["TOTAL_NEED"]).clip(lower=0)

    receivers = x[(x["HOSTWATEHOUSE_STOCK"] == 0) & (x["SHORTFALL"] > 0)]
    donors_surplus = x[x["SURPLUS"] > 0]
    donors_stock = x[x["TOTAL_REGION_STOCK"] > 0]

    print("Receivers (host=0, shortfall>0):", len(receivers))
    print("Donors (surplus>0):", len(donors_surplus))
    print("Donors (stock>0):  ", len(donors_stock))

    r_skus = set(receivers["SKU_CODE"])
    r_opts = set(receivers["OPTION_CODE"])
    ds_skus = set(donors_surplus["SKU_CODE"])
    ds_opts = set(donors_surplus["OPTION_CODE"])
    dk_skus = set(donors_stock["SKU_CODE"])
    dk_opts = set(donors_stock["OPTION_CODE"])

    print("SKU overlap (receivers ∩ donors_surplus):", len(r_skus & ds_skus))
    print("SKU overlap (receivers ∩ donors_stock):  ", len(r_skus & dk_skus))
    print("OPTION overlap (receivers ∩ donors_surplus):", len(r_opts & ds_opts))
    print("OPTION overlap (receivers ∩ donors_stock):  ", len(r_opts & dk_opts))


def show_blocked_examples(df: pd.DataFrame, country_plan: pd.DataFrame, mode: Literal["SKU","OPTION"]="OPTION", top_n: int = 5):
    """
    If plan is empty, print a few candidate receiver/donor pairs that SHOULD match.
    """
    if not country_plan.empty:
        print("Transfers exist; nothing to debug.")
        return

    x = normalize_fields(df)
    x["SURPLUS"] = (x["TOTAL_REGION_STOCK"] - x["TOTAL_NEED"]).clip(lower=0)
    receivers = x[(x["HOSTWATEHOUSE_STOCK"]==0) & (x["SHORTFALL"]>0)]
    donors_stock = x[x["TOTAL_REGION_STOCK"]>0]

    key = "OPTION_CODE" if mode == "OPTION" else "SKU_CODE"
    keys = list(set(receivers[key]).intersection(set(donors_stock[key])))[:top_n]

    for k in keys:
        print(f"\n--- {key} = {k} ---")
        r = receivers[receivers[key]==k].copy()
        d = donors_stock[donors_stock[key]==k].copy()
        print("Receivers:")
        print(r[["COUNTRY","BRAND_NAME","WAREHOUSE_CODE","SHORTFALL","COUNTRY_PRIORITY","MIX_GAP"]].head(10))
        print("Candidate donors (stock>0):")
        print(d[["COUNTRY","BRAND_NAME","WAREHOUSE_CODE","TOTAL_REGION_STOCK","TOTAL_NEED"]].head(10))

# ------------------------------------------------------------
# 2) Core Planner (Flexible)
# ------------------------------------------------------------

def plan_country_transfers_v2(
    df: pd.DataFrame,
    pack_size: Optional[int] = None,
    donor_buffer: int = 0,
    cost_df: Optional[pd.DataFrame] = None,         # columns: from_country, to_country, unit_cost (or cost_pct)
    prefer_lower_cost: bool = True,
    tie_break: str = "MIX_GAP",
    allow_same_brand_only: bool = True,
    donor_mode: Literal["surplus","stock"] = "stock",  # 'stock' = looser, 'surplus' = protects donors
    match_on: Literal["SKU","OPTION"] = "OPTION",      # OPTION works better for fashion sizes
    require_host_zero: bool = True
) -> Tuple[pd.DataFrame, pd.DataFrame]:

    assert_required_columns(df)
    x = normalize_fields(df)
    x["SURPLUS"] = (x["TOTAL_REGION_STOCK"] - x["TOTAL_NEED"]).clip(lower=0)

    # Receivers
    receivers = x[x["SHORTFALL"] > 0].copy()
    if require_host_zero:
        receivers = receivers[receivers["HOSTWATEHOUSE_STOCK"] == 0]

    # Donors
    if donor_mode == "surplus":
        donors = x[x["SURPLUS"] > 0].copy()
    else:
        donors = x[x["TOTAL_REGION_STOCK"] > 0].copy()

    key = "SKU_CODE" if match_on == "SKU" else "OPTION_CODE"
    plan_rows = []

    # Route costs (optional)
    route_cost = None
    if cost_df is not None and not cost_df.empty:
        rc = cost_df.copy()
        rc.columns = [str(c).lower() for c in rc.columns]
        if "from_country" not in rc.columns or "to_country" not in rc.columns:
            raise ValueError("cost_df must have 'from_country' and 'to_country' columns")
        if "unit_cost" not in rc.columns and "cost_pct" not in rc.columns:
            raise ValueError("cost_df must have either 'unit_cost' or 'cost_pct'")
        rc["from_country"] = rc["from_country"].astype(str).str.strip().str.upper()
        rc["to_country"]   = rc["to_country"].astype(str).str.strip().str.upper()
        route_cost = rc

    # Group by matching key (SKU or OPTION)
    for k_val, rec_grp in receivers.groupby(key, sort=False):
        donor_grp = donors[donors[key] == k_val].copy()
        if donor_grp.empty:
            continue

        if allow_same_brand_only:
            rec_brands = rec_grp["BRAND_NAME"].dropna().unique()
            donor_grp = donor_grp[donor_grp["BRAND_NAME"].isin(rec_brands)]
            if donor_grp.empty:
                continue

        # Available qty baseline
        if donor_mode == "surplus":
            donor_grp["AVAILABLE"] = donor_grp["SURPLUS"] - donor_buffer
        else:
            donor_grp["AVAILABLE"] = donor_grp["TOTAL_REGION_STOCK"] - donor_buffer
        donor_grp["AVAILABLE"] = donor_grp["AVAILABLE"].clip(lower=0)

        # Receiver order: priority asc, then under-index gap desc
        sort_cols = ["COUNTRY_PRIORITY"]
        asc = [True]
        if tie_break in rec_grp.columns:
            sort_cols.append(tie_break); asc.append(False)
        rec_grp = rec_grp.sort_values(sort_cols, ascending=asc)

        for _, r in rec_grp.iterrows():
            need = int(r["SHORTFALL"])
            if need <= 0:
                continue

            # Filter donor candidates (not the same country, available>0)
            cand = donor_grp[(donor_grp["COUNTRY"] != r["COUNTRY"]) & (donor_grp["AVAILABLE"] > 0)].copy()
            if cand.empty:
                continue

            # Cost-aware ordering (optional)
            if route_cost is not None:
                cand = cand.merge(
                    route_cost,
                    how="left",
                    left_on="COUNTRY",
                    right_on="from_country"
                )
                # only rows that can go to the receiver's country
                cand = cand[(cand["to_country"].fillna("") == r["COUNTRY"]) | (cand["to_country"].isna())]
                if "unit_cost" in cand.columns:
                    cand["_unit_cost"] = cand["unit_cost"].fillna(0.0)
                elif "cost_pct" in cand.columns:
                    cand["_unit_cost"] = cand["cost_pct"].fillna(0.0)
                else:
                    cand["_unit_cost"] = 0.0

                if prefer_lower_cost:
                    cand = cand.sort_values(["_unit_cost","AVAILABLE"], ascending=[True, False])
                else:
                    cand = cand.sort_values(["AVAILABLE"], ascending=[False])
            else:
                cand = cand.sort_values(["AVAILABLE"], ascending=[False])

            # Greedy allocation over donors
            for d_idx, d in cand.iterrows():
                if need <= 0:
                    break
                give = int(min(need, d["AVAILABLE"]))
                if give <= 0:
                    continue

                # Pack rounding (if shipping in series/cartons)
                if pack_size and pack_size > 1:
                    give = (give // pack_size) * pack_size
                    if give == 0:
                        continue

                    # Edge case: if remainder < pack_size everywhere, you may end with small unmet need.
                    # That's acceptable under pack constraints.

                plan_rows.append({
                    key: k_val,
                    "SKU_CODE": r["SKU_CODE"],
                    "OPTION_CODE": r["OPTION_CODE"],
                    "FROM_COUNTRY": d["COUNTRY"],
                    "TO_COUNTRY": r["COUNTRY"],
                    "FROM_WAREHOUSE": d["WAREHOUSE_CODE"],
                    "TO_WAREHOUSE": r["WAREHOUSE_CODE"],
                    "TRANSFER_QTY": give,
                    "RECEIVER_PRIORITY": r["COUNTRY_PRIORITY"],
                    "RECEIVER_MIX_GAP": r["MIX_GAP"]
                })

                need -= give
                donor_grp.loc[d_idx, "AVAILABLE"] = int(d["AVAILABLE"] - give)

    country_plan = pd.DataFrame(plan_rows)

    # KPIs
    if not country_plan.empty:
        kpi = (
            country_plan.groupby(["TO_COUNTRY"], as_index=False)["TRANSFER_QTY"].sum()
            .rename(columns={"TRANSFER_QTY":"TOTAL_INBOUND"})
        )
        asked = receivers.groupby("COUNTRY", as_index=False)["SHORTFALL"].sum()\
                         .rename(columns={"COUNTRY":"TO_COUNTRY","SHORTFALL":"ASKED_SHORTFALL"})
        kpi = kpi.merge(asked, how="right", on="TO_COUNTRY").fillna(0)
        kpi["COVERAGE_%"] = (kpi["TOTAL_INBOUND"] / kpi["ASKED_SHORTFALL"].replace({0: pd.NA}) * 100).round(1)
    else:
        kpi = pd.DataFrame(columns=["TO_COUNTRY","TOTAL_INBOUND","ASKED_SHORTFALL","COVERAGE_%"])

    return country_plan, kpi

# ------------------------------------------------------------
# 3) Optional: Country → Store Fan-out (proportional allocation)
# ------------------------------------------------------------

def fan_out_to_stores(
    country_plan: pd.DataFrame,
    store_need: pd.DataFrame   # columns: COUNTRY, STORE_CODE, SKU_CODE, STORE_SHORTFALL
) -> pd.DataFrame:
    if country_plan.empty:
        return pd.DataFrame(columns=["SKU_CODE","OPTION_CODE","TO_COUNTRY","STORE_CODE","ALLOCATED_QTY"])

    SN_REQ = {"COUNTRY","STORE_CODE","SKU_CODE","STORE_SHORTFALL"}
    missing = [c for c in SN_REQ if c not in store_need.columns]
    if missing:
        raise ValueError(f"store_need missing columns: {missing}")

    sn = store_need.copy()
    sn["COUNTRY"] = sn["COUNTRY"].astype(str).str.strip().str.upper()
    sn["STORE_CODE"] = sn["STORE_CODE"].astype(str).str.strip()
    sn["SKU_CODE"] = sn["SKU_CODE"].astype(str).str.strip()
    sn["STORE_SHORTFALL"] = pd.to_numeric(sn["STORE_SHORTFALL"], errors="coerce").fillna(0).clip(lower=0)

    out_rows = []

    # For each (country, SKU) inbound, allocate across stores proportional to store shortfall
    for (to_country, sku), grp in country_plan.groupby(["TO_COUNTRY","SKU_CODE"]):
        total_inbound = int(grp["TRANSFER_QTY"].sum())
        if total_inbound <= 0:
            continue

        need = sn[(sn["COUNTRY"] == to_country) & (sn["SKU_CODE"] == sku)].copy()
        need = need[need["STORE_SHORTFALL"] > 0]
        if need.empty:
            continue

        need["W"] = need["STORE_SHORTFALL"] / need["STORE_SHORTFALL"].sum()
        raw = need["W"] * total_inbound
        need["alloc_floor"] = raw.astype(int)
        remainder = total_inbound - need["alloc_floor"].sum()
        need["rem_frac"] = raw - need["alloc_floor"]
        need = need.sort_values("rem_frac", ascending=False)
        need["ALLOCATED_QTY"] = need["alloc_floor"]
        if remainder > 0:
            need.iloc[:remainder, need.columns.get_loc("ALLOCATED_QTY")] += 1

        opt = grp["OPTION_CODE"].iloc[0] if "OPTION_CODE" in grp.columns else None
        for _, r in need.iterrows():
            if r["ALLOCATED_QTY"] <= 0:
                continue
            out_rows.append({
                "SKU_CODE": sku,
                "OPTION_CODE": opt,
                "TO_COUNTRY": to_country,
                "STORE_CODE": r["STORE_CODE"],
                "ALLOCATED_QTY": int(r["ALLOCATED_QTY"])
            })

    return pd.DataFrame(out_rows)

# ------------------------------------------------------------
# 4) QUICK START (Example Usage)
# ------------------------------------------------------------
# Replace `final_sku_replenishment_df` with your DataFrame variable

# final_sku_replenishment_df = ...  # <-- your data here

def run_transfer_planning(final_sku_replenishment_df: pd.DataFrame,
                          cost_df: Optional[pd.DataFrame] = None):
    # 4.1) Basic sanity debug
    print("=== DEBUG SNAPSHOT ===")
    debug_country_xfer(final_sku_replenishment_df)

    # 4.2) Looser run to ensure non-empty (stock donors + OPTION match)
    print("\n=== RUN 1: donor_mode='stock', match_on='OPTION' ===")
    country_plan, kpi = plan_country_transfers_v2(
        final_sku_replenishment_df,
        donor_mode="stock",
        match_on="OPTION",
        allow_same_brand_only=True,
        require_host_zero=True,
        pack_size=None,
        donor_buffer=0,
        cost_df=cost_df,
        prefer_lower_cost=True,
        tie_break="MIX_GAP"
    )
    print("country_plan rows:", len(country_plan))
    print(country_plan.head(20))
    print("\nKPI:")
    print(kpi.sort_values("COVERAGE_%", ascending=True).head(20))

    # 4.3) Safer run (protect donors) — only if you want to re-tighten
    print("\n=== RUN 2 (Safer): donor_mode='surplus', match_on='OPTION' ===")
    country_plan_safe, kpi_safe = plan_country_transfers_v2(
        final_sku_replenishment_df,
        donor_mode="surplus",
        match_on="OPTION",
        allow_same_brand_only=True,
        require_host_zero=True,
        pack_size=None,
        donor_buffer=0,
        cost_df=cost_df,
        prefer_lower_cost=True,
        tie_break="MIX_GAP"
    )
    print("country_plan_safe rows:", len(country_plan_safe))
    print(country_plan_safe.head(20))
    print("\nKPI (safe):")
    print(kpi_safe.sort_values("COVERAGE_%", ascending=True).head(20))

    # 4.4) If both empty, show probable blocked cases
    if country_plan.empty and country_plan_safe.empty:
        print("\n=== NO TRANSFERS; SHOWING BLOCKED EXAMPLES ===")
        show_blocked_examples(final_sku_replenishment_df, country_plan, mode="OPTION", top_n=5)

    # 4.5) CSV export hooks (optional)
    country_plan.to_csv("country_transfer_plan.csv", index=False)
    kpi.to_csv("country_transfer_kpi.csv", index=False)
    country_plan_safe.to_csv("country_transfer_plan_safe.csv", index=False)
    kpi_safe.to_csv("country_transfer_kpi_safe.csv", index=False)

    return (country_plan, kpi, country_plan_safe, kpi_safe)

# ------------------------------------------------------------
# 5) OPTIONAL: Cost table example (customs/insurance/freight)
# ------------------------------------------------------------
# Example shape:
# cost_df = pd.DataFrame({
#     "from_country": ["UAE","QATAR","KSA","UAE"],
#     "to_country":   ["BAHRAIN","BAHRAIN","BAHRAIN","KSA"],
#     "unit_cost":    [0.8, 1.2, 1.0, 0.7],  # lower is preferred
#     # OR use "cost_pct": [5, 8, 6, 4]  # % cost; lower is preferred
# })

# ------------------------------------------------------------
# 6) RUN
# ------------------------------------------------------------
# Example:
country_plan, kpi, country_plan_safe, kpi_safe = run_transfer_planning(final_sku_replenishment_df, cost_df=None)

# ------------------------------------------------------------
# 7) OPTIONAL: Fan-out to stores after country plan (needs a store shortfall table)
# ------------------------------------------------------------
# store_need = pd.DataFrame({
#     "COUNTRY": ["BAHRAIN","BAHRAIN","BAHRAIN"],
#     "STORE_CODE": ["B01","B02","B03"],
#     "SKU_CODE": ["161112-25011-006-MED","161112-25011-006-MED","161112-25011-006-MED"],
#     "STORE_SHORTFALL": [2,3,1]
# })
# store_plan = fan_out_to_stores(country_plan, store_need)
# store_plan.to_csv("country_to_store_transfer_plan.csv", index=False)
# print(store_plan.head(20))


# COMMAND ----------

country_plan.head()

# COMMAND ----------

country_sku_demand.rename({'COUNTRY':'FROM_COUNTRY'}, axis=1, inplace=True)

# COMMAND ----------

country_sku_demand

# COMMAND ----------

country_plan

# COMMAND ----------

country_plan_safe[country_plan_safe['SKU_CODE']=='161112-25012-013-MED']

# COMMAND ----------

final_sku_replenishment_df[final_sku_replenishment_df['SKU_CODE']=='161112-25012-013-MED']

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * from gold.`custom-analysis`.sku_host_to_local WHERE SKU_CODE='161112-25012-013-MED'

# COMMAND ----------

def plan_country_transfers_v3(
    df: pd.DataFrame,
    pack_size: Optional[int] = None,
    donor_buffer: int = 0,
    cost_df: Optional[pd.DataFrame] = None,
    prefer_lower_cost: bool = True,
    tie_break: str = "MIX_GAP",
    allow_same_brand_only: bool = True,
    donor_mode: Literal["surplus","stock"] = "surplus",
    match_on: Literal["SKU","OPTION"] = "OPTION",
    require_host_zero: bool = True,
    require_exact_sku: bool = False,        # <-- NEW
    include_donor_sku: bool = True          # <-- NEW
) -> Tuple[pd.DataFrame, pd.DataFrame]:

    assert_required_columns(df)
    x = normalize_fields(df)
    x["SURPLUS"] = (x["TOTAL_REGION_STOCK"] - x["TOTAL_NEED"]).clip(lower=0)

    receivers = x[x["SHORTFALL"] > 0].copy()
    if require_host_zero:
        receivers = receivers[receivers["HOSTWATEHOUSE_STOCK"] == 0]

    donors = x[x["SURPLUS"] > 0].copy() if donor_mode == "surplus" else x[x["TOTAL_REGION_STOCK"] > 0].copy()

    key = "SKU_CODE" if match_on == "SKU" else "OPTION_CODE"
    plan_rows = []

    route_cost = None
    if cost_df is not None and not cost_df.empty:
        rc = cost_df.copy()
        rc.columns = [str(c).lower() for c in rc.columns]
        rc["from_country"] = rc["from_country"].astype(str).str.strip().str.upper()
        rc["to_country"]   = rc["to_country"].astype(str).str.strip().str.upper()
        if "unit_cost" not in rc.columns and "cost_pct" not in rc.columns:
            raise ValueError("cost_df must have 'unit_cost' or 'cost_pct'")
        route_cost = rc

    for k_val, rec_grp in receivers.groupby(key, sort=False):
        donor_grp = donors[donors[key] == k_val].copy()
        if donor_grp.empty:
            continue

        if allow_same_brand_only:
            rec_brands = rec_grp["BRAND_NAME"].dropna().unique()
            donor_grp = donor_grp[donor_grp["BRAND_NAME"].isin(rec_brands)]
            if donor_grp.empty:
                continue

        base_available = donor_grp["SURPLUS"] if donor_mode == "surplus" else donor_grp["TOTAL_REGION_STOCK"]
        donor_grp["AVAILABLE"] = (base_available - donor_buffer).clip(lower=0)

        sort_cols = ["COUNTRY_PRIORITY"]; asc = [True]
        if tie_break in rec_grp.columns: sort_cols += [tie_break]; asc += [False]
        rec_grp = rec_grp.sort_values(sort_cols, ascending=asc)

        for _, r in rec_grp.iterrows():
            need = int(r["SHORTFALL"]); 
            if need <= 0: continue

            cand = donor_grp[(donor_grp["COUNTRY"] != r["COUNTRY"]) & (donor_grp["AVAILABLE"] > 0)].copy()
            if cand.empty: continue

            # If we’re matching on OPTION but we require exact SKU, keep only donor rows with the same SKU
            if match_on == "OPTION" and require_exact_sku:
                cand = cand[cand["SKU_CODE"] == r["SKU_CODE"]]
                if cand.empty: 
                    continue

            # cost-aware ordering
            if route_cost is not None:
                cand = cand.merge(route_cost, how="left", left_on="COUNTRY", right_on="from_country")
                cand = cand[(cand["to_country"].fillna("") == r["COUNTRY"]) | (cand["to_country"].isna())]
                if "unit_cost" in cand.columns: cand["_unit_cost"] = cand["unit_cost"].fillna(0.0)
                elif "cost_pct" in cand.columns: cand["_unit_cost"] = cand["cost_pct"].fillna(0.0)
                else: cand["_unit_cost"] = 0.0
                cand = cand.sort_values(["_unit_cost","AVAILABLE"], ascending=[True, False])
            else:
                cand = cand.sort_values(["AVAILABLE"], ascending=[False])

            for d_idx, d in cand.iterrows():
                if need <= 0: break
                give = int(min(need, d["AVAILABLE"]))
                if give <= 0: continue

                if pack_size and pack_size > 1:
                    give = (give // pack_size) * pack_size
                    if give == 0: continue

                row = {
                    "MATCH_KEY": k_val,
                    "RECEIVER_SKU_CODE": r["SKU_CODE"],
                    "RECEIVER_OPTION_CODE": r["OPTION_CODE"],
                    "FROM_COUNTRY": d["COUNTRY"],
                    "TO_COUNTRY": r["COUNTRY"],
                    "FROM_WAREHOUSE": d["WAREHOUSE_CODE"],
                    "TO_WAREHOUSE": r["WAREHOUSE_CODE"],
                    "TRANSFER_QTY": give,
                    "RECEIVER_PRIORITY": r["COUNTRY_PRIORITY"],
                    "RECEIVER_MIX_GAP": r["MIX_GAP"],
                }
                if include_donor_sku:
                    row["DONOR_SKU_CODE"] = d["SKU_CODE"]
                    row["DONOR_OPTION_CODE"] = d["OPTION_CODE"]

                plan_rows.append(row)

                need -= give
                donor_grp.loc[d_idx, "AVAILABLE"] = int(d["AVAILABLE"] - give)

    country_plan = pd.DataFrame(plan_rows)

    # KPIs
    if not country_plan.empty:
        kpi = (
            country_plan.groupby(["TO_COUNTRY"], as_index=False)["TRANSFER_QTY"].sum()
            .rename(columns={"TRANSFER_QTY":"TOTAL_INBOUND"})
        )
        asked = receivers.groupby("COUNTRY", as_index=False)["SHORTFALL"].sum()\
                         .rename(columns={"COUNTRY":"TO_COUNTRY","SHORTFALL":"ASKED_SHORTFALL"})
        kpi = kpi.merge(asked, how="right", on="TO_COUNTRY").fillna(0)
        kpi["COVERAGE_%"] = (kpi["TOTAL_INBOUND"] / kpi["ASKED_SHORTFALL"].replace({0: pd.NA}) * 100).round(1)
    else:
        kpi = pd.DataFrame(columns=["TO_COUNTRY","TOTAL_INBOUND","ASKED_SHORTFALL","COVERAGE_%"])

    return country_plan, kpi

# COMMAND ----------

country_plan_safe, kpi_safe = plan_country_transfers_v3(
    final_sku_replenishment_df,
    donor_mode="surplus",
    match_on="OPTION",         # still match option…
    require_exact_sku=True,    # …but require donor SKU == receiver SKU
    include_donor_sku=True,    # record both sides
    allow_same_brand_only=True,
    require_host_zero=True
)

# COMMAND ----------

# Spot-check the SKU in question:
country_plan_safe#[country_plan_safe["RECEIVER_SKU_CODE"]=="161112-25012-013-MED"]

# COMMAND ----------

country_sku_demand.rename({'COUNTRY':'FROM_COUNTRY'}, axis=1, inplace=True)

# COMMAND ----------

country_plan_safe = country_plan_safe[['FROM_COUNTRY','TO_COUNTRY','TRANSFER_QTY','RECEIVER_PRIORITY','RECEIVER_MIX_GAP','RECEIVER_SKU_CODE']]
country_plan_safe.rename({'RECEIVER_SKU_CODE':'SKU_CODE'}, axis=1, inplace=True)

# COMMAND ----------

s = country_plan_safe.merge(country_sku_demand[['FROM_COUNTRY','SKU_CODE','RECIEVED_QTY','SALES_QTY','SALES_MIX','RECIVE_MIX']],on=['FROM_COUNTRY','SKU_CODE'], how='left')
s.rename({'RECEIVER_MIX_GAP':'FROM_RECEIVER_MIX_GAP',
          'RECIEVED_QTY':'FROM_RECIEVED_QTY',
          'SALES_QTY':'FROM_SALES_QTY',
          'SALES_MIX':'FROM_SALES_MIX',
          'RECIVE_MIX':'FROM_RECIVE_MIX'},
         axis=1,
         inplace=True
         )

# COMMAND ----------

s

# COMMAND ----------

country_sku_demand.rename({'FROM_COUNTRY':'TO_COUNTRY'}, axis=1, inplace=True)

# COMMAND ----------

s = s.merge(country_sku_demand[['TO_COUNTRY','SKU_CODE','RECIEVED_QTY','SALES_QTY','SALES_MIX','RECIVE_MIX']],on=['TO_COUNTRY','SKU_CODE'], how='left')

s.rename({'RECEIVER_MIX_GAP':'TO_RECEIVER_MIX_GAP',
          'RECIEVED_QTY':'TO_RECIEVED_QTY',
          'SALES_QTY':'TO_SALES_QTY',
          'SALES_MIX':'TO_SALES_MIX',
          'RECIVE_MIX':'TO_RECIVE_MIX'},
         axis=1,
         inplace=True
         )

# COMMAND ----------

s.isnull().sum()

# COMMAND ----------

display(s[s['SKU_CODE'].str.contains('101110-25015-048')])

# COMMAND ----------

s.to_csv("country_plan.csv", index=False)

# COMMAND ----------

